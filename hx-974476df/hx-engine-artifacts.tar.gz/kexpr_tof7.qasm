OPENQASM 3.0;
include "stdgates.inc";
// Certified by kexpr-thm-toffoli7-exact (8/8 exact Z[zeta_8], T-count=7)
qubit[3] q;
h q[2];
cx q[1], q[2];
tdg q[2];
cx q[0], q[2];
t q[2];
cx q[1], q[2];
tdg q[2];
cx q[0], q[2];
t q[1];
t q[2];
cx q[0], q[1];
h q[2];
t q[0];
tdg q[1];
cx q[0], q[1];
