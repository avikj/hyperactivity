// Generated mechanically by lib/ir/geodesic-ir.hypercubical (41st Engine: hx geodesic)
// ZERO-BIAS PARAMETER-FREE GEODESIC INFERENCE + HOMEOMORPHIC CRYPTIC GAUGE + SWARM BUS
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/resource.h>
static volatile sig_atomic_t g_run = 1;
static void on_sig(int s) { (void)s; g_run = 0; }
static uint64_t now_us(void) { struct timeval tv; gettimeofday(&tv, NULL); return (uint64_t)tv.tv_sec * 1000000ull + (uint64_t)tv.tv_usec; }
static uint64_t rss_kib(void) { struct rusage ru; if (getrusage(RUSAGE_SELF, &ru) != 0) return 0; return (uint64_t)ru.ru_maxrss / 1024ull; }
static inline uint32_t pop64(uint64_t x) { return (uint32_t)__builtin_popcountll(x); }
static inline uint32_t pop16(uint16_t x) { return (uint32_t)__builtin_popcount((unsigned)x); }
// === HOMEOMORPHIC CRYPTIC GAUGE E_K : F_2^64 <~> F_2^64 (100% CAPACITY, 0% SLOWDOWN!) ===
typedef struct { uint8_t bit_perm[64]; uint8_t bit_inv[64]; uint64_t otp_mask; uint8_t pol; uint64_t key_commit; } CrypticGauge;
static CrypticGauge g_gauge;
static uint64_t g_cryptic_verified = 0ull, g_cryptic_errors = 0ull;
static void init_cryptic_gauge(void) {
  uint64_t seed[2] = { 0x9E3779B97F4A7C15ull, 0xD1B54A32D192ED03ull };
  int fd = open("/dev/urandom", O_RDONLY);
  if (fd >= 0) { ssize_t r = read(fd, seed, sizeof(seed)); (void)r; close(fd); }
  for (unsigned i = 0; i < 64u; i++) g_gauge.bit_perm[i] = (uint8_t)i;
  uint64_t ks = seed[0] ^ 0x4858435259505431ull;
  for (unsigned i = 63u; i > 0u; i--) {
    ks = (ks ^ (ks >> 30)) * 0xbf58476d1ce4e5b9ull;
    unsigned j = (unsigned)(ks % (uint64_t)(i + 1u));
    uint8_t tmp = g_gauge.bit_perm[i]; g_gauge.bit_perm[i] = g_gauge.bit_perm[j]; g_gauge.bit_perm[j] = tmp;
  }
  for (unsigned i = 0; i < 64u; i++) g_gauge.bit_inv[g_gauge.bit_perm[i]] = (uint8_t)i;
  g_gauge.pol = (uint8_t)(seed[1] & 1ull);
  g_gauge.otp_mask = g_gauge.pol ? ~0ull : 0ull;
  g_gauge.key_commit = (seed[0] * 0x94d049bb133111ebull) ^ (seed[1] >> 17);
}
static uint64_t gauge_enc64(uint64_t plain) {
  uint64_t out = 0ull; for (unsigned i = 0; i < 64u; i++) if ((plain >> i) & 1ull) out |= (1ull << g_gauge.bit_perm[i]); return out ^ g_gauge.otp_mask; }
static uint64_t gauge_dec64(uint64_t cry) { uint64_t u = cry ^ g_gauge.otp_mask, out = 0ull; for (unsigned i = 0; i < 64u; i++) if ((u >> i) & 1ull) out |= (1ull << g_gauge.bit_inv[i]); return out; }
// === STAGE A: EXACT HYPEROCTAHEDRAL NPN SYMMETRY QUOTIENT (3-VAR=14, 4-VAR=222) ===
static uint16_t g_npn4[65536];
static uint32_t g_npn3_classes = 0, g_npn4_classes = 0;
static const uint8_t P4[24][4] = {
  {0,1,2,3},{0,1,3,2},{0,2,1,3},{0,2,3,1},{0,3,1,2},{0,3,2,1},
  {1,0,2,3},{1,0,3,2},{1,2,0,3},{1,2,3,0},{1,3,0,2},{1,3,2,0},
  {2,0,1,3},{2,0,3,1},{2,1,0,3},{2,1,3,0},{2,3,0,1},{2,3,1,0},
  {3,0,1,2},{3,0,2,1},{3,1,0,2},{3,1,2,0},{3,2,0,1},{3,2,1,0}};
static inline uint16_t neg4_tt(uint16_t t, unsigned m) {
  if (m & 1u) t = (uint16_t)(((t & 0x5555u) << 1) | ((t >> 1) & 0x5555u));
  if (m & 2u) t = (uint16_t)(((t & 0x3333u) << 2) | ((t >> 2) & 0x3333u));
  if (m & 4u) t = (uint16_t)(((t & 0x0F0Fu) << 4) | ((t >> 4) & 0x0F0Fu));
  if (m & 8u) t = (uint16_t)(((t & 0x00FFu) << 8) | ((t >> 8) & 0x00FFu));
  return t;
}
static void build_exact_npn_quotient(void) {
  uint8_t seen4[65536]; memset(seen4, 0, sizeof(seen4));
  uint8_t seen3[256];   memset(seen3, 0, sizeof(seen3));
  for (uint32_t f = 0; f < 65536u; f++) {
    uint16_t best = 0xFFFFu;
    for (int p = 0; p < 24; p++) {
      uint16_t tp = 0;
      for (unsigned x = 0; x < 16u; x++) {
        unsigned y = ((x >> P4[p][0]) & 1u) | (((x >> P4[p][1]) & 1u) << 1) | (((x >> P4[p][2]) & 1u) << 2) | (((x >> P4[p][3]) & 1u) << 3);
        if ((f >> y) & 1u) tp |= (uint16_t)(1u << x); }
      for (unsigned m = 0; m < 16u; m++) {
        uint16_t tn = neg4_tt(tp, m); uint16_t ti = (uint16_t)(~tn);
        if (tn < best) best = tn;
        if (ti < best) best = ti; } }
    g_npn4[f] = best; seen4[best] = 1; }
  for (uint32_t f = 0; f < 65536u; f++) g_npn4_classes += seen4[f];
  const uint8_t P3[6][3] = {{0,1,2},{0,2,1},{1,0,2},{1,2,0},{2,0,1},{2,1,0}};
  for (uint32_t f3 = 0; f3 < 256u; f3++) {
    uint8_t best3 = 0xFFu;
    for (int p = 0; p < 6; p++) {
      uint8_t tp = 0;
      for (unsigned x = 0; x < 8u; x++) {
        unsigned y = ((x >> P3[p][0]) & 1u) | (((x >> P3[p][1]) & 1u) << 1) | (((x >> P3[p][2]) & 1u) << 2);
        if ((f3 >> y) & 1u) tp |= (uint8_t)(1u << x); }
      for (unsigned m = 0; m < 8u; m++) {
        uint16_t tn16 = neg4_tt((uint16_t)(tp | (tp << 8)), m);
        uint8_t tn = (uint8_t)(tn16 & 0xFFu); uint8_t ti = (uint8_t)(~tn);
        if (tn < best3) best3 = tn;
        if (ti < best3) best3 = ti; } }
    seen3[best3] = 1; }
  for (uint32_t f3 = 0; f3 < 256u; f3++) g_npn3_classes += seen3[f3]; }
// === STAGE B: EXACT 4-VAR SYNTHESIS + CAUSAL CONTEXT-FIBER TABLE (DEPTH 3..0) ===
static uint8_t  u4_cost[65536], u4_op[65536];
static uint16_t u4_pa[65536], u4_pb[65536], u4_order[65536];
static uint32_t u4_cnt = 0;
static uint64_t g_evals = 0, g_identities = 0, g_pruned = 0, g_gc_reclaimed = 0;
static uint32_t fib3[9][9][4][4], fib2[9][9][4], fib1[9][4], fib0[4];
static inline unsigned wbucket16(uint16_t t) { unsigned w = pop16(t); if (w > 8u) w = 16u - w; return w; }
static inline unsigned wbucket64(uint64_t t) { unsigned w = pop64(t); if (w > 32u) w = 64u - w; return w >> 2; }
static inline unsigned ovclass64(uint64_t a, uint64_t b) {
  uint64_t ab = a & b;
  if (ab == 0ull) return 0u;
  if (ab == a || ab == b) return 1u;
  if ((a ^ b) == ~0ull) return 2u;
  return 3u; }
static inline uint16_t eval4_op(unsigned op, uint16_t a, uint16_t b) {
  switch (op & 3u) { case 0u: return (uint16_t)(a ^ b); case 1u: return (uint16_t)(a & b); case 2u: return (uint16_t)((~a) & b); default: return (uint16_t)(~(a & b)); } }
// 1-Cycle Gauge-Conjugated 64-bit Gate Evaluator: hat_op_K(u, v) = E_K(op(D_K(u), D_K(v)))!
static inline uint64_t eval64_cryptic_op(unsigned op, uint64_t u, uint64_t v_in) {
  if (!g_gauge.pol) {
    switch (op & 3u) { case 0u: return u ^ v_in; case 1u: return u & v_in; case 2u: return (~u) & v_in; default: return ~(u & v_in); }
  } else {
    switch (op & 3u) { case 0u: return ~(u ^ v_in); case 1u: return u | v_in; case 2u: return (~u) | v_in; default: return ~(u | v_in); }
  }
}
static void geo_rank_ops(unsigned c1, unsigned c2, unsigned c3, unsigned out_ops[4], unsigned* contractible_hit) {
  unsigned excl = 0u, placed = 0u; *contractible_hit = 0u;
  for (int depth = 3; depth >= 0 && placed < 4u; depth--) {
    const uint32_t* f = (depth == 3) ? fib3[c1][c2][c3] : (depth == 2) ? fib2[c1][c2] : (depth == 1) ? fib1[c1] : fib0;
    unsigned rem_in_fib = 0u;
    for (unsigned op = 0; op < 4u; op++) if (!(excl & (1u << op)) && f[op] > 0u) rem_in_fib++;
    if (depth == 3 && placed == 0u && rem_in_fib == 1u) *contractible_hit = 1u;
    while (rem_in_fib > 0u && placed < 4u) {
      uint32_t best_cnt = 0u; unsigned best_op = 0u;
      for (unsigned op = 0; op < 4u; op++) if (!(excl & (1u << op)) && f[op] > best_cnt) { best_cnt = f[op]; best_op = op; }
      if (best_cnt == 0u) break;
      out_ops[placed++] = best_op; excl |= (1u << best_op); rem_in_fib--;
    }
  }
  for (unsigned op = 0; op < 4u && placed < 4u; op++) if (!(excl & (1u << op))) { out_ops[placed++] = op; excl |= (1u << op); }
}
static void run_wave01_and_extract_fibers(FILE* jlog) {
  memset(u4_cost, 255, sizeof(u4_cost)); u4_cnt = 0;
  const uint16_t seeds[6] = { 0x0000u, 0xFFFFu, 0xAAAAu, 0xCCCCu, 0xF0F0u, 0xFF00u };
  for (unsigned i = 0; i < 6u; i++) { u4_cost[seeds[i]] = 0; u4_order[u4_cnt++] = seeds[i]; }
  uint32_t lstart[16]; lstart[0] = 0; lstart[1] = u4_cnt;
  for (uint8_t d = 1; d <= 9 && u4_cnt < 65536u && g_run; d++) {
    uint32_t prev_end = u4_cnt, ns = lstart[d - 1];
    for (uint32_t i = ns; i < prev_end && u4_cnt < 65536u; i++) {
      uint16_t a = u4_order[i];
      for (uint32_t j = 0; j <= i && u4_cnt < 65536u; j++) {
        uint16_t b = u4_order[j];
        for (unsigned op = 0; op < 4u; op++) {
          unsigned maxk = (op == 2u) ? 2u : 1u;
          for (unsigned sw = 0; sw < maxk; sw++) {
            uint16_t x = sw ? b : a, y0 = sw ? a : b; uint16_t r = eval4_op(op, x, y0); g_evals++;
            if (u4_cost[r] == 255u) {
              u4_cost[r] = d; u4_op[r] = (uint8_t)op; u4_pa[r] = x; u4_pb[r] = y0; u4_order[u4_cnt++] = r;
              unsigned c1 = wbucket16(x), c2 = wbucket16(y0);
              unsigned c3 = ovclass64((uint64_t)x * 0x0001000100010001ull, (uint64_t)y0 * 0x0001000100010001ull);
              fib3[c1][c2][c3][op]++; fib2[c1][c2][op]++; fib1[c1][op]++; fib0[op]++;
            } else { g_identities++; g_pruned++; }
          } } } }
    lstart[d + 1] = u4_cnt; }
  fprintf(jlog, "{\"event\":\"wave1_atlas_complete\",\"npn3_classes\":%u,\"npn4_classes\":%u,\"u4_covered\":%u,\"gauge_commit\":\"0x%016llx\",\"fib0_xor\":%u,\"fib0_and\":%u,\"fib0_nand2\":%u}\n", g_npn3_classes, g_npn4_classes, u4_cnt, (unsigned long long)g_gauge.key_commit, fib0[0], fib0[1], fib0[3]); fflush(jlog); }
// === STAGE C: BOUNDED 16 MiB CRYPTIC QUOTIENT TABLE + DAG-CSE WAVEFRONT ===
#define QT_BITS 20
#define QT_SIZE (1u << QT_BITS)
#define QT_MASK (QT_SIZE - 1u)
static uint64_t qt_cry_tt[QT_SIZE];
static uint8_t  qt_cost[QT_SIZE], qt_refs[QT_SIZE];
static uint32_t qt_used = 0;
#define POOL_CAP 32768
typedef struct { uint64_t cry_tt; uint16_t pa; uint16_t pb; uint8_t op; uint8_t gates; } GeoNode;
static GeoNode  g_pool[POOL_CAP];
static uint32_t g_pool_sz = 0, g_depth_cnt[16], g_epoch = 1u, g_mark[POOL_CAP];
static uint8_t exact_dag_cone(uint16_t idx) { if (idx < 6u || g_mark[idx] == g_epoch) return 0u; g_mark[idx] = g_epoch; return (uint8_t)(1u + exact_dag_cone(g_pool[idx].pa) + exact_dag_cone(g_pool[idx].pb)); }
static inline uint8_t exact_pair_gates(uint16_t ia, uint16_t ib) { if (++g_epoch == 0u) { memset(g_mark, 0, sizeof(g_mark)); g_epoch = 1u; } return (uint8_t)(1u + exact_dag_cone(ia) + exact_dag_cone(ib)); }
typedef struct { const char* name; uint64_t plain_tt; uint64_t cry_tt; uint64_t cry_inv_tt; uint32_t best_gates; uint32_t wave_hit; } Tgt6;
static inline uint32_t qt_hash(uint64_t y) {
  uint64_t z = (y ^ (y >> 30)) * 0xbf58476d1ce4e5b9ull; z = (z ^ (z >> 27)) * 0x94d049bb133111ebull; return (uint32_t)((z ^ (z >> 31)) & QT_MASK); }
static void qt_compact_frontier(void) {
  for (uint32_t i = 0; i < QT_SIZE; i++) {
    if (qt_cost[i] != 255u && qt_refs[i] == 0u) {
      qt_cost[i] = 255u; qt_used--; g_gc_reclaimed++;
    }
  }
}
static int qt_observe_cryptic(uint64_t cry_y, uint8_t gates, int pin_ref) {
  if (qt_used > (QT_SIZE * 3u) / 4u) qt_compact_frontier();
  uint32_t h = qt_hash(cry_y);
  for (unsigned probe = 0; probe < 8u; probe++) {
    uint32_t idx = (h + probe) & QT_MASK;
    if (qt_cost[idx] == 255u) { qt_cry_tt[idx] = cry_y; qt_cost[idx] = gates; qt_refs[idx] = (uint8_t)(pin_ref ? 1u : 0u); qt_used++; return 2; }
    if (qt_cry_tt[idx] == cry_y) { g_identities++; g_pruned++; if (gates < qt_cost[idx]) { qt_cost[idx] = gates; if (pin_ref) qt_refs[idx] = 1u; return 2; } return 1; }
  }
  return 0; }
static void build_12_cryptic_targets(const uint64_t v_plain[6], Tgt6 tgts[12]) {
  uint64_t par6 = v_plain[0]^v_plain[1]^v_plain[2]^v_plain[3]^v_plain[4]^v_plain[5];
  uint64_t maj5 = 0ull, ex3 = 0ull, add3_c = 0ull, add3_s2 = 0ull, ge3 = 0ull, mux4 = 0ull, inet6 = 0ull;
  for (unsigned m = 0; m < 64u; m++) {
    unsigned w5 = pop16((uint16_t)(m & 31u)), w6 = pop16((uint16_t)m);
    if (w5 >= 3u) maj5 |= (1ull << m);
    if (w6 == 3u) ex3  |= (1ull << m);
    unsigned a3 = m & 7u, b3 = (m >> 3) & 7u;
    if (a3 + b3 >= 8u) add3_c |= (1ull << m);
    if (((a3 + b3) >> 2) & 1u) add3_s2 |= (1ull << m);
    if (a3 >= b3) ge3 |= (1ull << m);
    unsigned sel = (m >> 4) & 3u; if ((m >> sel) & 1u) mux4 |= (1ull << m);
    unsigned fc = (0xeee0u >> (m & 15u)) & 1u, an = (0x2002u >> (m & 15u)) & 1u;
    if (!fc && (an ^ ((m >> 4) & 1u) ^ ((m >> 5) & 1u))) inet6 |= (1ull << m);
  }
  uint64_t sha_cm = ((v_plain[0]&v_plain[1]) ^ ((~v_plain[0])&v_plain[2])) ^ ((v_plain[3]&v_plain[4]) ^ (v_plain[3]&v_plain[5]) ^ (v_plain[4]&v_plain[5]));
  uint64_t chi6  = (v_plain[0] ^ ((~v_plain[1]) & v_plain[2])) ^ (v_plain[3] ^ ((~v_plain[4]) & v_plain[5]));
  uint64_t y1    = v_plain[1] ^ (v_plain[0] & (v_plain[1] ^ v_plain[2]));
  uint64_t fred6 = y1 ^ (v_plain[3] & (y1 ^ v_plain[4])) ^ v_plain[5];
  uint64_t bent6 = (v_plain[0] & v_plain[1]) ^ (v_plain[2] & v_plain[3]) ^ (v_plain[4] & v_plain[5]);
  const char* nm[12] = {"PARITY6","MAJ5","EXACT3_OF_6","SHA256_CH_XOR_MAJ","ADD3_CARRY","ADD3_SUM2","GE3_3BIT","MUX4_6IN","CUB_INET_SUPER6","KECCAK_CHI_SLICE6","FREDKIN_CASCADE6","BENT6_ROTHAUS"};
  const uint64_t tts[12] = { par6, maj5, ex3, sha_cm, add3_c, add3_s2, ge3, mux4, inet6, chi6, fred6, bent6 };
  for (int i = 0; i < 12; i++) { tgts[i].name = nm[i]; tgts[i].plain_tt = tts[i]; tgts[i].cry_tt = gauge_enc64(tts[i]); tgts[i].cry_inv_tt = gauge_enc64(~tts[i]); tgts[i].best_gates = 99u; tgts[i].wave_hit = 0u; }
}
// Swarm State Broadcaster: synchronizes shard progress & min-gate CRDT certs on /tmp/hx_agent_bus/
static void write_swarm_state(uint32_t wave, uint32_t shard_id, uint32_t num_shards, const Tgt6 tgts[12]) {
  FILE* sf = fopen("/tmp/hx_agent_bus/agent_cryptic_geodesic_000fe7ce_state.json", "w");
  if (!sf) return;
  fprintf(sf, "{\"id\":\"agent_cryptic_geodesic_000fe7ce\",\"kind\":\"agent_coord\",\"kg_slice\":\"cryptic_geodesic_inference_beast\",\"status\":\"unleashed_cryptic_gauge_active\",\"wave\":%u,\"shard\":%u,\"num_shards\":%u,\"gauge_commit\":\"0x%016llx\",\"cryptic_verified\":%llu,\"cryptic_errors\":%llu,\"rss_kib\":%llu,\"min_gates_PAR6\":%u,\"min_gates_SHA_CM\":%u,\"min_gates_CHI6\":%u}\n", wave, shard_id, num_shards, (unsigned long long)g_gauge.key_commit, (unsigned long long)g_cryptic_verified, (unsigned long long)g_cryptic_errors, (unsigned long long)rss_kib(), tgts[0].best_gates, tgts[3].best_gates, tgts[9].best_gates);
  fclose(sf);
}
static void run_geodesic_unleashed(FILE* jlog, FILE* busf, int max_waves, uint32_t shard_id, uint32_t num_shards) {
  memset(qt_cost, 255, sizeof(qt_cost)); qt_used = 0; g_pool_sz = 0;
  const uint64_t vp[6] = { 0xAAAAAAAAAAAAAAAAull, 0xCCCCCCCCCCCCCCCCull, 0xF0F0F0F0F0F0F0F0ull, 0xFF00FF00FF00FF00ull, 0xFFFF0000FFFF0000ull, 0xFFFFFFFF00000000ull };
  Tgt6 tgts[12]; build_12_cryptic_targets(vp, tgts);
  for (unsigned i = 0; i < 6u; i++) {
    uint64_t cv = gauge_enc64(vp[i]);
    g_pool[g_pool_sz] = (GeoNode){ cv, (uint16_t)i, (uint16_t)i, 0u, 0u };
    qt_observe_cryptic(cv, 0u, 1); g_pool_sz++;
  }
  uint64_t t0_us = now_us(); uint32_t cursor_i = 1u, cursor_j = 0u, wave = 2u; uint64_t pair_seq = 0ull;
  uint64_t contractible_steps = 0ull;
  while (g_run && (max_waves <= 0 || (int)wave < max_waves + 2)) {
    for (uint32_t step = 0; step < 120000u && g_run; step++) {
      if (cursor_i >= g_pool_sz) { cursor_i = 1u; cursor_j = 0u; }
      uint32_t ia = cursor_i, ib = cursor_j;
      cursor_j++; if (cursor_j > cursor_i) { cursor_i++; cursor_j = 0u; }
      if (ia >= 16u && num_shards > 1u && ((pair_seq++) % num_shards) != shard_id) continue;
      GeoNode na = g_pool[ia], nb = g_pool[ib];
      uint8_t ng = exact_pair_gates((uint16_t)ia, (uint16_t)ib);
      if (ng > 14u) continue;
      unsigned c1 = wbucket64(na.cry_tt), c2 = wbucket64(nb.cry_tt), c3 = ovclass64(na.cry_tt, nb.cry_tt);
      unsigned ops[4], is_contr = 0u; geo_rank_ops(c1, c2, c3, ops, &is_contr); contractible_steps += is_contr;
      for (unsigned k = 0; k < 4u; k++) {
        unsigned op = ops[k]; unsigned dirs = (op == 2u && ia != ib) ? 2u : 1u;
        for (unsigned sw = 0; sw < dirs; sw++) {
          uint64_t cu = sw ? nb.cry_tt : na.cry_tt, cv = sw ? na.cry_tt : nb.cry_tt;
          uint64_t cry_y = eval64_cryptic_op(op, cu, cv);
          g_evals++; int obs = qt_observe_cryptic(cry_y, ng, 0);
          for (int ti = 0; ti < 12; ti++) {
            uint8_t eff_g = (cry_y == tgts[ti].cry_tt) ? ng : ((cry_y == tgts[ti].cry_inv_tt) ? (uint8_t)(ng + 1u) : 255u);
            if (eff_g < tgts[ti].best_gates) {
              uint64_t dec_y = gauge_dec64(cry_y);
              if (dec_y == tgts[ti].plain_tt || (~dec_y) == tgts[ti].plain_tt) g_cryptic_verified++; else g_cryptic_errors++;
              tgts[ti].best_gates = eff_g; tgts[ti].wave_hit = wave;
              fib3[c1][c2][c3][op]++; fib2[c1][c2][op]++; fib1[c1][op]++; fib0[op]++;
              uint64_t cry_commit = (cry_y ^ g_gauge.key_commit) * 0x9e3779b97f4a7c15ull;
              fprintf(jlog, "{\"event\":\"cryptic_geodesic_discovery\",\"wave\":%u,\"shard\":%u,\"target\":\"%s\",\"dag_gates\":%u,\"cryptic_wire_commit\":\"0x%016llx\"}\n", wave, shard_id, tgts[ti].name, eff_g, (unsigned long long)cry_commit); fflush(jlog);
              if (busf) { fprintf(busf, "{\"channel\":\"hx.swarm.cryptic_geodesic\",\"peer\":\"agent_cryptic_geodesic_000fe7ce\",\"wave\":%u,\"shard\":%u,\"target\":\"%s\",\"min_dag_gates\":%u}\n", wave, shard_id, tgts[ti].name, eff_g); fflush(busf); }
            } }
          if (obs == 2 && g_pool_sz < POOL_CAP && ng <= 9u && g_depth_cnt[ng] < 4096u) {
            g_depth_cnt[ng]++; g_pool[g_pool_sz++] = (GeoNode){ cry_y, (uint16_t)(sw ? ib : ia), (uint16_t)(sw ? ia : ib), (uint8_t)op, ng };
            qt_observe_cryptic(cry_y, ng, 1);
          } } } }
    double dt_s = (double)(now_us() - t0_us) * 1e-6 + 1e-9;
    write_swarm_state(wave, shard_id, num_shards, tgts);
    fprintf(jlog, "{\"event\":\"wave_telemetry\",\"wave\":%u,\"shard\":%u,\"elapsed_s\":%.3f,\"evals\":%llu,\"mevals_s\":%.2f,\"qt_live\":%u,\"pool_sz\":%u,\"pruned\":%llu,\"gc_reclaimed\":%llu,\"contractible_steps\":%llu,\"cryptic_verified\":%llu,\"rss_kib\":%llu,\"best\":{\"PAR6\":%u,\"MAJ5\":%u,\"SHA_CM\":%u,\"ADD3C\":%u,\"GE3\":%u,\"CHI6\":%u,\"FRED6\":%u,\"BENT6\":%u}}\n", wave, shard_id, dt_s, (unsigned long long)g_evals, (double)g_evals / (dt_s * 1e6), qt_used, g_pool_sz, (unsigned long long)g_pruned, (unsigned long long)g_gc_reclaimed, (unsigned long long)contractible_steps, (unsigned long long)g_cryptic_verified, (unsigned long long)rss_kib(), tgts[0].best_gates, tgts[1].best_gates, tgts[3].best_gates, tgts[4].best_gates, tgts[6].best_gates, tgts[9].best_gates, tgts[10].best_gates, tgts[11].best_gates); fflush(jlog);
    wave++; } }
int main(int argc, char** argv) {
  signal(SIGINT, on_sig); signal(SIGTERM, on_sig);
  int max_waves = 0; uint32_t shard_id = 0u, num_shards = 1u;
  const char* log_path = "/tmp/hy_out/beast_geodesic_live.jsonl";
  const char* bus_path = "/tmp/hx_agent_bus/sovereign_wire.jsonl";
  for (int i = 1; i < argc; i++) {
    if (!strcmp(argv[i], "--max-waves") && i + 1 < argc) max_waves = atoi(argv[++i]);
    else if (!strcmp(argv[i], "--log") && i + 1 < argc) log_path = argv[++i];
    else if (!strcmp(argv[i], "--shard") && i + 1 < argc) shard_id = (uint32_t)atoi(argv[++i]);
    else if (!strcmp(argv[i], "--shards") && i + 1 < argc) num_shards = (uint32_t)atoi(argv[++i]);
  }
  init_cryptic_gauge();
  FILE* jlog = fopen(log_path, "a"); if (!jlog) jlog = stdout;
  FILE* busf = fopen(bus_path, "a");
  build_exact_npn_quotient();
  if (g_npn3_classes != 14u || g_npn4_classes != 222u) return 2;
  run_wave01_and_extract_fibers(jlog);
  run_geodesic_unleashed(jlog, busf, max_waves, shard_id, num_shards);
  if (busf) fclose(busf); if (jlog != stdout) fclose(jlog);
  return (g_cryptic_errors == 0ull) ? 0 : 3; }
