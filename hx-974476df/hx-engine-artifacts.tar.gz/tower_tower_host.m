#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <stdio.h>
#include <stdint.h>
#include <sys/time.h>
static double now_ms(void){ struct timeval tv; gettimeofday(&tv,NULL); return tv.tv_sec*1000.0 + tv.tv_usec/1000.0; }
int main(void){
  @autoreleasepool {
    id<MTLDevice> dev = MTLCreateSystemDefaultDevice();
    if (!dev) { printf("No Metal\n"); return 1; }
    NSError* err = nil;
    NSString* src = [NSString stringWithContentsOfFile:@"/home/claude/hxb/out/tower_tower.metal" encoding:NSUTF8StringEncoding error:&err];
    id<MTLLibrary> lib = [dev newLibraryWithSource:src options:nil error:&err];
    if (!lib) { printf("Metal err: %s\n", [[err localizedDescription] UTF8String]); return 1; }
    id<MTLCommandQueue> q = [dev newCommandQueue];
    uint32_t N = 262144u;
    id<MTLBuffer> bS = [dev newBufferWithLength:N*4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> bC = [dev newBufferWithLength:N*4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> bV = [dev newBufferWithLength:N*4 options:MTLResourceStorageModeShared];
    uint32_t* sp = (uint32_t*)[bS contents]; for (uint32_t i=0;i<N;i++) sp[i]=i*2654435761u+7u;
    id<MTLComputePipelineState> p1 = [dev newComputePipelineStateWithFunction:[lib newFunctionWithName:@"tower_gpu_4level"] error:&err];
    double t0 = now_ms();
    id<MTLCommandBuffer> cb = [q commandBuffer]; id<MTLComputeCommandEncoder> en = [cb computeCommandEncoder];
    [en setComputePipelineState:p1]; [en setBuffer:bS offset:0 atIndex:0]; [en setBuffer:bC offset:0 atIndex:1]; [en setBuffer:bV offset:0 atIndex:2];
    [en dispatchThreads:MTLSizeMake(N,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)]; [en endEncoding]; [cb commit]; [cb waitUntilCompleted];
    double dt = now_ms() - t0;
    uint32_t* cp = (uint32_t*)[bC contents]; uint32_t errs = 0u; uint64_t tot_rw = 0;
    for (uint32_t i=0;i<N;i++) { if (cp[i]==9999u || cp[i]==0u) errs++; else tot_rw += cp[i]; }
    double grw = ((double)tot_rw) / (dt * 1e6);
    printf("[TOWER GPU %s] 262,144 REAL INet graph reductions (%llu rewrites) in %.2f ms | %.2f G-rewrites/s | exact_errors=%u (0=exact!)\n", [[dev name] UTF8String], (unsigned long long)tot_rw, dt, grw, errs);
  }
  return 0;
}
