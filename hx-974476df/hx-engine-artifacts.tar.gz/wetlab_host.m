// Generated from lib/hx-wetlab.hypercubical — Apple A18 Pro Exact Zero-Drift Wet-Lab Simulator
#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <stdio.h>
#include <stdint.h>
#include <math.h>
#include <mach/mach_time.h>
static double now_ms(void) {
  static mach_timebase_info_data_t tb = {0,0};
  if (!tb.denom) mach_timebase_info(&tb);
  return (double)mach_absolute_time() * (double)tb.numer / (double)tb.denom / 1e6;
}
int main(void) {
  @autoreleasepool {
    id<MTLDevice> dev = MTLCreateSystemDefaultDevice();
    NSError* err = nil;
    NSString* src = [NSString stringWithContentsOfFile:@"/home/claude/hxb/out/wetlab.metal" encoding:NSUTF8StringEncoding error:&err];
    MTLCompileOptions* opts = [MTLCompileOptions new]; opts.mathMode = MTLMathModeSafe;
    id<MTLLibrary> lib = [dev newLibraryWithSource:src options:opts error:&err];
    if (!lib) { fprintf(stderr, "Metal error: %s\n", [[err localizedDescription] UTF8String]); return 1; }
    id<MTLCommandQueue> q = [dev newCommandQueue];
    id<MTLComputePipelineState> p1 = [dev newComputePipelineStateWithFunction:[lib newFunctionWithName:@"wl_cayley_tunnel_dna"] error:&err];
    id<MTLComputePipelineState> p2 = [dev newComputePipelineStateWithFunction:[lib newFunctionWithName:@"wl_aspirin_flasks"] error:&err];
    id<MTLComputePipelineState> p3 = [dev newComputePipelineStateWithFunction:[lib newFunctionWithName:@"wl_atp_peptide_flasks"] error:&err];
    id<MTLComputePipelineState> p4 = [dev newComputePipelineStateWithFunction:[lib newFunctionWithName:@"wl_stiff_enzyme_fold"] error:&err];
    printf("=== HX-WETLAB EXACT QUANTUM-GEOMETRY -> WET-LAB SIMULATOR (%s) ===\n", [[dev name] UTF8String]);
    // [1] Quantum Proton Tunneling (4,096 barriers x 10,000 exact double-double Cayley SU(2) steps)
    const uint32_t N1 = 4096u, NF = 65536u;
    id<MTLBuffer> b1a = [dev newBufferWithLength:N1*4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> b1b = [dev newBufferWithLength:N1*4 options:MTLResourceStorageModeShared];
    double t0 = now_ms();
    id<MTLCommandBuffer> cb1 = [q commandBuffer]; id<MTLComputeCommandEncoder> e1 = [cb1 computeCommandEncoder];
    [e1 setComputePipelineState:p1]; [e1 setBuffer:b1a offset:0 atIndex:0]; [e1 setBuffer:b1b offset:0 atIndex:1];
    [e1 dispatchThreads:MTLSizeMake(N1,1,1) threadsPerThreadgroup:MTLSizeMake(64,1,1)]; [e1 endEncoding]; [cb1 commit]; [cb1 waitUntilCompleted];
    double dt1 = now_ms() - t0;
    float* p1a = (float*)b1a.contents; float* p1b = (float*)b1b.contents;
    float max_p = 0.0f, max_dr = 0.0f;
    for (uint32_t i = 0; i < N1; i++) { if (p1a[i]>max_p) max_p=p1a[i]; if (p1b[i]>max_dr) max_dr=p1b[i]; }
    printf("[1] DNA Proton Tunneling (4096 x 10K Cayley SU(2) = 40.96M steps) | P_max=%.6f max_norm_drift=%.2e | %.2f ms (%.2f G-steps/s)\n", max_p, max_dr, dt1, 40.96 / dt1);
    // [2] Aspirin Esterification Wet-Lab Optimizer (65,536 flasks)
    id<MTLBuffer> b2a = [dev newBufferWithLength:NF*4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> b2b = [dev newBufferWithLength:NF*4 options:MTLResourceStorageModeShared];
    double t1 = now_ms();
    id<MTLCommandBuffer> cb2 = [q commandBuffer]; id<MTLComputeCommandEncoder> e2 = [cb2 computeCommandEncoder];
    [e2 setComputePipelineState:p2]; [e2 setBuffer:b2a offset:0 atIndex:0]; [e2 setBuffer:b2b offset:0 atIndex:1];
    [e2 dispatchThreads:MTLSizeMake(NF,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)]; [e2 endEncoding]; [cb2 commit]; [cb2 waitUntilCompleted];
    double dt2 = now_ms() - t1;
    float* p2a = (float*)b2a.contents; float* p2b = (float*)b2b.contents;
    float best_asa = 0.0f, max_me2 = 0.0f; uint32_t best2 = 0;
    for (uint32_t i = 0; i < NF; i++) { if (p2a[i]>best_asa){best_asa=p2a[i]; best2=i;} if (p2b[i]>max_me2) max_me2=p2b[i]; }
    printf("[2] Aspirin Esterification (65,536 flasks) | best_yield=%.2f%% at T=%uK Ac2O=%.1feq | max_CHO_err=%.2e | %.2f ms (%.2f M-flasks/s)\n", best_asa*100.0f, 300u+(best2&63u), 1.0f+0.1f*((best2>>6u)&31u), max_me2, dt2, (double)NF/(dt2*1e3));
    // [3] ATP-Driven Peptide Synthesis (65,536 physiological/wet-lab flasks)
    id<MTLBuffer> b3a = [dev newBufferWithLength:NF*4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> b3b = [dev newBufferWithLength:NF*4 options:MTLResourceStorageModeShared];
    double t2 = now_ms();
    id<MTLCommandBuffer> cb3 = [q commandBuffer]; id<MTLComputeCommandEncoder> e3 = [cb3 computeCommandEncoder];
    [e3 setComputePipelineState:p3]; [e3 setBuffer:b3a offset:0 atIndex:0]; [e3 setBuffer:b3b offset:0 atIndex:1];
    [e3 dispatchThreads:MTLSizeMake(NF,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)]; [e3 endEncoding]; [cb3 commit]; [cb3 waitUntilCompleted];
    double dt3 = now_ms() - t2;
    float* p3a = (float*)b3a.contents; float* p3b = (float*)b3b.contents;
    float best_pep = 0.0f, max_me3 = 0.0f; uint32_t best3 = 0;
    for (uint32_t i = 0; i < NF; i++) { if (p3a[i]>best_pep){best_pep=p3a[i]; best3=i;} if (p3b[i]>max_me3) max_me3=p3b[i]; }
    printf("[3] ATP->Peptide Bioenergetics (65,536 flasks) | best_yield=%.2f%% at T=%uK pH=%.1f | max_CHNOP_err=%.2e | %.2f ms (%.2f M-flasks/s)\n", best_pep*100.0f, 285u+(best3&63u), 5.5f+0.1f*(best3>>11u), max_me3, dt3, (double)NF/(dt3*1e3));
    // [4] Stiffness-10^12 Enzyme Catalysis + Thermal Protein Folding (65,536 flasks)
    id<MTLBuffer> b4a = [dev newBufferWithLength:NF*4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> b4b = [dev newBufferWithLength:NF*4 options:MTLResourceStorageModeShared];
    double t3 = now_ms();
    id<MTLCommandBuffer> cb4 = [q commandBuffer]; id<MTLComputeCommandEncoder> e4 = [cb4 computeCommandEncoder];
    [e4 setComputePipelineState:p4]; [e4 setBuffer:b4a offset:0 atIndex:0]; [e4 setBuffer:b4b offset:0 atIndex:1];
    [e4 dispatchThreads:MTLSizeMake(NF,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)]; [e4 endEncoding]; [cb4 commit]; [cb4 waitUntilCompleted];
    double dt4 = now_ms() - t3;
    float* p4a = (float*)b4a.contents; float* p4b = (float*)b4b.contents;
    float best_p4 = 0.0f, max_me4 = 0.0f; uint32_t best4 = 0;
    for (uint32_t i = 0; i < NF; i++) { if (p4a[i]>best_p4){best_p4=p4a[i]; best4=i;} if (p4b[i]>max_me4) max_me4=p4b[i]; }
    printf("[4] Stiff-10^12 Enzyme+Folding (65,536 flasks) | best_prod=%.2f%% at T_opt=%uK (Tm=%.1fK) | max_cons_err=%.2e | %.2f ms (%.2f M-flasks/s)\n", best_p4*100.0f, 275u+(best4&127u), 315.0f+0.1f*(best4>>7u), max_me4, dt4, (double)NF/(dt4*1e3));
    return (max_dr < 1e-6f && max_me2 < 1e-4f && max_me3 < 1e-4f && max_me4 < 1e-5f) ? 0 : 1;
  }
}
