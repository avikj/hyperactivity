/* Mechanically lowered from PolyOptCert + F2OptCert in lib/ir/poly-opt.hypercubical (33rd engine) */
#include <stdint.h>
#include <stdio.h>
static inline void spec_karatsuba(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3;
  out[0] = (v0 * v2);
  out[1] = ((v0 * v3) + (v1 * v2));
  out[2] = (v1 * v3);
}
static inline void opt_karatsuba(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3;
  uint32_t v4 = (v0 * v2);
  uint32_t v5 = (v1 * v3);
  uint32_t v6 = ((v0 + v1) * (v2 + v3));
  out[0] = v4;
  out[1] = ((v6 - v4) - v5);
  out[2] = v5;
}
static inline void spec_gauss_complex(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3;
  out[0] = ((v0 * v2) - (v1 * v3));
  out[1] = ((v0 * v3) + (v1 * v2));
}
static inline void opt_gauss_complex(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3;
  uint32_t v4 = (v0 * (v2 + v3));
  uint32_t v5 = (v3 * (v0 + v1));
  uint32_t v6 = (v2 * (v1 - v0));
  out[0] = (v4 - v5);
  out[1] = (v4 + v6);
}
static inline void spec_horner_cubic(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4;
  out[0] = (v1 + ((v2 * v0) + ((v3 * (v0 * v0)) + (v4 * (v0 * (v0 * v0))))));
}
static inline void opt_horner_cubic(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4;
  out[0] = (v1 + (v0 * (v2 + (v0 * (v3 + (v0 * v4))))));
}
static inline void spec_cayley_su2_err(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t* out) {
  (void)v0; (void)v1; (void)v2;
  uint32_t v3 = ((v0 * v0) * ((v1 * v1) + (v2 * v2)));
  uint32_t v4 = (1u - v3);
  uint32_t v5 = (1u + v3);
  out[0] = (((v4 * v4) + (4u * v3)) - (v5 * v5));
}
static inline void opt_cayley_su2_err(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t* out) {
  (void)v0; (void)v1; (void)v2;
  out[0] = 0u;
}
static inline void spec_brahmagupta_norm(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3;
  uint32_t v4 = ((v0 * v2) - (v1 * v3));
  uint32_t v5 = ((v0 * v3) + (v1 * v2));
  out[0] = ((v4 * v4) + (v5 * v5));
}
static inline void opt_brahmagupta_norm(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3;
  out[0] = (((v0 * v0) + (v1 * v1)) * ((v2 * v2) + (v3 * v3)));
}
static inline void spec_sha256_ch(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t* out) {
  out[0] = ((v0 & v1) ^ ((~v0) & v2));
}
static inline void opt_sha256_ch(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t* out) {
  out[0] = (v2 ^ (v0 & (v1 ^ v2)));
}
static inline void spec_sha256_maj(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t* out) {
  out[0] = (((v0 & v1) ^ (v0 & v2)) ^ (v1 & v2));
}
static inline void opt_sha256_maj(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t* out) {
  out[0] = (v0 ^ ((v0 ^ v1) & (v0 ^ v2)));
}
static inline void spec_full_adder(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t* out) {
  out[0] = ((v0 ^ v1) ^ v2);
  out[1] = (((v0 & v1) | (v0 & v2)) | (v1 & v2));
}
static inline void opt_full_adder(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t* out) {
  uint32_t v3 = (v0 ^ v2);
  uint32_t v4 = (v1 ^ v2);
  out[0] = (v3 ^ v1);
  out[1] = (v2 ^ (v3 & v4));
}
int main(void) {
  uint32_t s[3], c[3], err = 0u;
  uint64_t rng = 0x9e3779b97f4a7c15ULL;
  for (uint32_t i = 0u; i < 100000u; i++) {
    rng ^= rng << 13; rng ^= rng >> 7; rng ^= rng << 17;
    uint32_t x0=(uint32_t)rng, x1=(uint32_t)(rng>>16), x2=(uint32_t)(rng>>32), x3=(uint32_t)(rng>>48), x4=i*2654435761u;
    spec_karatsuba(x0,x1,x2,x3,s); opt_karatsuba(x0,x1,x2,x3,c); if (s[0]!=c[0]||s[1]!=c[1]||s[2]!=c[2]) err++;
    spec_gauss_complex(x0,x1,x2,x3,s); opt_gauss_complex(x0,x1,x2,x3,c); if (s[0]!=c[0]||s[1]!=c[1]) err++;
    spec_horner_cubic(x0,x1,x2,x3,x4,s); opt_horner_cubic(x0,x1,x2,x3,x4,c); if (s[0]!=c[0]) err++;
    spec_cayley_su2_err(x0,x1,x2,s); opt_cayley_su2_err(x0,x1,x2,c); if (s[0]!=c[0]||c[0]!=0u) err++;
    spec_brahmagupta_norm(x0,x1,x2,x3,s); opt_brahmagupta_norm(x0,x1,x2,x3,c); if (s[0]!=c[0]) err++;
    spec_sha256_ch(x0,x1,x2,s); opt_sha256_ch(x0,x1,x2,c); if (s[0]!=c[0]) err++;
    spec_sha256_maj(x0,x1,x2,s); opt_sha256_maj(x0,x1,x2,c); if (s[0]!=c[0]) err++;
    spec_full_adder(x0,x1,x2,s); opt_full_adder(x0,x1,x2,c); if (s[0]!=c[0]||s[1]!=c[1]) err++;
  }
  printf("HX-POLY C11 Differential Verifier: 8/8 certified superopts x 100,000 vectors = 800,000 checks | errors=%u\n", err);
  return err ? 1 : 0;
}
