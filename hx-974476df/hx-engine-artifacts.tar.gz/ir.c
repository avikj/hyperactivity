/* Generated mechanically from KernelIR (lib/ir/kernel-ir.hypercubical) — verified by kir-opt-sound */
#include <stdint.h>
#include <stdio.h>
static inline uint32_t kir_ch(uint32_t x0, uint32_t x1, uint32_t x2) { return (x2 ^ (x0 & (x1 ^ x2))); }
static inline uint32_t kir_maj(uint32_t x0, uint32_t x1, uint32_t x2) { return (x0 ^ ((x0 ^ x1) & (x0 ^ x2))); }
static inline uint32_t kir_cancel(uint32_t x0, uint32_t x1, uint32_t x2) { return 0u; }
int main(void) {
  uint32_t a=0x6a09e667u, b=0xbb67ae85u, c=0x3c6ef372u;
  uint32_t ch = kir_ch(a,b,c), maj = kir_maj(a,b,c), z = kir_cancel(a,b,c);
  uint32_t ref_ch = (a&b)^((~a)&c), ref_maj = (a&b)^(a&c)^(b&c);
  printf("KIR-C11 exact=%d ch=0x%08x maj=0x%08x cancel=%u\n", (ch==ref_ch && maj==ref_maj && z==0u), ch, maj, z);
  return (ch==ref_ch && maj==ref_maj && z==0u) ? 0 : 1;
}
