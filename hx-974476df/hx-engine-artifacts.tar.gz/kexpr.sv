// Generated mechanically by lib/ir/kexpr.hypercubical (hx kexpr, 29th engine)
module hx_kexpr_sha256_core (
  input  logic [31:0] x0, x1, x2,
  output logic [31:0] y_s0, y_s1, y_ch, y_maj, y_t2
);
  assign y_s0  = (({x0[1:0], x0[31:2]} ^ {x0[12:0], x0[31:13]}) ^ {x0[21:0], x0[31:22]});
  assign y_s1  = (({x0[5:0], x0[31:6]} ^ {x0[10:0], x0[31:11]}) ^ {x0[24:0], x0[31:25]});
  assign y_ch  = (x2 ^ (x0 & (x1 ^ x2)));
  assign y_maj = (x0 ^ ((x0 ^ x1) & (x0 ^ x2)));
  assign y_t2  = ((({x0[1:0], x0[31:2]} ^ {x0[12:0], x0[31:13]}) ^ {x0[21:0], x0[31:22]}) + (x0 ^ ((x0 ^ x1) & (x0 ^ x2))));
endmodule
