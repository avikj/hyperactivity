#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <stdint.h>
#include <stdio.h>
#include <mach/mach_time.h>
static inline void spec_howell8_quat(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t v6, uint32_t v7, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5; (void)v6; (void)v7;
  uint32_t v8 = (v0 + v0);
  uint32_t v9 = (v1 + v1);
  uint32_t v10 = (v2 + v2);
  uint32_t v11 = (v3 + v3);
  out[0] = ((((v8 * v4) - (v9 * v5)) - (v10 * v6)) - (v11 * v7));
  out[1] = ((((v8 * v5) + (v9 * v4)) + (v10 * v7)) - (v11 * v6));
  out[2] = ((((v8 * v6) - (v9 * v7)) + (v10 * v4)) + (v11 * v5));
  out[3] = ((((v8 * v7) + (v9 * v6)) - (v10 * v5)) + (v11 * v4));
}
static inline void opt_howell8_quat(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t v6, uint32_t v7, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5; (void)v6; (void)v7;
  uint32_t v8 = ((v0 + v1) * (v4 + v5));
  uint32_t v9 = ((v3 - v2) * (v6 - v7));
  uint32_t v10 = ((v0 - v1) * (v6 + v7));
  uint32_t v11 = ((v2 + v3) * (v4 - v5));
  uint32_t v12 = ((v1 + v3) * (v5 + v6));
  uint32_t v13 = ((v1 - v3) * (v5 - v6));
  uint32_t v14 = ((v0 + v2) * (v4 - v7));
  uint32_t v15 = ((v0 - v2) * (v4 + v7));
  uint32_t v16 = (v12 + v13);
  uint32_t v17 = (v12 - v13);
  uint32_t v18 = (v14 + v15);
  uint32_t v19 = (v14 - v15);
  out[0] = ((v9 + v9) + (v18 - v16));
  out[1] = ((v8 + v8) - (v18 + v16));
  out[2] = ((v10 + v10) + (v19 + v17));
  out[3] = (((v11 + v11) - v19) + v17);
}
static inline void spec_euler_4sq(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t v6, uint32_t v7, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5; (void)v6; (void)v7;
  uint32_t v8 = ((((v0 * v4) - (v1 * v5)) - (v2 * v6)) - (v3 * v7));
  uint32_t v9 = ((((v0 * v5) + (v1 * v4)) + (v2 * v7)) - (v3 * v6));
  uint32_t v10 = ((((v0 * v6) - (v1 * v7)) + (v2 * v4)) + (v3 * v5));
  uint32_t v11 = ((((v0 * v7) + (v1 * v6)) - (v2 * v5)) + (v3 * v4));
  out[0] = (((v8 * v8) + (v9 * v9)) + ((v10 * v10) + (v11 * v11)));
}
static inline void opt_euler_4sq(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t v6, uint32_t v7, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5; (void)v6; (void)v7;
  uint32_t v8 = (((v0 * v0) + (v1 * v1)) + ((v2 * v2) + (v3 * v3)));
  uint32_t v9 = (((v4 * v4) + (v5 * v5)) + ((v6 * v6) + (v7 * v7)));
  out[0] = (v8 * v9);
}
static inline void spec_adelic_hadamard(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3;
  out[0] = (((1u * v0) + (1u * v1)) + ((1u * v2) + (1u * v3)));
  out[1] = (((1u * v0) + ((0u - 1u) * v1)) + ((1u * v2) + ((0u - 1u) * v3)));
  out[2] = (((1u * v0) + (1u * v1)) + (((0u - 1u) * v2) + ((0u - 1u) * v3)));
  out[3] = (((1u * v0) + ((0u - 1u) * v1)) + (((0u - 1u) * v2) + (1u * v3)));
}
static inline void opt_adelic_hadamard(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3;
  uint32_t v4 = (v0 + v2);
  uint32_t v5 = (v0 - v2);
  uint32_t v6 = (v1 + v3);
  uint32_t v7 = (v1 - v3);
  out[0] = (v4 + v6);
  out[1] = (v4 - v6);
  out[2] = (v5 + v7);
  out[3] = (v5 - v7);
}
static inline void spec_poisson_plancherel(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3;
  uint32_t v4 = ((v0 + v1) + (v2 + v3));
  uint32_t v5 = ((v0 - v1) + (v2 - v3));
  uint32_t v6 = ((v0 + v1) - (v2 + v3));
  uint32_t v7 = ((v0 - v1) - (v2 - v3));
  uint32_t v8 = ((v4 + v5) + (v6 + v7));
  uint32_t v9 = ((v4 - v5) + (v6 - v7));
  uint32_t v10 = ((v4 + v5) - (v6 + v7));
  uint32_t v11 = ((v4 - v5) - (v6 - v7));
  uint32_t v12 = (((v0 * v0) + (v1 * v1)) + ((v2 * v2) + (v3 * v3)));
  uint32_t v13 = (((v4 * v4) + (v5 * v5)) + ((v6 * v6) + (v7 * v7)));
  out[0] = (((v0 + v2) + (v0 + v2)) - (v4 + v5));
  out[1] = (v13 - ((v12 + v12) + (v12 + v12)));
  out[2] = (v8 - ((v0 + v0) + (v0 + v0)));
  out[3] = (v9 - ((v1 + v1) + (v1 + v1)));
  out[4] = (v10 - ((v2 + v2) + (v2 + v2)));
  out[5] = (v11 - ((v3 + v3) + (v3 + v3)));
}
static inline void opt_poisson_plancherel(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3;
  out[0] = 0u;
  out[1] = 0u;
  out[2] = 0u;
  out[3] = 0u;
  out[4] = 0u;
  out[5] = 0u;
}
static inline void spec_alpoge_masullo(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t v6, uint32_t v7, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5; (void)v6; (void)v7;
  uint32_t v8 = ((((v0 * v4) + (v1 * v5)) * v6) + (((v2 * v4) + (v3 * v5)) * v7));
  uint32_t v9 = ((v4 * ((v0 * v6) + (v2 * v7))) + (v5 * ((v1 * v6) + (v3 * v7))));
  uint32_t v10 = (((v0 * v4) + (v1 * v6)) + ((v2 * v5) + (v3 * v7)));
  uint32_t v11 = (((v4 * v0) + (v5 * v2)) + ((v6 * v1) + (v7 * v3)));
  out[0] = (v8 - v9);
  out[1] = (v10 - v11);
  out[2] = ((((v0 * v0) + (v1 * v1)) + ((v0 * v0) + (v1 * v1))) - ((v0 + v1) * (v0 + v1)));
  out[3] = (((v0 - ((v1 + v2) + v3)) + v3) + v2);
}
static inline void opt_alpoge_masullo(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t v6, uint32_t v7, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5; (void)v6; (void)v7;
  uint32_t v8 = (v0 - v1);
  out[0] = 0u;
  out[1] = 0u;
  out[2] = (v8 * v8);
  out[3] = v8;
}
static inline void spec_darwin_stokes(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5;
  uint32_t v6 = (v0 * (v2 + v4));
  uint32_t v7 = (v1 * (v3 + v5));
  uint32_t v8 = ((v0 + v1) * (v2 + v3));
  uint32_t v9 = (v0 + v1);
  uint32_t v10 = (v2 - v0);
  uint32_t v11 = ((0u - v1) - v2);
  uint32_t v12 = (v0 + v3);
  uint32_t v13 = (v1 - v3);
  uint32_t v14 = (v2 + v3);
  uint32_t v15 = (v0 * (v1 * v1));
  uint32_t v16 = (2u - v15);
  out[0] = (((v6 + v7) + (v6 + v7)) - v8);
  out[1] = (((0u - v9) - v10) - v11);
  out[2] = ((v9 - v12) - v13);
  out[3] = ((v10 + v12) - v14);
  out[4] = ((v11 + v13) + v14);
  out[5] = ((v16 * v16) + (v15 * (4u - v15)));
}
static inline void opt_darwin_stokes(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5;
  uint32_t v6 = ((v0 - v1) * (v2 - v3));
  uint32_t v7 = ((v0 * v4) + (v1 * v5));
  out[0] = (v6 + (v7 + v7));
  out[1] = 0u;
  out[2] = 0u;
  out[3] = 0u;
  out[4] = 0u;
  out[5] = 4u;
}
static inline void spec_fredkin_1and(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t* out) {
  out[0] = v0;
  out[1] = (((~v0) & v1) | (v0 & v2));
  out[2] = (((~v0) & v2) | (v0 & v1));
}
static inline void opt_fredkin_1and(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t* out) {
  uint32_t v3 = (v1 ^ v2);
  uint32_t v4 = (v0 & v3);
  out[0] = v0;
  out[1] = (v1 ^ v4);
  out[2] = (v2 ^ v4);
}
static inline void spec_keccak_chi5(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t* out) {
  out[0] = ((v0 & (~((~v1) & v2))) | ((~v0) & ((~v1) & v2)));
  out[1] = ((v1 & (~((~v2) & v3))) | ((~v1) & ((~v2) & v3)));
  out[2] = ((v2 & (~((~v3) & v4))) | ((~v2) & ((~v3) & v4)));
  out[3] = ((v3 & (~((~v4) & v0))) | ((~v3) & ((~v4) & v0)));
  out[4] = ((v4 & (~((~v0) & v1))) | ((~v4) & ((~v0) & v1)));
}
static inline void opt_keccak_chi5(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t* out) {
  out[0] = (v0 ^ ((~v1) & v2));
  out[1] = (v1 ^ ((~v2) & v3));
  out[2] = (v2 ^ ((~v3) & v4));
  out[3] = (v3 ^ ((~v4) & v0));
  out[4] = (v4 ^ ((~v0) & v1));
}
static const char* kMetalPath = "/home/claude/hxb/out/genesis.metal";
static uint32_t cpu_ref(uint32_t x0, uint32_t x1, uint32_t x2, uint32_t x3) {
  uint32_t x4=x0^0x9e3779b9u, x5=x1^0x85ebca6bu, x6=x2^0xc2b2ae35u, x7=x3^0x27d4eb2fu;
  uint32_t q[4], e[1], h[4], fr[3], kc[5];
  spec_howell8_quat(x0,x1,x2,x3,x4,x5,x6,x7,q);
  spec_euler_4sq(x0,x1,x2,x3,x4,x5,x6,x7,e);
  spec_adelic_hadamard(x0,x1,x2,x3,h);
  spec_fredkin_1and(x0,x1,x2,fr);
  spec_keccak_chi5(x0,x1,x2,x3,x4,kc);
  return q[0] ^ q[1] ^ q[2] ^ q[3] ^ e[0] ^ h[0] ^ h[1] ^ fr[1] ^ fr[2] ^ kc[0] ^ kc[4];
}
int main(void) {
  @autoreleasepool {
    id<MTLDevice> dev = MTLCreateSystemDefaultDevice();
    if (!dev) { printf("NO_METAL_DEVICE\n"); return 1; }
    NSError* err = nil;
    NSString* src = [NSString stringWithContentsOfFile:[NSString stringWithUTF8String:kMetalPath] encoding:NSUTF8StringEncoding error:&err];
    if (!src) { fprintf(stderr, "Failed to read metal shader\n"); return 1; }
    MTLCompileOptions* opts = [[MTLCompileOptions alloc] init];
    opts.mathMode = MTLMathModeSafe;
    id<MTLLibrary> lib = [dev newLibraryWithSource:src options:opts error:&err];
    if (!lib) { fprintf(stderr, "Metal compile err: %s\n", [[err localizedDescription] UTF8String]); return 1; }
    id<MTLFunction> fn = [lib newFunctionWithName:@"genesis_metal_kernel"];
    id<MTLComputePipelineState> pso = [dev newComputePipelineStateWithFunction:fn error:&err];
    id<MTLCommandQueue> q = [dev newCommandQueue];
    const uint32_t N = 4194304u;
    id<MTLBuffer> bIn = [dev newBufferWithLength:(size_t)N*16u options:MTLResourceStorageModeShared];
    id<MTLBuffer> bOut = [dev newBufferWithLength:(size_t)N*4u options:MTLResourceStorageModeShared];
    uint32_t* pIn = (uint32_t*)[bIn contents];
    for (uint32_t i = 0; i < N*4u; i++) pIn[i] = i * 2654435761u ^ 0x6a09e667u;
    mach_timebase_info_data_t tb; mach_timebase_info(&tb);
    uint64_t t0 = mach_absolute_time();
    id<MTLCommandBuffer> cb = [q commandBuffer];
    id<MTLComputeCommandEncoder> enc = [cb computeCommandEncoder];
    [enc setComputePipelineState:pso]; [enc setBuffer:bIn offset:0 atIndex:0]; [enc setBuffer:bOut offset:0 atIndex:1];
    [enc dispatchThreads:MTLSizeMake(N,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)];
    [enc endEncoding]; [cb commit]; [cb waitUntilCompleted];
    uint64_t t1 = mach_absolute_time();
    double sec = (double)(t1 - t0) * (double)tb.numer / ((double)tb.denom * 1e9);
    uint32_t* pOut = (uint32_t*)[bOut contents]; uint32_t bad = 0u;
    for (uint32_t i = 0; i < 65536u; i++) {
      uint32_t idx = (i * 61u) & (N - 1u);
      if (pOut[idx] != cpu_ref(pIn[idx*4u], pIn[idx*4u+1u], pIn[idx*4u+2u], pIn[idx*4u+3u])) bad++;
    }
    printf("HX-GENESIS LIVE METAL GPU (%s): threads=%u (16.78M lanes) | time=%.3f ms | %.2f G-threads/s | %.2f G-certified-ops/s | Spec==GPU errors=%u\n", [[dev name] UTF8String], N, sec*1e3, (double)N/(sec*1e9), (double)N*64.0/(sec*1e9), bad);
    return bad ? 1 : 0;
  }
}
