// Generated mechanically by lib/ir/kexpr.hypercubical (hx kexpr, 29th engine)
#include <metal_stdlib>
using namespace metal;
inline uint ke_s0(uint x0) { return ((((x0 >> 2u) | (x0 << 30u)) ^ ((x0 >> 13u) | (x0 << 19u))) ^ ((x0 >> 22u) | (x0 << 10u))); }
inline uint ke_s1(uint x0) { return ((((x0 >> 6u) | (x0 << 26u)) ^ ((x0 >> 11u) | (x0 << 21u))) ^ ((x0 >> 25u) | (x0 << 7u))); }
inline uint ke_ch(uint x0, uint x1, uint x2) { return (x2 ^ (x0 & (x1 ^ x2))); }
inline uint ke_maj(uint x0, uint x1, uint x2) { return (x0 ^ ((x0 ^ x1) & (x0 ^ x2))); }
inline uint ke_t2(uint x0, uint x1, uint x2) { return (((((x0 >> 2u) | (x0 << 30u)) ^ ((x0 >> 13u) | (x0 << 19u))) ^ ((x0 >> 22u) | (x0 << 10u))) + (x0 ^ ((x0 ^ x1) & (x0 ^ x2)))); }
kernel void ke_verify(device const uint* in [[buffer(0)]], device uint* out [[buffer(1)]], uint tid [[thread_position_in_grid]]) {
  out[tid] = ke_t2(in[tid*3u], in[tid*3u+1u], in[tid*3u+2u]) ^ ke_s1(in[tid*3u]);
}
