// Mechanically lowered from PolyOptCert + F2OptCert (NVIDIA CUDA sm_90a — identical AST to Metal!)
#include <stdint.h>
__device__ __forceinline__ void opt_karatsuba(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3;
  uint32_t v4 = (v0 * v2);
  uint32_t v5 = (v1 * v3);
  uint32_t v6 = ((v0 + v1) * (v2 + v3));
  out[0] = v4;
  out[1] = ((v6 - v4) - v5);
  out[2] = v5;
}
__device__ __forceinline__ void opt_gauss_complex(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3;
  uint32_t v4 = (v0 * (v2 + v3));
  uint32_t v5 = (v3 * (v0 + v1));
  uint32_t v6 = (v2 * (v1 - v0));
  out[0] = (v4 - v5);
  out[1] = (v4 + v6);
}
__device__ __forceinline__ void opt_horner_cubic(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4;
  out[0] = (v1 + (v0 * (v2 + (v0 * (v3 + (v0 * v4))))));
}
__device__ __forceinline__ void opt_cayley_su2_err(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t* out) {
  (void)v0; (void)v1; (void)v2;
  out[0] = 0u;
}
__device__ __forceinline__ void opt_brahmagupta_norm(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3;
  out[0] = (((v0 * v0) + (v1 * v1)) * ((v2 * v2) + (v3 * v3)));
}
__device__ __forceinline__ void opt_sha256_ch(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t* out) {
  out[0] = (v2 ^ (v0 & (v1 ^ v2)));
}
__device__ __forceinline__ void opt_sha256_maj(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t* out) {
  out[0] = (v0 ^ ((v0 ^ v1) & (v0 ^ v2)));
}
__device__ __forceinline__ void opt_full_adder(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t* out) {
  uint32_t v3 = (v0 ^ v2);
  uint32_t v4 = (v1 ^ v2);
  out[0] = (v3 ^ v1);
  out[1] = (v2 ^ (v3 & v4));
}
__global__ void poly_cuda_bench(const uint32_t* in, uint32_t* out, uint32_t n) {
  uint32_t tid = blockIdx.x * blockDim.x + threadIdx.x; if (tid >= n) return;
  uint32_t a=in[tid*4u], b=in[tid*4u+1u], c=in[tid*4u+2u], d=in[tid*4u+3u]; uint32_t k[3], g[2], f[2];
  opt_karatsuba(a,b,c,d,k); opt_gauss_complex(a,b,c,d,g); opt_full_adder(a,b,c,f);
  out[tid] = k[1] ^ g[0] ^ g[1] ^ f[0] ^ f[1];
}
