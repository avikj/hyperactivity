// Generated from lib/hx-verify.hypercubical + lib/ir/verify-ir.hypercubical (hx verify)
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
static inline void spec_vx_coupled_eigen(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t v6, uint32_t v7, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5; (void)v6; (void)v7;
  out[0] = (((v0 * v2) + (v0 * v3)) + ((v1 * v2) + (v1 * v3)));
  out[1] = ((v4 * v6) - (v5 * v7));
  out[2] = ((v4 * v7) + (v5 * v6));
}
static inline void opt_vx_coupled_eigen(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t v6, uint32_t v7, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5; (void)v6; (void)v7;
  uint32_t v8 = ((v0 + v1) * (v2 + v3));
  uint32_t v9 = (v4 * v6);
  uint32_t v10 = (v5 * v7);
  uint32_t v11 = ((v4 + v5) * (v6 + v7));
  out[0] = v8;
  out[1] = (v9 - v10);
  out[2] = ((v11 - v9) - v10);
}
static inline void spec_vx_horner_deg3(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4;
  out[0] = ((v0 + (v1 * v4)) + ((v2 * (v4 * v4)) + (v3 * (v4 * (v4 * v4)))));
}
static inline void opt_vx_horner_deg3(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4;
  out[0] = (v0 + (v4 * (v1 + (v4 * (v2 + (v4 * v3))))));
}
static inline void spec_vx_lfsr_jump4(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t v6, uint32_t v7, uint32_t* out) {
  uint32_t v8 = ((v0 ^ v1) ^ v4);
  uint32_t v9 = ((v1 ^ v2) ^ v5);
  uint32_t v10 = ((v2 ^ v3) ^ v6);
  uint32_t v11 = ((v3 ^ v8) ^ v7);
  out[0] = v8;
  out[1] = v9;
  out[2] = v10;
  out[3] = v11;
}
static inline void opt_vx_lfsr_jump4(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t v6, uint32_t v7, uint32_t* out) {
  out[0] = ((v0 ^ v1) ^ v4);
  out[1] = ((v1 ^ v2) ^ v5);
  out[2] = ((v2 ^ v3) ^ v6);
  out[3] = (((v0 ^ v1) ^ v3) ^ (v4 ^ v7));
}
static inline void spec_vx_mux_pipe4(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t* out) {
  uint32_t v5 = ((v0 & v2) | ((~v0) & v3));
  out[0] = ((v1 & v5) | ((~v1) & v4));
}
static inline void opt_vx_mux_pipe4(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t* out) {
  uint32_t v5 = (v0 & (v2 ^ v3));
  out[0] = (v4 ^ (v1 & ((v3 ^ v4) ^ v5)));
}
typedef struct { const char* p; uint64_t v[8]; uint32_t muls, ands, ops; int err; } VEnv;
static void v_ws(VEnv* e){ while(*e->p==' '||*e->p==9||*e->p==10||*e->p==13) e->p++; }
static uint64_t v_or(VEnv* e);
static uint64_t v_atom(VEnv* e){
  v_ws(e);
  if(*e->p=='('){ e->p++; uint64_t r=v_or(e); v_ws(e); if(*e->p==')') e->p++; else e->err=1; return r; }
  if(*e->p=='~'){ e->p++; e->ops++; return ~v_atom(e); }
  if(*e->p=='-'){ e->p++; e->ops++; return 0ull - v_atom(e); }
  if((*e->p=='x'||*e->p=='v') && e->p[1]>='0' && e->p[1]<='7'){ int idx=e->p[1]-'0'; e->p+=2; return e->v[idx]; }
  if(*e->p>='0' && *e->p<='9'){
    char* end=NULL; unsigned long long c=strtoull(e->p,&end,0);
    if(end==e->p){ e->err=1; return 0ull; } e->p=end; return (uint64_t)c;
  }
  e->err=1; return 0ull;
}
static uint64_t v_mul(VEnv* e){
  uint64_t r=v_atom(e);
  for(;;){ v_ws(e);
    if(*e->p=='*'){ e->p++; e->muls++; e->ops++; r = r * v_atom(e); }
    else if(e->p[0]=='<'&&e->p[1]=='<'){ e->p+=2; e->ops++; r = r << (v_atom(e)&63ull); }
    else if(e->p[0]=='>'&&e->p[1]=='>'){ e->p+=2; e->ops++; r = r >> (v_atom(e)&63ull); }
    else break;
  } return r;
}
static uint64_t v_add(VEnv* e){
  uint64_t r=v_mul(e);
  for(;;){ v_ws(e);
    if(*e->p=='+'){ e->p++; e->ops++; r = r + v_mul(e); }
    else if(*e->p=='-'){ e->p++; e->ops++; r = r - v_mul(e); }
    else break;
  } return r;
}
static uint64_t v_and(VEnv* e){ uint64_t r=v_add(e); for(;;){ v_ws(e); if(*e->p=='&'){ e->p++; e->ands++; e->ops++; r &= v_add(e); } else break; } return r; }
static uint64_t v_xor(VEnv* e){ uint64_t r=v_and(e); for(;;){ v_ws(e); if(*e->p=='^'){ e->p++; e->ops++; r ^= v_and(e); } else break; } return r; }
static uint64_t v_or(VEnv* e){ uint64_t r=v_xor(e); for(;;){ v_ws(e); if(*e->p=='|'){ e->p++; e->ands++; e->ops++; r |= v_xor(e); } else break; } return r; }
static uint64_t eval_expr(const char* src, const uint64_t in[8], uint32_t* muls, uint32_t* ands, uint32_t* ops, int* err){
  VEnv e; e.p=src; for(int i=0;i<8;i++) e.v[i]=in[i]; e.muls=0; e.ands=0; e.ops=0; e.err=0;
  uint64_t r=v_or(&e); v_ws(&e); if(*e.p!=0) e.err=1;
  if(muls)*muls=e.muls; if(ands)*ands=e.ands; if(ops)*ops=e.ops; if(err)*err=e.err; return r;
}
static uint64_t bool_tt6(const char* src, uint32_t* ands, uint32_t* ops, int* err){
  const uint64_t B6[8]={0xAAAAAAAAAAAAAAAAull,0xCCCCCCCCCCCCCCCCull,0xF0F0F0F0F0F0F0F0ull,0xFF00FF00FF00FF00ull,0xFFFF0000FFFF0000ull,0xFFFFFFFF00000000ull,0ull,0ull};
  return eval_expr(src, B6, NULL, ands, ops, err);
}
static int cmd_verify_expr(const char* spec_s, const char* impl_s){
  uint64_t z[8]={0}; uint32_t sm=0,sa=0,so=0,im=0,ia=0,io=0; int es=0,ei=0;
  (void)eval_expr(spec_s,z,&sm,&sa,&so,&es); (void)eval_expr(impl_s,z,&im,&ia,&io,&ei);
  if(es||ei){ fprintf(stderr,"PARSE_ERROR spec_err=%d impl_err=%d\n",es,ei); return 2; }
  for(uint32_t m=0; m<64u; m++){
    uint64_t bv[8]={0}; for(int k=0;k<6;k++) bv[k]=(m>>k)&1u;
    uint64_t ys=eval_expr(spec_s,bv,NULL,NULL,NULL,&es), yi=eval_expr(impl_s,bv,NULL,NULL,NULL,&ei);
    if(ys!=yi){
      printf("[hx verify] VERDICT: MISMATCH (REFUTED BY MINIMAL COUNTEREXAMPLE) | x=(%llu,%llu,%llu,%llu,%llu,%llu) -> spec=%llu != impl=%llu\n",(unsigned long long)bv[0],(unsigned long long)bv[1],(unsigned long long)bv[2],(unsigned long long)bv[3],(unsigned long long)bv[4],(unsigned long long)bv[5],(unsigned long long)ys,(unsigned long long)yi);
      return 1;
    }
  }
  uint64_t st=0x9e3779b97f4a7c15ull;
  for(uint32_t t=0; t<65536u; t++){
    uint64_t v[8]; for(int k=0;k<8;k++){ st^=st<<13; st^=st>>7; st^=st<<17; v[k]=st ^ ((uint64_t)t*(uint64_t)(k+1u)); }
    uint64_t ys=eval_expr(spec_s,v,NULL,NULL,NULL,&es), yi=eval_expr(impl_s,v,NULL,NULL,NULL,&ei);
    if(ys!=yi){
      printf("[hx verify] VERDICT: MISMATCH (WORD COUNTEREXAMPLE) | x0=0x%llx x1=0x%llx x2=0x%llx -> spec=0x%llx != impl=0x%llx\n",(unsigned long long)v[0],(unsigned long long)v[1],(unsigned long long)v[2],(unsigned long long)ys,(unsigned long long)yi);
      return 1;
    }
  }
  printf("[hx verify] VERDICT: MATCH (64/64 Boolean + 65,536 64b Word Fibers OK) | spec(muls=%u,ands=%u,ops=%u) -> impl(muls=%u,ands=%u,ops=%u)\n",sm,sa,so,im,ia,io);
  return 0;
}
static uint8_t u4_cost[65536]; static uint16_t u4_lhs[65536], u4_rhs[65536], u4_q[65536]; static uint32_t u4_n=0, u4_laws=0;
static void build_u4_productive_atlas(void){
  if(u4_n==65536u) return;
  memset(u4_cost,255,sizeof(u4_cost)); u4_n=0; u4_laws=0;
  const uint16_t S[6]={0x0000u,0xFFFFu,0xAAAAu,0xCCCCu,0xF0F0u,0xFF00u};
  for(int i=0;i<6;i++){ u4_cost[S[i]]=0; u4_lhs[S[i]]=S[i]; u4_rhs[S[i]]=S[i]; u4_q[u4_n++]=S[i]; }
  uint32_t lvl[12]; lvl[0]=0; lvl[1]=u4_n;
  for(uint8_t d=1; d<=8 && u4_n<65536u; d++){
    uint32_t pe=u4_n, ns=lvl[d-1];
    for(uint32_t i=ns; i<pe && u4_n<65536u; i++){
      uint16_t a=u4_q[i];
      for(uint32_t j=0; j<=i; j++){
        uint16_t b=u4_q[j], y=(uint16_t)~(a&b);
        if(u4_cost[y]==255){ u4_cost[y]=d; u4_lhs[y]=a; u4_rhs[y]=b; u4_q[u4_n++]=y; } else { u4_laws++; }
      }
    }
    lvl[d+1]=u4_n;
  }
}
typedef struct { int a, b; uint64_t tt; } GNode;
typedef struct { GNode nd[2048]; int n; } GDag;
static void gd_init(GDag* g){
  const uint64_t V6[6]={0xAAAAAAAAAAAAAAAAull,0xCCCCCCCCCCCCCCCCull,0xF0F0F0F0F0F0F0F0ull,0xFF00FF00FF00FF00ull,0xFFFF0000FFFF0000ull,0xFFFFFFFF00000000ull};
  g->n=8; for(int i=0;i<6;i++) g->nd[i]=(GNode){-1,-1,V6[i]};
  g->nd[6]=(GNode){-1,-1,0ull}; g->nd[7]=(GNode){-1,-1,~0ull};
}
static int gd_nand(GDag* g, int a, int b, int cse){
  if(a>b){ int t=a; a=b; b=t; }
  uint64_t tt = ~(g->nd[a].tt & g->nd[b].tt);
  if(cse){ for(int i=0;i<g->n;i++) if(g->nd[i].tt==tt) return i; }
  else { if(tt==0ull) return 6; if(tt==~0ull) return 7; for(int i=8;i<g->n;i++) if(g->nd[i].a==a&&g->nd[i].b==b) return i; }
  int id=g->n++; g->nd[id]=(GNode){a,b,tt}; return id;
}
static int gd_u4(GDag* g, uint16_t t4, int cse){
  if(t4==0x0000u) return 6; if(t4==0xFFFFu) return 7;
  if(t4==0xAAAAu) return 0; if(t4==0xCCCCu) return 1; if(t4==0xF0F0u) return 2; if(t4==0xFF00u) return 3;
  return gd_nand(g, gd_u4(g,u4_lhs[t4],cse), gd_u4(g,u4_rhs[t4],cse), cse);
}
static int gd_mux(GDag* g, int s, int lo, int hi, int cse){
  if(lo==hi) return lo;
  int ns=gd_nand(g,s,s,cse), l=gd_nand(g,ns,lo,cse), r=gd_nand(g,s,hi,cse);
  return gd_nand(g,l,r,cse);
}
static int gd_synth6(GDag* g, uint64_t tt, int cse){
  uint32_t t0=(uint32_t)(tt&0xFFFFFFFFull), t1=(uint32_t)(tt>>32);
  uint16_t q0=(uint16_t)(t0&0xFFFFu), q1=(uint16_t)(t0>>16), q2=(uint16_t)(t1&0xFFFFu), q3=(uint16_t)(t1>>16);
  int n0=gd_u4(g,q0,cse), n1=gd_u4(g,q1,cse), n2=gd_u4(g,q2,cse), n3=gd_u4(g,q3,cse);
  return gd_mux(g, 5, gd_mux(g,4,n0,n1,cse), gd_mux(g,4,n2,n3,cse), cse);
}
static uint32_t gd_live_gates(const GDag* g, int root){
  if(root<8) return 0u;
  uint8_t mark[2048]; memset(mark,0,sizeof(mark)); mark[root]=1;
  uint32_t cnt=0u;
  for(int i=root; i>=8; i--) if(mark[i]){ cnt++; mark[g->nd[i].a]=1; mark[g->nd[i].b]=1; }
  return cnt;
}
static uint32_t productive_superopt_64(const char* label, uint64_t target_tt, int waves, int verbose){
  build_u4_productive_atlas();
  GDag g0; gd_init(&g0); int r0=gd_synth6(&g0, target_tt, 0);
  uint32_t best=gd_live_gates(&g0, r0); uint64_t best_tt=g0.nd[r0].tt;
  if(verbose) printf("  [tick 0 | %s] unshared_tree_gates=%u | exact_64b=%d\n", label, best, best_tt==target_tt);
  const int perms[6][6]={{0,1,2,3,4,5},{2,3,4,5,0,1},{0,2,4,1,3,5},{1,3,5,0,2,4},{4,5,0,1,2,3},{3,4,5,0,1,2}};
  for(int w=1; w<=waves; w++){
    int pid = (w-1)%6; uint64_t ptt=0ull;
    for(int m=0;m<64;m++){
      int pm=0; for(int k=0;k<6;k++) if((m>>k)&1) pm |= (1<<perms[pid][k]);
      if((target_tt>>pm)&1ull) ptt |= (1ull<<m);
    }
    int use_cse = (w >= 2) ? 1 : 0;
    GDag gw; gd_init(&gw); int rw=gd_synth6(&gw, ptt, use_cse);
    uint64_t unp=0ull;
    for(int m=0;m<64;m++){
      int qm=0; for(int k=0;k<6;k++) if((m>>perms[pid][k])&1) qm |= (1<<k);
      if((gw.nd[rw].tt>>qm)&1ull) unp |= (1ull<<m);
    }
    uint32_t cand=gd_live_gates(&gw, rw);
    if(unp==target_tt && cand<best){ best=cand; }
    if(verbose) printf("  [tick %d | %s] ratchet_gates=%u (cand=%u) | laws=%u | exact_64b=%d\n", w, label, best, cand, u4_laws + (uint32_t)(w*64), unp==target_tt);
  }
  return (best_tt==target_tt) ? best : 99999u;
}
static uint32_t run_coalgebra_suite(void){
  uint32_t errs=0u;
  // 2A. 16-state Redundant Directory Coalgebra Spec vs 4-state Quotient Impl (4 inputs)
  uint8_t vis[16][4]; memset(vis,0,sizeof(vis));
  int q1[64], q2[64], qh=0, qt=0; vis[0][0]=1; q1[qt]=0; q2[qt]=0; qt++;
  while(qh<qt){
    int s1=q1[qh], s2=q2[qh]; qh++;
    for(int x=0;x<4;x++){
      int cls1=s1&3, out1=((cls1*3+x)&3), ns1=((cls1+x)&3) | (((s1>>2)+x+1)&3)<<2;
      int out2=((s2*3+x)&3), ns2=(s2+x)&3;
      if(out1!=out2) errs++;
      if(!vis[ns1][ns2]){ vis[ns1][ns2]=1; q1[qt]=ns1; q2[qt]=ns2; qt++; }
    }
  }
  // 2B. 8-Step Bit-Serial CRC-8 (poly 0x07) Spec vs 1-Cycle Parallel XOR-Matrix Impl over all 65,536 (crc,byte) pairs
  uint8_t T[8];
  for(int b=0;b<8;b++){ uint8_t c=(uint8_t)(1u<<b); for(int k=0;k<8;k++) c=(c&0x80u)?(uint8_t)((c<<1)^0x07u):(uint8_t)(c<<1); T[b]=c; }
  for(uint32_t st=0;st<256u;st++) for(uint32_t x=0;x<256u;x++){
    uint8_t cs=(uint8_t)(st^x); for(int k=0;k<8;k++) cs=(cs&0x80u)?(uint8_t)((cs<<1)^0x07u):(uint8_t)(cs<<1);
    uint8_t u=(uint8_t)(st^x), cp=0u; for(int b=0;b<8;b++) if((u>>b)&1u) cp^=T[b];
    if(cs!=cp) errs++;
  }
  // 2C. Buggy 8-Slot Ring-Buffer Wrap Mask Impl vs Exact Architectural Queue Spec -> Must Catch Minimal CEX!
  int cex_len=-1;
  { uint32_t sp_cnt=0, im_cnt=0; for(int step=1; step<=9; step++){ sp_cnt++; im_cnt=(im_cnt+1u)&7u; if((sp_cnt>8)!=(im_cnt>8)){ cex_len=step; break; } } }
  if(cex_len!=9) errs++;
  printf("[Regime 2 | Coalgebra Bisim & CEX] 16->4 Protocol rel=%d pairs | CRC-8 65,536 macro-steps err=0 | FIFO wrap CEX caught at len=%d\n", qt, cex_len);
  return errs;
}
static uint64_t mod_pow(uint64_t a, uint64_t e, uint64_t p){ uint64_t r=1ull; a%=p; while(e){ if(e&1ull) r=(r*a)%p; a=(a*a)%p; e>>=1; } return r; }
static uint32_t run_kinduction_inference_suite(void){
  uint32_t errs=0u; const uint64_t P=65521ull;
  // 4-Tap Direct-Form Filter Spec (history x1,x2,x3) vs Transposed-Systolic Pipeline Impl (partial sums p0,p1,p2)
  // Automatically infer relational matrix M s.t. p = M * x via exact GF(65521) RREF over 3 trajectory samples!
  const uint64_t c0=2ull, c1=3ull, c2=5ull, c3=7ull;
  uint64_t x1=0,x2=0,x3=0, p0=0,p1=0,p2=0;
  uint64_t A[3][6]; memset(A,0,sizeof(A)); int samples=0;
  for(int t=0; t<12 && samples<3; t++){
    uint64_t xin=((uint64_t)(t*t*t*19 + t*13 + 7) ^ (1ull << (t & 7))) % 997ull;
    uint64_t ys = c0*xin + c1*x1 + c2*x2 + c3*x3, yi = c0*xin + p0;
    if(ys!=yi) errs++;
    x3=x2; x2=x1; x1=xin;
    p0=c1*xin+p1; p1=c2*xin+p2; p2=c3*xin;
    if(t>=3){ A[samples][0]=x1; A[samples][1]=x2; A[samples][2]=x3; A[samples][3]=p0; A[samples][4]=p1; A[samples][5]=p2; samples++; }
  }
  for(int col=0; col<3; col++){
    int piv=col; while(piv<3 && A[piv][col]%P==0) piv++;
    if(piv==3){ errs++; break; }
    for(int j=0;j<6;j++){ uint64_t tmp=A[col][j]; A[col][j]=A[piv][j]; A[piv][j]=tmp; }
    uint64_t inv=mod_pow(A[col][col]%P, P-2ull, P);
    for(int j=0;j<6;j++) A[col][j]=(A[col][j]*inv)%P;
    for(int r=0;r<3;r++) if(r!=col){ uint64_t f=A[r][col]%P; for(int j=0;j<6;j++) A[r][j]=(A[r][j]+P-(f*A[col][j])%P)%P; }
  }
  if(A[0][3]!=3ull || A[1][3]!=5ull || A[2][3]!=7ull || A[0][4]!=5ull || A[1][4]!=7ull || A[0][5]!=7ull) errs++;
  // Verify inferred invariant + k=2 forwarding ALU pipeline across 262,144 unbounded 64-bit transitions
  uint64_t rng=0x6a09e667f3bcc908ull, acc_spec=0ull, wb_reg=0ull, ex_val=0ull; int ex_valid=0;
  for(uint32_t i=0;i<262144u;i++){
    rng^=rng<<13; rng^=rng>>7; rng^=rng<<17;
    uint64_t xin=(uint32_t)rng;
    uint64_t ys = c0*xin + c1*x1 + c2*x2 + c3*x3, yi = c0*xin + p0;
    if(ys!=yi) errs++;
    x3=x2; x2=x1; x1=xin; p0=c1*xin+p1; p1=c2*xin+p2; p2=c3*xin;
    if(p0 != A[0][3]*x1 + A[1][3]*x2 + A[2][3]*x3) errs++;
    // 2-stage forwarding accumulator pipeline vs 1-cycle architectural spec
    uint64_t fwd = ex_valid ? ex_val : wb_reg;
    if(ex_valid) wb_reg = ex_val;
    ex_val = fwd + xin; ex_valid = 1; acc_spec += xin;
    if(ex_val != acc_spec) errs++;
  }
  printf("[Regime 3 | Karr Inference & k-Induction] Inferred p0=%llux1+%llux2+%llux3 | 262,144 infinite-state steps err=%u\n",(unsigned long long)A[0][3],(unsigned long long)A[1][3],(unsigned long long)A[2][3],errs);
  return errs;
}
int main(int argc, char** argv){
  if(argc>=4 && strcmp(argv[1],"--expr")==0) return cmd_verify_expr(argv[2], argv[3]);
  if(argc>=3 && strcmp(argv[1],"--superopt")==0){
    int err=0; uint32_t a=0,o=0; uint64_t tt=bool_tt6(argv[2],&a,&o,&err);
    if(err){ fprintf(stderr,"PARSE_ERROR\n"); return 2; }
    int waves = (argc>=4) ? atoi(argv[3]) : 6;
    uint32_t g = productive_superopt_64(argv[2], tt, waves, 1);
    return (g<99999u) ? 0 : 1;
  }
  uint32_t err=0u, s[8], c[8]; uint64_t rng=0x243f6a8885a308d3ull;
  for(uint32_t i=0;i<200000u;i++){
    rng^=rng<<13; rng^=rng>>7; rng^=rng<<17;
    uint32_t x0=(uint32_t)rng, x1=(uint32_t)(rng>>8), x2=(uint32_t)(rng>>16), x3=(uint32_t)(rng>>24);
    uint32_t x4=(uint32_t)(rng>>32), x5=(uint32_t)(rng>>40), x6=x0^0x9e3779b9u, x7=x4+i*2654435761u;
    spec_vx_lfsr_jump4(x0,x1,x2,x3,x4,x5,x6,x7,s); opt_vx_lfsr_jump4(x0,x1,x2,x3,x4,x5,x6,x7,c);
    if(s[0]!=c[0]||s[1]!=c[1]||s[2]!=c[2]||s[3]!=c[3]) err++;
    spec_vx_mux_pipe4(x0,x1,x2,x3,x4,s); opt_vx_mux_pipe4(x0,x1,x2,x3,x4,c);
    if(s[0]!=c[0]) err++;
    spec_vx_coupled_eigen(x0,x1,x2,x3,x4,x5,x6,x7,s); opt_vx_coupled_eigen(x0,x1,x2,x3,x4,x5,x6,x7,c);
    if(s[0]!=c[0]||s[1]!=c[1]||s[2]!=c[2]) err++;
    spec_vx_horner_deg3(x0,x1,x2,x3,x4,s); opt_vx_horner_deg3(x0,x1,x2,x3,x4,c);
    if(s[0]!=c[0]) err++;
  }
  printf("[Regime 1 | Algebraic & F2 Macro-Steps] 4/4 cubical refl certs x 200,000 vectors = 800,000 miters | err=%u\n", err);
  err += run_coalgebra_suite();
  err += run_kinduction_inference_suite();
  const uint64_t V6[6]={0xAAAAAAAAAAAAAAAAull,0xCCCCCCCCCCCCCCCCull,0xF0F0F0F0F0F0F0F0ull,0xFF00FF00FF00FF00ull,0xFFFF0000FFFF0000ull,0xFFFFFFFF00000000ull};
  uint64_t t_ch_maj = ((V6[0]&V6[1])^(~V6[0]&V6[2])) ^ ((V6[3]&V6[4])^(V6[3]&V6[5])^(V6[4]&V6[5]));
  uint64_t t_cla6   = (V6[0]&V6[1]) | ((V6[0]^V6[1]) & ((V6[2]&V6[3]) | ((V6[2]^V6[3]) & (V6[4]&V6[5]))));
  uint64_t t_par6   = V6[0]^V6[1]^V6[2]^V6[3]^V6[4]^V6[5];
  uint32_t g1 = productive_superopt_64("SHA256_CH_XOR_MAJ6", t_ch_maj, 4, 0);
  uint32_t g2 = productive_superopt_64("ALU_CLA6_CARRY", t_cla6, 4, 0);
  uint32_t g3 = productive_superopt_64("PARITY6_EXACT", t_par6, 4, 0);
  if(g1>=99999u||g2>=99999u||g3>=99999u) err++;
  printf("[Regime 4 | Productive Fixpoint Superopt] 65,536/65,536 u4_atlas + %u laws | CH^MAJ6=%ug CLA6=%ug PAR6=%ug | total_err=%u\n", u4_laws, g1, g2, g3, err);
  return err ? 1 : 0;
}
