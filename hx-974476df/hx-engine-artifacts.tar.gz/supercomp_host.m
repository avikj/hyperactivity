// Generated from lib/hx-supercomp.hypercubical — Apple A18 Pro Supercomputer Fabric Bench
#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <stdio.h>
#include <stdint.h>
#include <math.h>
#include <mach/mach_time.h>
static double now_ms(void) {
  static mach_timebase_info_data_t tb = {0,0};
  if (!tb.denom) mach_timebase_info(&tb);
  return (double)mach_absolute_time() * (double)tb.numer / (double)tb.denom / 1e6;
}
int main(void) {
  @autoreleasepool {
    id<MTLDevice> dev = MTLCreateSystemDefaultDevice();
    NSError* err = nil;
    NSString* src = [NSString stringWithContentsOfFile:@"/home/claude/hxb/out/supercomp.metal" encoding:NSUTF8StringEncoding error:&err];
    id<MTLLibrary> lib = [dev newLibraryWithSource:src options:nil error:&err];
    if (!lib) { fprintf(stderr, "Metal compile error: %s\n", [[err localizedDescription] UTF8String]); return 1; }
    id<MTLCommandQueue> q = [dev newCommandQueue];
    id<MTLComputePipelineState> p_dor = [dev newComputePipelineStateWithFunction:[lib newFunctionWithName:@"sc_dor_1m_verify"] error:&err];
    id<MTLComputePipelineState> p_ar  = [dev newComputePipelineStateWithFunction:[lib newFunctionWithName:@"sc_allreduce_hop"] error:&err];
    id<MTLComputePipelineState> p_wc  = [dev newComputePipelineStateWithFunction:[lib newFunctionWithName:@"sc_wire_codec_bf16"] error:&err];
    id<MTLComputePipelineState> p_opt = [dev newComputePipelineStateWithFunction:[lib newFunctionWithName:@"sc_dc_opt_next_dc"] error:&err];
    printf("=== HX-SUPERCOMP LIVE GPU FABRIC VERIFIER (%s) ===\n", [[dev name] UTF8String]);
    // 1. 1,048,576-Node (DIM=20) DOR Verification across 65,536 cross-bisection flows
    const uint32_t NF = 65536u;
    id<MTLBuffer> b_src = [dev newBufferWithLength:NF*4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> b_dst = [dev newBufferWithLength:NF*4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> b_hop = [dev newBufferWithLength:NF*4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> b_err = [dev newBufferWithLength:4 options:MTLResourceStorageModeShared];
    uint32_t* ps = (uint32_t*)b_src.contents; uint32_t* pd = (uint32_t*)b_dst.contents;
    for (uint32_t i = 0; i < NF; i++) {
      ps[i] = (i * 2654435761u) & 0xFFFFFu;
      pd[i] = ((i * 2246822519u) ^ 0xFFFFFu) & 0xFFFFFu;
    }
    *(uint32_t*)b_err.contents = 0u;
    double t0 = now_ms();
    id<MTLCommandBuffer> cb1 = [q commandBuffer]; id<MTLComputeCommandEncoder> e1 = [cb1 computeCommandEncoder];
    [e1 setComputePipelineState:p_dor]; [e1 setBuffer:b_src offset:0 atIndex:0];
    [e1 setBuffer:b_dst offset:0 atIndex:1]; [e1 setBuffer:b_hop offset:0 atIndex:2]; [e1 setBuffer:b_err offset:0 atIndex:3];
    [e1 dispatchThreads:MTLSizeMake(NF,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)]; [e1 endEncoding]; [cb1 commit]; [cb1 waitUntilCompleted];
    double dt1 = now_ms() - t0;
    uint64_t tot_hops = 0; uint32_t* ph = (uint32_t*)b_hop.contents; uint32_t max_h = 0;
    for (uint32_t i = 0; i < NF; i++) { tot_hops += ph[i]; if (ph[i] > max_h) max_h = ph[i]; }
    uint32_t dor_err = *(uint32_t*)b_err.contents;
    printf("[1] DOR 1,048,576-node (d=20) | flows=%u tot_hops=%llu max_hop=%u deadlocks=%u | %.3f ms (%.2f M-hops/s)\n", NF, tot_hops, max_h, dor_err, dt1, (double)tot_hops / (dt1 * 1e3));
    // 2. 20-Hop Recursive Halving-Doubling AllReduce across 1,048,576 Virtual Ranks
    const uint32_t NR = 1048576u;
    id<MTLBuffer> b_a = [dev newBufferWithLength:NR*4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> b_b = [dev newBufferWithLength:NR*4 options:MTLResourceStorageModeShared];
    float* fa = (float*)b_a.contents;
    for (uint32_t i = 0; i < NR; i++) fa[i] = 1.0f;
    double t1 = now_ms();
    id<MTLCommandBuffer> cb2 = [q commandBuffer]; id<MTLComputeCommandEncoder> e2 = [cb2 computeCommandEncoder];
    [e2 setComputePipelineState:p_ar];
    for (uint32_t d = 0; d < 20u; d++) {
      uint32_t st = 1u << d;
      [e2 setBuffer:(d&1)?b_b:b_a offset:0 atIndex:0]; [e2 setBuffer:(d&1)?b_a:b_b offset:0 atIndex:1];
      [e2 setBytes:&st length:4 atIndex:2];
      [e2 dispatchThreads:MTLSizeMake(NR,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)];
    }
    [e2 endEncoding]; [cb2 commit]; [cb2 waitUntilCompleted];
    double dt2 = now_ms() - t1;
    float ar0 = fa[0], ar_last = fa[NR-1];
    int ar_ok = (ar0 == 1048576.0f && ar_last == 1048576.0f);
    printf("[2] AllReduce 1,048,576 ranks (20 hops vs Ring 2,097,150 = 104,857x) | sum=%.0f exact=%d | %.3f ms\n", ar0, ar_ok, dt2);
    // 3. 4,194,304-Weight (1,048,576 4-lane packets) Bit-Exact 48b<->64b Optical Wire Codec
    const uint32_t NP = 1048576u;
    id<MTLBuffer> b_in = [dev newBufferWithLength:NP*8 options:MTLResourceStorageModeShared];
    id<MTLBuffer> b_lo = [dev newBufferWithLength:NP*4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> b_hi = [dev newBufferWithLength:NP*2 options:MTLResourceStorageModeShared];
    uint16_t* pw = (uint16_t*)b_in.contents;
    for (uint32_t i = 0; i < NP*4u; i++) {
      uint16_t s = (uint16_t)((i * 17u) & 1u);
      uint16_t e = (uint16_t)(120u + ((i * 31u) & 15u));
      uint16_t m = (uint16_t)((i * 73u) & 0x7Fu);
      pw[i] = (uint16_t)((s << 15) | (e << 7) | m);
    }
    *(uint32_t*)b_err.contents = 0u;
    double t2 = now_ms();
    id<MTLCommandBuffer> cb3 = [q commandBuffer]; id<MTLComputeCommandEncoder> e3 = [cb3 computeCommandEncoder];
    [e3 setComputePipelineState:p_wc]; [e3 setBuffer:b_in offset:0 atIndex:0];
    [e3 setBuffer:b_lo offset:0 atIndex:1]; [e3 setBuffer:b_hi offset:0 atIndex:2]; [e3 setBuffer:b_err offset:0 atIndex:3];
    [e3 dispatchThreads:MTLSizeMake(NP,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)]; [e3 endEncoding]; [cb3 commit]; [cb3 waitUntilCompleted];
    double dt3 = now_ms() - t2;
    uint32_t wc_err = *(uint32_t*)b_err.contents;
    double gbps = ((double)NP * 8.0) / (dt3 * 1e6);
    printf("[3] Wire-Codec 48b<->64b BF16 | weights=4,194,304 bit_errors=%u ratio=1.333x (-25%% optics) | %.3f ms (%.2f GB/s)\n", wc_err, dt3, gbps);
    // 4. Parametric 5-Tier Supercomputer Contract Table (d = 0, 4, 10, 17, 20)
    printf("--- COMPILED SUPERCOMPUTER CONTRACT TIERS (1 PSC-1 = 128GB HBM, 2 PFLOP/s FP8, 1.333x Wire Codec) ---\n");
    const int dims[5] = {0, 4, 10, 17, 20};
    const char* names[5] = {"PSC-1 Personal", "HX-Rack16", "HX-Pod1K", "HX-Colossus131K", "HX-Zetta1M"};
    for (int i = 0; i < 5; i++) {
      int d = dims[i]; uint64_t N = 1ULL << d; uint64_t bis = (d==0)?0ULL:(1ULL<<(d-1));
      double hbm_tb = (double)N * 0.128; double fp8_ef = (double)N * 0.002;
      double eff_bis_pbps = (double)bis * 0.8 * (4.0/3.0) / 1000.0; // 800Gbps raw -> 1.067Tbps eff per link
      printf("  d=%2d %-16s | N=%7llu | HBM=%8.1f TB | FP8=%7.2f EFLOP/s | Bisect=%6llu links (%.1f PB/s eff) | AR=%2d hops\n", d, names[i], N, hbm_tb, fp8_ef, bis, eff_bis_pbps, d);
    }
    // 5. CLOSED-LOOP SELF-OPTIMIZING DATACENTER (Gen 0 -> Gen 4, 1,048,576 candidate machines/gen on GPU!)
    printf("--- CLOSED-LOOP DATACENTER(g) -> DATACENTER(g+1) RECURSIVE SELF-OPTIMIZATION (1,048,576 configs/gen) ---\n");
    const uint32_t NC = 1048576u;
    id<MTLBuffer> b_gp = [dev newBufferWithLength:16 options:MTLResourceStorageModeShared];
    id<MTLBuffer> b_sc = [dev newBufferWithLength:NC*4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> b_cf = [dev newBufferWithLength:NC*4 options:MTLResourceStorageModeShared];
    uint32_t cur_gate = 260u, cur_pj = 200u, prev_best = 0xFFFFFFFFu; int mono_ok = 1;
    for (uint32_t g = 0; g < 5u; g++) {
      uint32_t* gp = (uint32_t*)b_gp.contents; gp[0] = g; gp[1] = cur_gate; gp[2] = cur_pj; gp[3] = 0u;
      double tg = now_ms();
      id<MTLCommandBuffer> cbg = [q commandBuffer]; id<MTLComputeCommandEncoder> eg = [cbg computeCommandEncoder];
      [eg setComputePipelineState:p_opt]; [eg setBuffer:b_gp offset:0 atIndex:0];
      [eg setBuffer:b_sc offset:0 atIndex:1]; [eg setBuffer:b_cf offset:0 atIndex:2];
      [eg dispatchThreads:MTLSizeMake(NC,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)]; [eg endEncoding]; [cbg commit]; [cbg waitUntilCompleted];
      double dtg = now_ms() - tg;
      uint32_t* sc = (uint32_t*)b_sc.contents; uint32_t best = 0xFFFFFFFFu, best_id = 0u;
      for (uint32_t k = 0; k < NC; k++) if (sc[k] < best) { best = sc[k]; best_id = k; }
      if (best > prev_best) mono_ok = 0;
      prev_best = best;
      uint32_t go = best_id & 0xFu, wm = (best_id >> 4u) & 3u, tc = (best_id >> 6u) & 0xFu;
      cur_gate = (cur_gate > go*8u) ? (cur_gate - go*8u) : 40u; cur_pj = (cur_pj * 4u) / 5u;
      printf("  Gen %u -> Gen %u | best_cost=%3u pJ-eq | gate_opt=%2u wire_48b=%u sc_Tc_lvl=%2u | %.2f ms (%.2f G-machines/s)\n", g, g+1u, best, go, (wm==3u)?1u:0u, tc, dtg, (double)NC / (dtg * 1e6));
    }
    return (dor_err == 0u && ar_ok && wc_err == 0u && mono_ok) ? 0 : 1;
  }
}
