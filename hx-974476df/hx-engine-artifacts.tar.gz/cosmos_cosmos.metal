// Generated from lib/hx-cosmos.hypercubical — Apple Silicon Metal GPU Manifold + CBF Verifier
#include <metal_stdlib>
using namespace metal;

// Kernel 1: 65,536-Candidate Parallel Non-Planar Manifold Wire-Energy Search (2D vs 3D SoIC vs Optical)
kernel void cos_metal_manifold_search(
  device const uint* edges_u [[buffer(0)]],
  device const uint* edges_v [[buffer(1)]],
  device float* out_energy   [[buffer(2)]],
  constant uint& n_edges     [[buffer(3)]],
  constant uint& mode        [[buffer(4)]],
  uint tid [[thread_position_in_grid]]) {
  uint key = tid * 2654435761u + 17u;
  uint rot = tid & 11u;
  float energy = 0.0f;
  for (uint e = 0u; e < n_edges; e++) {
    uint u = ((edges_u[e] ^ key) << rot | (edges_u[e] ^ key) >> (12u - rot)) & 4095u;
    uint v = ((edges_v[e] ^ key) << rot | (edges_v[e] ^ key) >> (12u - rot)) & 4095u;
    if (mode == 0u) {
      int dx = abs((int)(u & 63u) - (int)(v & 63u));
      int dy = abs((int)(u >> 6u) - (int)(v >> 6u));
      energy += (float)(dx + dy);
    } else if (mode == 1u) {
      int dx = abs((int)(u & 15u) - (int)(v & 15u));
      int dy = abs((int)((u >> 4u) & 15u) - (int)((v >> 4u) & 15u));
      int dz = abs((int)(u >> 8u) - (int)(v >> 8u));
      energy += (float)(dx + dy) + 0.35f * (float)dz;
    } else {
      energy += (float)popcount(u ^ v);
    }
  }
  out_energy[tid] = energy / (float)n_edges;
}

// Kernel 2: 65,536-Trajectory Adversarial Coupled Two-Agent CBF Reachability Stress Verifier
kernel void cos_metal_cbf_reach(
  device atomic_uint* viol_cnt [[buffer(0)]],
  device float* min_margin_out [[buffer(1)]],
  uint tid [[thread_position_in_grid]]) {
  uint s = tid * 747796405u + 2891336453u;
  float x = 0.25f + 0.75f * (float)(tid & 1023u) / 1023.0f;
  const float safe_min = 0.20f, eps_tot = 0.01906f, d_max = 0.12f;
  const float floor_cbf = safe_min + eps_tot + d_max;
  float mn = x;
  for (uint t = 0u; t < 256u; t++) {
    s = s * 1664525u + 1013904223u;
    float d = (((float)(s >> 8u) / 16777216.0f) * 2.0f - 1.0f) * d_max;
    float u_des = -0.40f * (x - 0.02f);
    float u_act = max(u_des, floor_cbf - x);
    x = x + u_act + d;
    if (x < mn) mn = x;
    if (x < safe_min) atomic_fetch_add_explicit(viol_cnt, 1u, memory_order_relaxed);
  }
  min_margin_out[tid] = mn;
}
