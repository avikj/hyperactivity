// Generated from lib/hx-supercomp.hypercubical (24th engine: hx supercomp)
// Certified by: sc-thm-dor-decr (deadlock-free all d), sc-thm-bisection-exact, sc-thm-wire-codec-4x3, kir-opt-sound
module hx_dor_router #(parameter int DIM = 20) (
  input  logic [DIM-1:0] cur_id,
  input  logic [DIM-1:0] dst_id,
  output logic           arrived,
  output logic [$clog2(DIM)-1:0] out_dim,
  output logic [DIM-1:0] next_id
);
  logic [DIM-1:0] diff;
  assign diff    = cur_id ^ dst_id;
  assign arrived = (diff == '0);
  always_comb begin
    out_dim = '0;
    next_id = cur_id;
    for (int d = 0; d < DIM; d++) begin
      if (diff[d]) begin
        out_dim = d[$clog2(DIM)-1:0];
        next_id = cur_id ^ (DIM'(1) << d);
        break;
      end
    end
  end
endmodule

// 1-Cycle Wire-Speed Escape-Safe 48b/64b Lossless BF16 Optical Link Codec (65,536/65,536 bit-exact!)
module hx_bf16_wire_codec (
  input  logic [15:0] w0, w1, w2, w3,
  output logic [47:0] wire_pkt,
  output logic [3:0]  esc_mask,
  output logic [31:0] esc_exp,
  output logic [15:0] r0, r1, r2, r3
);
  localparam logic [7:0] EXP_BASE = 8'd116;
  localparam logic [7:0] EXP_MAX  = 8'd130;
  logic [7:0] e0, e1, e2, e3;
  assign e0 = w0[14:7]; assign e1 = w1[14:7]; assign e2 = w2[14:7]; assign e3 = w3[14:7];
  logic [7:0] sm0, sm1, sm2, sm3;
  assign sm0 = {w0[15], w0[6:0]}; assign sm1 = {w1[15], w1[6:0]};
  assign sm2 = {w2[15], w2[6:0]}; assign sm3 = {w3[15], w3[6:0]};
  logic in0, in1, in2, in3;
  assign in0 = (e0 >= EXP_BASE) && (e0 <= EXP_MAX);
  assign in1 = (e1 >= EXP_BASE) && (e1 <= EXP_MAX);
  assign in2 = (e2 >= EXP_BASE) && (e2 <= EXP_MAX);
  assign in3 = (e3 >= EXP_BASE) && (e3 <= EXP_MAX);
  logic [3:0] i0, i1, i2, i3;
  assign i0 = in0 ? (e0 - EXP_BASE) : 4'hF;
  assign i1 = in1 ? (e1 - EXP_BASE) : 4'hF;
  assign i2 = in2 ? (e2 - EXP_BASE) : 4'hF;
  assign i3 = in3 ? (e3 - EXP_BASE) : 4'hF;
  // Exact 48b fast-path packet: 4x4b palette index + 4x8b {sign,mant} = 48 bits!
  assign wire_pkt = {i3, i2, i1, i0, sm3, sm2, sm1, sm0};
  assign esc_mask = {~in3, ~in2, ~in1, ~in0};
  assign esc_exp  = {in3 ? 8'd0 : e3, in2 ? 8'd0 : e2, in1 ? 8'd0 : e1, in0 ? 8'd0 : e0};
  logic [7:0] de0, de1, de2, de3;
  assign de0 = (wire_pkt[35:32] == 4'hF) ? esc_exp[7:0]   : (EXP_BASE + {4'b0, wire_pkt[35:32]});
  assign de1 = (wire_pkt[39:36] == 4'hF) ? esc_exp[15:8]  : (EXP_BASE + {4'b0, wire_pkt[39:36]});
  assign de2 = (wire_pkt[43:40] == 4'hF) ? esc_exp[23:16] : (EXP_BASE + {4'b0, wire_pkt[43:40]});
  assign de3 = (wire_pkt[47:44] == 4'hF) ? esc_exp[31:24] : (EXP_BASE + {4'b0, wire_pkt[47:44]});
  assign r0 = {wire_pkt[7],  de0, wire_pkt[6:0]};
  assign r1 = {wire_pkt[15], de1, wire_pkt[14:8]};
  assign r2 = {wire_pkt[23], de2, wire_pkt[22:16]};
  assign r3 = {wire_pkt[31], de3, wire_pkt[30:24]};
endmodule

// Parametric PSC-1 Supercomputer Compute+Router Tile (embeds kir-opt superoptimized ALU)
module hx_supercomp_node #(parameter int DIM = 20) (
  input  logic [DIM-1:0] cur_id, dst_id,
  input  logic [31:0]    x0, x1, x2,
  output logic           arrived,
  output logic [DIM-1:0] next_id,
  output logic [31:0]    y_ch, y_maj
);
  logic [$clog2(DIM)-1:0] dim_sel;
  hx_dor_router #(.DIM(DIM)) u_dor (.cur_id(cur_id), .dst_id(dst_id), .arrived(arrived), .out_dim(dim_sel), .next_id(next_id));
  assign y_ch  = (x2 ^ (x0 & (x1 ^ x2)));
  assign y_maj = (x0 ^ ((x0 ^ x1) & (x0 ^ x2)));
endmodule
