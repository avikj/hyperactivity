#include <metal_stdlib>
using namespace metal;
struct HxpCell64 {
  ulong hdr_seq; ulong port_wire; ulong val_a; ulong val_b;
  ulong quote_phi; ulong fiber_ep; ulong key_ref; ulong mac_tag;
};
static inline uint tonnetz_op(uint t, uint op) {
  uint r = t >> 1u, m = t & 1u;
  if (op == 0u) return (r << 1u) | (m ^ 1u);
  if (op == 1u) return (((m == 0u) ? ((r + 4u) % 12u) : ((r + 8u) % 12u)) << 1u) | (m ^ 1u);
  return (((m == 0u) ? ((r + 9u) % 12u) : ((r + 3u) % 12u)) << 1u) | (m ^ 1u);
}
static inline uint clebsch_hop(uint u, uint v) {
  uint d = (u ^ v) & 15u;
  if (d == 0u) return u;
  if (d == 1u || d == 2u || d == 4u || d == 8u || d == 15u) return v;
  uint pop = popcount(d);
  if (pop == 2u) return u ^ (d & (0u - d));
  return u ^ 15u; /* folded antipodal 5th chord reaches remaining 3-bit targets in 2 hops! */
}
kernel void hxp_unified_superconductor(
    device HxpCell64 *cells [[buffer(0)]],
    device atomic_uint *err_cnt [[buffer(1)]],
    uint gid [[thread_position_in_grid]]) {
  HxpCell64 c = cells[gid];
  /* 1. I Ching Q_6 Hexagram Lut6 + Moving-Line Digital Divination */
  ulong hx = (c.hdr_seq >> 48ul) & 63ul, dh = c.val_b & 63ul;
  ulong hx1 = hx ^ dh, hx_back = hx1 ^ dh;
  ulong lut_bit = (c.val_a >> hx1) & 1ul;
  /* 2. Zero-Float Rational Cayley Unitary 2-Port Norm Conservation */
  ulong q = (c.val_a & 255ul) + 1ul, d = (c.val_b & 127ul) + 1ul;
  ulong qd = q + d, a = qd * qd - q * q, b = 2ul * qd * q, r = qd * qd + q * q;
  /* 3. Meissner Triangular Arbitrage Curl Expulsion (d_omega -> 0) */
  long p0 = (long)(c.quote_phi & 0xfffful), p1 = (long)((c.quote_phi >> 16ul) & 0xfffful);
  long p2 = (long)((c.quote_phi >> 32ul) & 0xfffful), eps = (long)(gid & 31u);
  long w01 = (p1 - p0) + eps, w12 = p2 - p1, w20 = p0 - p2;
  long curl = w01 + w12 + w20; long w01_healed = w01 - curl;
  long curl_after = w01_healed + w12 + w20;
  /* 4. Synthetic Synesthesia Tonnetz Involution + Clebsch Diameter-2 Geodesic */
  uint triad = gid % 24u, top = gid % 3u;
  uint t2 = tonnetz_op(tonnetz_op(triad, top), top);
  uint cu = gid & 15u, cv = (gid >> 4u) & 15u;
  uint ch1 = clebsch_hop(cu, cv), ch2 = clebsch_hop(ch1, cv);
  if (hx_back != hx || (a * a + b * b) != (r * r) || curl_after != 0 || t2 != triad || ch2 != cv) {
    atomic_fetch_add_explicit(err_cnt, 1u, memory_order_relaxed);
  }
  c.val_a = (c.val_a ^ r ^ lut_bit) + (ulong)t2;
  c.hdr_seq = (5ul << 56ul) | (hx1 << 48ul) | (c.hdr_seq & 0xfffffffffffful);
  cells[gid] = c;
}
/* end hxp_unified_superconductor.metal */





