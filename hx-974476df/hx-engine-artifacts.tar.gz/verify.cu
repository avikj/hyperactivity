#include <stdint.h>
__device__ __forceinline__ void spec_vx_coupled_eigen(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t v6, uint32_t v7, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5; (void)v6; (void)v7;
  out[0] = (((v0 * v2) + (v0 * v3)) + ((v1 * v2) + (v1 * v3)));
  out[1] = ((v4 * v6) - (v5 * v7));
  out[2] = ((v4 * v7) + (v5 * v6));
}
__device__ __forceinline__ void opt_vx_coupled_eigen(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t v6, uint32_t v7, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5; (void)v6; (void)v7;
  uint32_t v8 = ((v0 + v1) * (v2 + v3));
  uint32_t v9 = (v4 * v6);
  uint32_t v10 = (v5 * v7);
  uint32_t v11 = ((v4 + v5) * (v6 + v7));
  out[0] = v8;
  out[1] = (v9 - v10);
  out[2] = ((v11 - v9) - v10);
}
__device__ __forceinline__ void spec_vx_horner_deg3(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4;
  out[0] = ((v0 + (v1 * v4)) + ((v2 * (v4 * v4)) + (v3 * (v4 * (v4 * v4)))));
}
__device__ __forceinline__ void opt_vx_horner_deg3(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4;
  out[0] = (v0 + (v4 * (v1 + (v4 * (v2 + (v4 * v3))))));
}
__device__ __forceinline__ void spec_vx_lfsr_jump4(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t v6, uint32_t v7, uint32_t* out) {
  uint32_t v8 = ((v0 ^ v1) ^ v4);
  uint32_t v9 = ((v1 ^ v2) ^ v5);
  uint32_t v10 = ((v2 ^ v3) ^ v6);
  uint32_t v11 = ((v3 ^ v8) ^ v7);
  out[0] = v8;
  out[1] = v9;
  out[2] = v10;
  out[3] = v11;
}
__device__ __forceinline__ void opt_vx_lfsr_jump4(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t v6, uint32_t v7, uint32_t* out) {
  out[0] = ((v0 ^ v1) ^ v4);
  out[1] = ((v1 ^ v2) ^ v5);
  out[2] = ((v2 ^ v3) ^ v6);
  out[3] = (((v0 ^ v1) ^ v3) ^ (v4 ^ v7));
}
__device__ __forceinline__ void spec_vx_mux_pipe4(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t* out) {
  uint32_t v5 = ((v0 & v2) | ((~v0) & v3));
  out[0] = ((v1 & v5) | ((~v1) & v4));
}
__device__ __forceinline__ void opt_vx_mux_pipe4(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t* out) {
  uint32_t v5 = (v0 & (v2 ^ v3));
  out[0] = (v4 ^ (v1 & ((v3 ^ v4) ^ v5)));
}
extern "C" __global__ void vx_verify_cuda_kernel(const uint32_t* inBuf, uint32_t* outErr, uint32_t N) {
  uint32_t tid = blockIdx.x * blockDim.x + threadIdx.x;
  if (tid >= N) return;
  uint32_t b = tid * 4u;
  uint32_t x0=inBuf[b], x1=inBuf[b+1u], x2=inBuf[b+2u], x3=inBuf[b+3u];
  uint32_t x4=x0^0x9e3779b9u, x5=x1^0x85ebca6bu, x6=x2^0xc2b2ae35u, x7=x3^0x27d4eb2fu;
  uint32_t s0[4], c0[4], s1[1], c1[1];
  spec_vx_lfsr_jump4(x0,x1,x2,x3,x4,x5,x6,x7,s0); opt_vx_lfsr_jump4(x0,x1,x2,x3,x4,x5,x6,x7,c0);
  spec_vx_mux_pipe4(x0,x1,x2,x3,x4,s1); opt_vx_mux_pipe4(x0,x1,x2,x3,x4,c1);
  outErr[tid] = (s0[0]^c0[0]) | (s0[1]^c0[1]) | (s0[2]^c0[2]) | (s0[3]^c0[3]) | (s1[0]^c1[0]);
}
