#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <sys/time.h>
static double now_ms(void){ struct timeval tv; gettimeofday(&tv,NULL); return tv.tv_sec*1000.0 + tv.tv_usec/1000.0; }
int main(void){
  @autoreleasepool {
    id<MTLDevice> dev = MTLCreateSystemDefaultDevice();
    if (!dev) { printf("No Metal device\n"); return 1; }
    NSError* err = nil;
    NSString* src = [NSString stringWithContentsOfFile:@"/home/claude/hxb/out/omni_omni.metal" encoding:NSUTF8StringEncoding error:&err];
    id<MTLLibrary> lib = [dev newLibraryWithSource:src options:nil error:&err];
    if (!lib) { printf("Metal compile error: %s\n", [[err localizedDescription] UTF8String]); return 1; }
    id<MTLCommandQueue> q = [dev newCommandQueue];
    printf("HX-OMNI Apple Metal GPU: %s (UnifiedMem=%.1f GB)\n", [[dev name] UTF8String], (double)[dev recommendedMaxWorkingSetSize]/1e9);
    uint32_t N1 = 65536u, iters = 256u;
    id<MTLBuffer> bS = [dev newBufferWithLength:N1*4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> bO = [dev newBufferWithLength:N1*4 options:MTLResourceStorageModeShared];
    uint32_t* sp = (uint32_t*)[bS contents]; for (uint32_t i=0;i<N1;i++) sp[i]=i*2654435761u+1u;
    id<MTLComputePipelineState> p1 = [dev newComputePipelineStateWithFunction:[lib newFunctionWithName:@"omni_metal_meta_inet"] error:&err];
    double t0 = now_ms();
    id<MTLCommandBuffer> cb1 = [q commandBuffer]; id<MTLComputeCommandEncoder> e1 = [cb1 computeCommandEncoder];
    [e1 setComputePipelineState:p1]; [e1 setBuffer:bS offset:0 atIndex:0]; [e1 setBuffer:bO offset:0 atIndex:1]; [e1 setBytes:&iters length:4 atIndex:2];
    [e1 dispatchThreads:MTLSizeMake(N1,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)]; [e1 endEncoding]; [cb1 commit]; [cb1 waitUntilCompleted];
    double dt1 = now_ms() - t0;
    double t_nand = (double)N1 * 32.0 * (double)iters * 61.0 / (dt1 * 1e9);
    printf("  [GPU 1] MetaCircuit 61-NAND2 VM : %.2f ms | %.2f T-NAND2/s (checksum=0x%08x)\n", dt1, t_nand, ((uint32_t*)[bO contents])[0]);
    uint32_t terms[16] = {1u|(1u<<8), 2u|(1u<<8), 4u|(1u<<8), 3u|(7u<<8), 5u|(7u<<8), 6u|(7u<<8), 7u|(1u<<8), 9u|(1u<<8), 10u|(7u<<8), 11u|(1u<<8), 12u|(7u<<8), 13u|(1u<<8), 14u|(1u<<8), 15u|(7u<<8), 17u|(1u<<8), 17u|(7u<<8)};
    uint32_t n_terms = 16u;
    id<MTLBuffer> bT = [dev newBufferWithBytes:terms length:sizeof(terms) options:MTLResourceStorageModeShared];
    id<MTLBuffer> bBest = [dev newBufferWithLength:N1*4 options:MTLResourceStorageModeShared];
    id<MTLComputePipelineState> p2 = [dev newComputePipelineStateWithFunction:[lib newFunctionWithName:@"omni_metal_f2_tcount"] error:&err];
    double t2 = now_ms();
    id<MTLCommandBuffer> cb2 = [q commandBuffer]; id<MTLComputeCommandEncoder> e2 = [cb2 computeCommandEncoder];
    [e2 setComputePipelineState:p2]; [e2 setBuffer:bT offset:0 atIndex:0]; [e2 setBuffer:bBest offset:0 atIndex:1]; [e2 setBytes:&n_terms length:4 atIndex:2];
    [e2 dispatchThreads:MTLSizeMake(N1,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)]; [e2 endEncoding]; [cb2 commit]; [cb2 waitUntilCompleted];
    double dt2 = now_ms() - t2;
    uint32_t* bp = (uint32_t*)[bBest contents]; uint32_t min_t = 999u; for (uint32_t i=0;i<N1;i++) if (bp[i]<min_t) min_t=bp[i];
    printf("  [GPU 2] F2-Gauss T-Count Search : %.2f ms | 65,536 F2-bases | best_T=%u (from 16 raw T-terms)\n", dt2, min_t);
    uint32_t sites = 64u, chi = 32u, n3 = sites * 4u * chi * chi;
    id<MTLBuffer> bL = [dev newBufferWithLength:sites*chi*chi*4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> bA = [dev newBufferWithLength:n3*4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> bR = [dev newBufferWithLength:n3*4 options:MTLResourceStorageModeShared];
    float* lp = (float*)[bL contents]; float* ap = (float*)[bA contents];
    for (uint32_t i=0;i<sites*chi*chi;i++) lp[i] = 0.01f * (float)((i%17)+1);
    for (uint32_t i=0;i<n3;i++) ap[i] = 0.01f * (float)((i%13)-6);
    id<MTLComputePipelineState> p3 = [dev newComputePipelineStateWithFunction:[lib newFunctionWithName:@"omni_metal_mps_contract"] error:&err];
    double t3 = now_ms();
    id<MTLCommandBuffer> cb3 = [q commandBuffer]; id<MTLComputeCommandEncoder> e3 = [cb3 computeCommandEncoder];
    [e3 setComputePipelineState:p3]; [e3 setBuffer:bL offset:0 atIndex:0]; [e3 setBuffer:bA offset:0 atIndex:1]; [e3 setBuffer:bR offset:0 atIndex:2]; [e3 setBytes:&chi length:4 atIndex:3];
    [e3 dispatchThreads:MTLSizeMake(n3,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)]; [e3 endEncoding]; [cb3 commit]; [cb3 waitUntilCompleted];
    double dt3 = now_ms() - t3;
    double gflops3 = (2.0 * (double)n3 * (double)chi) / (dt3 * 1e6);
    printf("  [GPU 3] 64-Site MPS Contraction : %.2f ms | chi=%u | %.2f GFLOP/s (T[0]=%.5f)\n", dt3, chi, gflops3, ((float*)[bR contents])[0]);
    uint32_t rows = 4096u, cols = 4096u, cols4 = cols / 4u;
    id<MTLBuffer> bSM = [dev newBufferWithLength:rows*cols4*4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> bIX = [dev newBufferWithLength:rows*cols4*2 options:MTLResourceStorageModeShared];
    id<MTLBuffer> bES = [dev newBufferWithLength:rows*cols options:MTLResourceStorageModeShared];
    id<MTLBuffer> bX  = [dev newBufferWithLength:cols*4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> bY  = [dev newBufferWithLength:rows*4 options:MTLResourceStorageModeShared];
    uint32_t* smp = (uint32_t*)[bSM contents]; uint16_t* ixp = (uint16_t*)[bIX contents]; uint8_t* esp = (uint8_t*)[bES contents];
    float* xp = (float*)[bX contents]; for (uint32_t c=0;c<cols;c++) xp[c] = 0.001f * (float)((c%11)-5);
    uint32_t esc_cnt = 0u;
    for (uint32_t r=0;r<rows;r++) for (uint32_t c=0;c<cols4;c++) {
      uint32_t lo=0u; uint16_t hi=0u;
      for (uint32_t k=0;k<4u;k++) {
        uint32_t idx = (r*cols4+c)*4u+k;
        uint16_t w = (idx < 65536u) ? (uint16_t)idx : (uint16_t)(((idx&1u)<<15) | ((120u + (idx%11u))<<7) | (idx&127u));
        if (idx < 65536u && ((w>>7)&0xFFu) == 255u) w = 0x3F80u;
        uint32_t e = (w >> 7u) & 0xFFu; uint32_t sm = ((w >> 8u) & 0x80u) | (w & 0x7Fu);
        uint32_t ix = (e >= 116u && e <= 130u) ? (e - 116u) : 15u;
        if (ix == 15u) { esp[idx] = (uint8_t)e; esc_cnt++; } else esp[idx] = 0u;
        lo |= (sm << (k*8u)); hi |= (uint16_t)(ix << (k*4u));
      }
      smp[r*cols4+c] = lo; ixp[r*cols4+c] = hi;
    }
    id<MTLComputePipelineState> p4 = [dev newComputePipelineStateWithFunction:[lib newFunctionWithName:@"omni_metal_bf16_gemv_esc"] error:&err];
    double t4 = now_ms();
    id<MTLCommandBuffer> cb4 = [q commandBuffer]; id<MTLComputeCommandEncoder> e4 = [cb4 computeCommandEncoder];
    [e4 setComputePipelineState:p4]; [e4 setBuffer:bSM offset:0 atIndex:0]; [e4 setBuffer:bIX offset:0 atIndex:1];
    [e4 setBuffer:bES offset:0 atIndex:2]; [e4 setBuffer:bX offset:0 atIndex:3]; [e4 setBuffer:bY offset:0 atIndex:4]; [e4 setBytes:&cols4 length:4 atIndex:5];
    [e4 dispatchThreads:MTLSizeMake(rows,1,1) threadsPerThreadgroup:MTLSizeMake(64,1,1)]; [e4 endEncoding]; [cb4 commit]; [cb4 waitUntilCompleted];
    double dt4 = now_ms() - t4;
    float ref0 = 0.0f; for (uint32_t c=0;c<cols;c++) { uint16_t w = (uint16_t)c; if (((w>>7)&0xFFu)==255u) w=0x3F80u; uint32_t u=((uint32_t)w)<<16; float wf; memcpy(&wf,&u,4); ref0 = fmaf(wf, xp[c], ref0); }
    float got0 = ((float*)[bY contents])[0]; float diff0 = fabsf(got0 - ref0);
    double eff_gbps = ((double)rows * (double)cols * 2.0) / (dt4 * 1e6);
    printf("  [GPU 4] Escape-Safe BF16 GEMV   : %.2f ms | %.2f GB/s eff | esc=%u | row0_err=%.2e (0=exact)\n", dt4, eff_gbps, esc_cnt, diff0);
  }
  return 0;
}
