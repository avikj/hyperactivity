#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <time.h>
typedef struct { uint32_t seed, iters, rounds, mode; } SpaceParams;
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1e3 + ts.tv_nsec * 1e-6; }
static int verify_mc(int mode, int ng, const uint8_t *tr, int *out_ands) {
  uint32_t w[24];
  w[0]=0xAAAAAAAAu; w[1]=0xCCCCCCCCu; w[2]=0xF0F0F0F0u; w[3]=0xFF00FF00u;
  w[4]=(mode==2)?0xFFFFFFFFu:0xFFFF0000u; w[5]=0xFFFFFFFFu;
  int nin=(mode==2)?5:6, ands=0;
  for (int g=0; g<ng; g++) { uint32_t a=w[tr[g*3]], b=w[tr[g*3+1]]; int op=tr[g*3+2]; w[nin+g]=op?(a&b):(a^b); ands+=op; }
  *out_ands = ands;
  if (mode==0) { int h0=0,h1=0; for(int g=0;g<ng;g++){ if(w[nin+g]==0xD82727D8u)h0=1; if(w[nin+g]==0xFFD8D800u)h1=1; } return h0&&h1; }
  if (mode==1) { int h0=0,h1=0; for(int g=0;g<ng;g++){ if(w[nin+g]==0xE81717E8u)h0=1; if(w[nin+g]==0xFFE8E800u)h1=1; } return h0&&h1; }
  int h0=0,h1=0,h2=0,h3=0;
  for(int g=0;g<ng;g++){ uint16_t v=(uint16_t)(w[nin+g]&0xFFFFu); if(v==0x659A)h0=1; if(v==0xA74C)h1=1; if(v==0x3687)h2=1; if(v==0x0ED9)h3=1; }
  return h0&&h1&&h2&&h3;
}
int main(void) { @autoreleasepool {
  id<MTLDevice> dev = MTLCreateSystemDefaultDevice();
  if (!dev) { printf("NO_METAL_DEVICE"); putchar(10); return 1; }
  NSError *err = nil;
  NSString *src = [NSString stringWithContentsOfFile:[NSString stringWithUTF8String:"/home/claude/hxb/out/space.metal"] encoding:NSUTF8StringEncoding error:&err];
  id<MTLLibrary> lib = [dev newLibraryWithSource:src options:nil error:&err];
  if (!lib) { fprintf(stderr, "METAL_ERR: %s", err.localizedDescription.UTF8String); fputc(10, stderr); return 2; }
  id<MTLCommandQueue> q = [dev newCommandQueue];
  id<MTLComputePipelineState> pMC = [dev newComputePipelineStateWithFunction:[lib newFunctionWithName:[NSString stringWithUTF8String:"hx_mc_discover"]] error:&err];
  id<MTLComputePipelineState> pGC = [dev newComputePipelineStateWithFunction:[lib newFunctionWithName:[NSString stringWithUTF8String:"hx_gc_lattice_bench"]] error:&err];
  id<MTLComputePipelineState> pHZ = [dev newComputePipelineStateWithFunction:[lib newFunctionWithName:[NSString stringWithUTF8String:"hx_horizon_probe"]] error:&err];
  printf("=== SHA-256 MULTI-FUNCTOR MATHEMATICAL IDENTITY OBSERVATORY (%s) ===", dev.name.UTF8String); putchar(10);
  // FUNCTOR 1: Multiplicative Complexity {XOR=0, AND=1}
  uint32_t ba_init[3] = {99,99,99}; uint32_t tk_init[48] = {0};
  id<MTLBuffer> bBA = [dev newBufferWithBytes:ba_init length:sizeof(ba_init) options:MTLResourceStorageModeShared];
  id<MTLBuffer> bTK = [dev newBufferWithBytes:tk_init length:sizeof(tk_init) options:MTLResourceStorageModeShared];
  id<MTLBuffer> bOC = [dev newBufferWithLength:48*48 options:MTLResourceStorageModeShared];
  SpaceParams sp1 = { 1337, 24576, 0, 0 };
  double t1 = now_ms();
  id<MTLCommandBuffer> c1 = [q commandBuffer]; id<MTLComputeCommandEncoder> e1 = [c1 computeCommandEncoder];
  [e1 setComputePipelineState:pMC]; [e1 setBuffer:bBA offset:0 atIndex:0]; [e1 setBuffer:bTK offset:0 atIndex:1]; [e1 setBuffer:bOC offset:0 atIndex:2]; [e1 setBytes:&sp1 length:sizeof(sp1) atIndex:3];
  [e1 dispatchThreads:MTLSizeMake(49152, 1, 1) threadsPerThreadgroup:MTLSizeMake(256, 1, 1)];
  [e1 endEncoding]; [c1 commit]; [c1 waitUntilCompleted];
  double mc_ms = now_ms() - t1;
  printf("[Functor 1: Multiplicative Complexity {XOR=0, AND=1} in %.1f ms]", mc_ms); putchar(10);
  const char *mnames[3] = { "SHA256_CH5 (Ch+FA 5in->2out)", "SHA256_MAJ5 (Maj+FA 5in->2out)", "PRESENT_SBOX_4OUT (all 4 bits!)" };
  uint32_t *ba = bBA.contents; const uint8_t *oc = bOC.contents;
  for (int m = 0; m < 3; m++) {
    int a = (int)ba[m], va = 0, ok = 0, ng = (m==2)?14:9;
    if (a < 16) ok = verify_mc(m, ng, oc + (m*16 + a)*48, &va);
    printf("  %-32s min_AND=%2d verified=%d", mnames[m], a, ok); putchar(10);
  }
  // FUNCTOR 2: Bit-Parallel 128-bit uint4 Signed-Bit Generalized-Condition Lattice
  uint32_t z0 = 0, mw = 9999;
  id<MTLBuffer> bTP = [dev newBufferWithBytes:&z0 length:4 options:MTLResourceStorageModeShared];
  id<MTLBuffer> bMW = [dev newBufferWithBytes:&mw length:4 options:MTLResourceStorageModeShared];
  SpaceParams sp2 = { 4242, 4096, 8, 0 };
  double t2 = now_ms();
  id<MTLCommandBuffer> c2 = [q commandBuffer]; id<MTLComputeCommandEncoder> e2 = [c2 computeCommandEncoder];
  [e2 setComputePipelineState:pGC]; [e2 setBuffer:bTP offset:0 atIndex:0]; [e2 setBuffer:bMW offset:0 atIndex:1]; [e2 setBytes:&sp2 length:sizeof(sp2) atIndex:2];
  [e2 dispatchThreads:MTLSizeMake(65536, 1, 1) threadsPerThreadgroup:MTLSizeMake(256, 1, 1)];
  [e2 endEncoding]; [c2 commit]; [c2 waitUntilCompleted];
  double gc_ms = now_ms() - t2;
  double bit_conds = 65536.0 * sp2.iters * sp2.rounds * 32.0;
  printf("[Functor 2: uint4 Generalized-Condition Lattice] %.2fB bit-conds in %.2f ms (%.2f G-bit-conds/s) | 8-rnd min_active_wt=%u", bit_conds/1e9, gc_ms, bit_conds/(gc_ms*1e6), ((uint32_t*)bMW.contents)[0]); putchar(10);
  // FUNCTOR 3: Exact Round-by-Round Avalanche / Rotational / 2-Adic Horizon (R=1..12)
  printf("[Functor 3: SHA-256 Avalanche + Rotational + 2-Adic Horizon (N=1,048,576 pairs/round)]"); putchar(10);
  for (uint32_t R = 1; R <= 12; R++) {
    uint32_t st0[4] = {0,0,0,0};
    id<MTLBuffer> bST = [dev newBufferWithBytes:st0 length:16 options:MTLResourceStorageModeShared];
    SpaceParams sp3 = { 9000 + R, 64, R, 0 };
    id<MTLCommandBuffer> c3 = [q commandBuffer]; id<MTLComputeCommandEncoder> e3 = [c3 computeCommandEncoder];
    [e3 setComputePipelineState:pHZ]; [e3 setBuffer:bST offset:0 atIndex:0]; [e3 setBytes:&sp3 length:sizeof(sp3) atIndex:1];
    [e3 dispatchThreads:MTLSizeMake(16384, 1, 1) threadsPerThreadgroup:MTLSizeMake(256, 1, 1)];
    [e3 endEncoding]; [c3 commit]; [c3 waitUntilCompleted];
    uint32_t *st = bST.contents; double N = 16384.0 * 64.0;
    double hd = st[0]/N, rd = st[1]/N, ad = st[2]/N, b0 = fabs(st[3]/N - 0.5);
    printf("  R=%2u | xor_ham=%.2f/256 | rot_ham=%.2f/256 | 2adic_ham=%.2f/256 | bit0_bias=%.5f", R, hd, rd, ad, b0); putchar(10);
  }
  return 0;
} }
