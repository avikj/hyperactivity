// Mechanically lowered from certified PolyOptCert + F2OptCert suite (lib/ir/poly-opt.hypercubical)
module hx_poly_howell8_quat (input logic [31:0] v0, input logic [31:0] v1, input logic [31:0] v2, input logic [31:0] v3, input logic [31:0] v4, input logic [31:0] v5, input logic [31:0] v6, input logic [31:0] v7, output logic [31:0] y0, output logic [31:0] y1, output logic [31:0] y2, output logic [31:0] y3);
  logic [31:0] v8; assign v8 = ((v0 + v1) * (v4 + v5));
  logic [31:0] v9; assign v9 = ((v3 - v2) * (v6 - v7));
  logic [31:0] v10; assign v10 = ((v0 - v1) * (v6 + v7));
  logic [31:0] v11; assign v11 = ((v2 + v3) * (v4 - v5));
  logic [31:0] v12; assign v12 = ((v1 + v3) * (v5 + v6));
  logic [31:0] v13; assign v13 = ((v1 - v3) * (v5 - v6));
  logic [31:0] v14; assign v14 = ((v0 + v2) * (v4 - v7));
  logic [31:0] v15; assign v15 = ((v0 - v2) * (v4 + v7));
  logic [31:0] v16; assign v16 = (v12 + v13);
  logic [31:0] v17; assign v17 = (v12 - v13);
  logic [31:0] v18; assign v18 = (v14 + v15);
  logic [31:0] v19; assign v19 = (v14 - v15);
  assign y0 = ((v9 + v9) + (v18 - v16));
  assign y1 = ((v8 + v8) - (v18 + v16));
  assign y2 = ((v10 + v10) + (v19 + v17));
  assign y3 = (((v11 + v11) - v19) + v17);
endmodule

module hx_poly_euler_4sq (input logic [31:0] v0, input logic [31:0] v1, input logic [31:0] v2, input logic [31:0] v3, input logic [31:0] v4, input logic [31:0] v5, input logic [31:0] v6, input logic [31:0] v7, output logic [31:0] y0);
  logic [31:0] v8; assign v8 = (((v0 * v0) + (v1 * v1)) + ((v2 * v2) + (v3 * v3)));
  logic [31:0] v9; assign v9 = (((v4 * v4) + (v5 * v5)) + ((v6 * v6) + (v7 * v7)));
  assign y0 = (v8 * v9);
endmodule

module hx_poly_adelic_hadamard (input logic [31:0] v0, input logic [31:0] v1, input logic [31:0] v2, input logic [31:0] v3, output logic [31:0] y0, output logic [31:0] y1, output logic [31:0] y2, output logic [31:0] y3);
  logic [31:0] v4; assign v4 = (v0 + v2);
  logic [31:0] v5; assign v5 = (v0 - v2);
  logic [31:0] v6; assign v6 = (v1 + v3);
  logic [31:0] v7; assign v7 = (v1 - v3);
  assign y0 = (v4 + v6);
  assign y1 = (v4 - v6);
  assign y2 = (v5 + v7);
  assign y3 = (v5 - v7);
endmodule

module hx_poly_poisson_plancherel (input logic [31:0] v0, input logic [31:0] v1, input logic [31:0] v2, input logic [31:0] v3, output logic [31:0] y0, output logic [31:0] y1, output logic [31:0] y2, output logic [31:0] y3, output logic [31:0] y4, output logic [31:0] y5);
  assign y0 = 32'd0;
  assign y1 = 32'd0;
  assign y2 = 32'd0;
  assign y3 = 32'd0;
  assign y4 = 32'd0;
  assign y5 = 32'd0;
endmodule

module hx_poly_alpoge_masullo (input logic [31:0] v0, input logic [31:0] v1, input logic [31:0] v2, input logic [31:0] v3, input logic [31:0] v4, input logic [31:0] v5, input logic [31:0] v6, input logic [31:0] v7, output logic [31:0] y0, output logic [31:0] y1, output logic [31:0] y2, output logic [31:0] y3);
  logic [31:0] v8; assign v8 = (v0 - v1);
  assign y0 = 32'd0;
  assign y1 = 32'd0;
  assign y2 = (v8 * v8);
  assign y3 = v8;
endmodule

module hx_poly_darwin_stokes (input logic [31:0] v0, input logic [31:0] v1, input logic [31:0] v2, input logic [31:0] v3, input logic [31:0] v4, input logic [31:0] v5, output logic [31:0] y0, output logic [31:0] y1, output logic [31:0] y2, output logic [31:0] y3, output logic [31:0] y4, output logic [31:0] y5);
  logic [31:0] v6; assign v6 = ((v0 - v1) * (v2 - v3));
  logic [31:0] v7; assign v7 = ((v0 * v4) + (v1 * v5));
  assign y0 = (v6 + (v7 + v7));
  assign y1 = 32'd0;
  assign y2 = 32'd0;
  assign y3 = 32'd0;
  assign y4 = 32'd0;
  assign y5 = 32'd4;
endmodule

module hx_poly_fredkin_1and (input logic [31:0] v0, input logic [31:0] v1, input logic [31:0] v2, output logic [31:0] y0, output logic [31:0] y1, output logic [31:0] y2);
  logic [31:0] v3; assign v3 = (v1 ^ v2);
  logic [31:0] v4; assign v4 = (v0 & v3);
  assign y0 = v0;
  assign y1 = (v1 ^ v4);
  assign y2 = (v2 ^ v4);
endmodule

module hx_poly_keccak_chi5 (input logic [31:0] v0, input logic [31:0] v1, input logic [31:0] v2, input logic [31:0] v3, input logic [31:0] v4, output logic [31:0] y0, output logic [31:0] y1, output logic [31:0] y2, output logic [31:0] y3, output logic [31:0] y4);
  assign y0 = (v0 ^ ((~v1) & v2));
  assign y1 = (v1 ^ ((~v2) & v3));
  assign y2 = (v2 ^ ((~v3) & v4));
  assign y3 = (v3 ^ ((~v4) & v0));
  assign y4 = (v4 ^ ((~v0) & v1));
endmodule

