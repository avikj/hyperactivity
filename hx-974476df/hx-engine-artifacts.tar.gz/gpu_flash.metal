// Mechanically lowered from verified TensorIR specs (lib/ir/tensor-ir.hypercubical)
#include <metal_stdlib>
#include <metal_simdgroup_matrix>
using namespace metal;
struct GemmDims { uint M; uint N; uint K; };
struct AttnDims { uint N; uint D; float scale; };
// Lowered from verified tk-gemm 2048x2048x2048 tile=32x32x32
kernel void hx_gemm_simd16(
    device const half* A [[buffer(0)]],
    device const half* B [[buffer(1)]],
    device float* C [[buffer(2)]],
    constant GemmDims& dm [[buffer(3)]],
    uint2 tgid [[threadgroup_position_in_grid]],
    uint sgid [[simdgroup_index_in_threadgroup]],
    uint tid [[thread_index_in_threadgroup]]) {
  threadgroup half As[32][32];
  threadgroup half Bs[32][32];
  uint bm = tgid.y * 32, bn = tgid.x * 32;
  uint sgr = (sgid >> 1) * 16, sgc = (sgid & 1) * 16;
  simdgroup_float8x8 acc00 = make_filled_simdgroup_matrix<float, 8, 8>(0.0f);
  simdgroup_float8x8 acc01 = make_filled_simdgroup_matrix<float, 8, 8>(0.0f);
  simdgroup_float8x8 acc10 = make_filled_simdgroup_matrix<float, 8, 8>(0.0f);
  simdgroup_float8x8 acc11 = make_filled_simdgroup_matrix<float, 8, 8>(0.0f);
  for (uint bk = 0; bk < dm.K; bk += 32) {
    for (uint e = tid; e < 1024; e += 128) {
      uint r = e / 32, c = e % 32;
      As[r][c] = A[(bm + r) * dm.K + (bk + c)];
      Bs[r][c] = B[(bk + r) * dm.N + (bn + c)];
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    for (uint kk = 0; kk < 32; kk += 8) {
      simdgroup_half8x8 a0, a1, b0, b1;
      simdgroup_load(a0, &As[sgr][kk], 32); simdgroup_load(a1, &As[sgr + 8][kk], 32);
      simdgroup_load(b0, &Bs[kk][sgc], 32); simdgroup_load(b1, &Bs[kk][sgc + 8], 32);
      simdgroup_multiply_accumulate(acc00, a0, b0, acc00);
      simdgroup_multiply_accumulate(acc01, a0, b1, acc01);
      simdgroup_multiply_accumulate(acc10, a1, b0, acc10);
      simdgroup_multiply_accumulate(acc11, a1, b1, acc11);
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
  }
  simdgroup_store(acc00, &C[(bm + sgr) * dm.N + (bn + sgc)], dm.N);
  simdgroup_store(acc01, &C[(bm + sgr) * dm.N + (bn + sgc + 8)], dm.N);
  simdgroup_store(acc10, &C[(bm + sgr + 8) * dm.N + (bn + sgc)], dm.N);
  simdgroup_store(acc11, &C[(bm + sgr + 8) * dm.N + (bn + sgc + 8)], dm.N);
}
// Lowered from verified tk-flash-attn N=1024 D=64 tile=32x32
kernel void hx_flash_attn_simd16(
    device const half* Q [[buffer(0)]],
    device const half* Kt [[buffer(1)]],
    device const half* V [[buffer(2)]],
    device float* O [[buffer(3)]],
    constant AttnDims& ad [[buffer(4)]],
    uint tgid [[threadgroup_position_in_grid]],
    uint sgid [[simdgroup_index_in_threadgroup]],
    uint lane [[thread_index_in_simdgroup]],
    uint tid [[thread_index_in_threadgroup]]) {
  threadgroup half Qs[32][64];
  threadgroup half Kts[64][32];
  threadgroup half Vs[32][64];
  threadgroup float St[32][32];
  threadgroup half Pt[32][32];
  threadgroup float Ot[32][64];
  threadgroup float rm[32], rl[32], ralpha[32];
  uint qbase = tgid * 32;
  for (uint e = tid; e < 2048; e += 128) {
    uint r = e / 64, c = e % 64;
    Qs[r][c] = Q[(qbase + r) * 64 + c];
    Ot[r][c] = 0.0f;
  }
  if (tid < 32) { rm[tid] = -1e30f; rl[tid] = 0.0f; }
  threadgroup_barrier(mem_flags::mem_threadgroup);
  uint qrow = sgid * 8;
  for (uint kv = 0; kv < ad.N; kv += 32) {
    for (uint e = tid; e < 2048; e += 128) {
      uint r = e / 64, c = e % 64;
      Vs[r][c] = V[(kv + r) * 64 + c];
      Kts[c][r] = Kt[(kv + r) * 64 + c];
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    simdgroup_float8x8 s0 = make_filled_simdgroup_matrix<float, 8, 8>(0.0f);
    simdgroup_float8x8 s1 = make_filled_simdgroup_matrix<float, 8, 8>(0.0f);
    simdgroup_float8x8 s2 = make_filled_simdgroup_matrix<float, 8, 8>(0.0f);
    simdgroup_float8x8 s3 = make_filled_simdgroup_matrix<float, 8, 8>(0.0f);
    for (uint k = 0; k < 64; k += 8) {
      simdgroup_half8x8 qm, k0, k1, k2, k3;
      simdgroup_load(qm, &Qs[qrow][k], 64);
      simdgroup_load(k0, &Kts[k][0], 32); simdgroup_load(k1, &Kts[k][8], 32);
      simdgroup_load(k2, &Kts[k][16], 32); simdgroup_load(k3, &Kts[k][24], 32);
      simdgroup_multiply_accumulate(s0, qm, k0, s0);
      simdgroup_multiply_accumulate(s1, qm, k1, s1);
      simdgroup_multiply_accumulate(s2, qm, k2, s2);
      simdgroup_multiply_accumulate(s3, qm, k3, s3);
    }
    simdgroup_store(s0, &St[qrow][0], 32); simdgroup_store(s1, &St[qrow][8], 32);
    simdgroup_store(s2, &St[qrow][16], 32); simdgroup_store(s3, &St[qrow][24], 32);
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (tid < 32) {
      float m = rm[tid], l = rl[tid], mx = m;
      for (uint j = 0; j < 32; j++) { float v = St[tid][j] * ad.scale; St[tid][j] = v; if (v > mx) mx = v; }
      float alpha = exp(m - mx), sum = 0.0f;
      for (uint j = 0; j < 32; j++) { float p = exp(St[tid][j] - mx); Pt[tid][j] = half(p); sum += p; }
      rl[tid] = l * alpha + sum; rm[tid] = mx; ralpha[tid] = alpha;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    for (uint e = tid; e < 2048; e += 128) { uint r = e / 64, c = e % 64; Ot[r][c] *= ralpha[r]; }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    for (uint col = 0; col < 64; col += 16) {
      simdgroup_float8x8 o0, o1;
      simdgroup_load(o0, &Ot[qrow][col], 64); simdgroup_load(o1, &Ot[qrow][col + 8], 64);
      for (uint k = 0; k < 32; k += 8) {
        simdgroup_half8x8 pm, v0, v1;
        simdgroup_load(pm, &Pt[qrow][k], 32);
        simdgroup_load(v0, &Vs[k][col], 64); simdgroup_load(v1, &Vs[k][col + 8], 64);
        simdgroup_multiply_accumulate(o0, pm, v0, o0);
        simdgroup_multiply_accumulate(o1, pm, v1, o1);
      }
      simdgroup_store(o0, &Ot[qrow][col], 64); simdgroup_store(o1, &Ot[qrow][col + 8], 64);
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
  }
  for (uint e = tid; e < 2048; e += 128) {
    uint r = e / 64, c = e % 64;
    O[(qbase + r) * 64 + c] = Ot[r][c] / rl[r];
  }
}
