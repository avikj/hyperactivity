#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
struct HxpCell64 {
  uint64_t hdr_seq, port_wire, val_a, val_b, quote_phi, fiber_ep, key_ref, mac_tag;
} __attribute__((aligned(64)));
static inline double sec_now(void) {
  struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
  return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}
int main(int argc, char **argv) {
  @autoreleasepool {
    const char *mpath = (argc > 1) ? argv[1] : "/tmp/hy_out/hx_hxp.metal";
    id<MTLDevice> dev = MTLCreateSystemDefaultDevice();
    if (!dev) { printf("[HXP-METAL] No Metal GPU\n"); return 1; }
    NSError *err = nil;
    NSString *src = [NSString stringWithContentsOfFile:[NSString stringWithUTF8String:mpath]
                     encoding:NSUTF8StringEncoding error:&err];
    if (!src) { printf("[HXP-METAL] Missing shader\n"); return 1; }
    MTLCompileOptions *opts = [MTLCompileOptions new];
    opts.mathMode = MTLMathModeSafe;
    id<MTLLibrary> lib = [dev newLibraryWithSource:src options:opts error:&err];
    if (!lib) { printf("%s\n", [[err localizedDescription] UTF8String]); return 1; }
    id<MTLFunction> fn = [lib newFunctionWithName:@"hxp_unified_superconductor"];
    id<MTLComputePipelineState> pso = [dev newComputePipelineStateWithFunction:fn error:&err];
    id<MTLCommandQueue> q = [dev newCommandQueue];
    const size_t NCELLS = 4194304ULL; /* 4.19M Hexagram cells = 256 MiB Unified DRAM */
    const size_t BYTES  = NCELLS * sizeof(struct HxpCell64);
    void *raw_cells = NULL; void *raw_err = NULL;
    if (posix_memalign(&raw_cells, 16384, BYTES) != 0 || !raw_cells) return 1;
    if (posix_memalign(&raw_err, 16384, 16384) != 0 || !raw_err) return 1;
    struct HxpCell64 *cells = (struct HxpCell64 *)raw_cells;
    memset(raw_err, 0, 16384);
    for (size_t i = 0; i < NCELLS; ++i) {
      cells[i].hdr_seq = (2ULL << 56) | ((i & 63ULL) << 48) | i;
      cells[i].port_wire = (uint64_t)i;
      cells[i].val_a = 0xf0f0ccccaaaaaaaaULL ^ (uint64_t)i;
      cells[i].val_b = (uint64_t)((i * 7ULL) & 63ULL);
      cells[i].quote_phi = ((uint64_t)(i & 1023ULL) << 32) | ((uint64_t)((i * 3ULL) & 1023ULL) << 16) | (uint64_t)(i & 511ULL);
      cells[i].fiber_ep = 1ULL; cells[i].key_ref = (uint64_t)i * 0x9e3779b9ULL; cells[i].mac_tag = 0ULL;
    }
    /* ZERO-COPY Unified DRAM Binding: CPU and GPU share exact physical pages! */
    id<MTLBuffer> bCells = [dev newBufferWithBytesNoCopy:raw_cells length:BYTES
                            options:MTLResourceStorageModeShared deallocator:nil];
    id<MTLBuffer> bErr = [dev newBufferWithBytesNoCopy:raw_err length:16384
                          options:MTLResourceStorageModeShared deallocator:nil];
    int zero_copy_ok = ([bCells contents] == raw_cells) ? 1 : 0;
    double best = 1e9;
    for (int it = 0; it < 7; ++it) {
      id<MTLCommandBuffer> cb = [q commandBuffer];
      id<MTLComputeCommandEncoder> enc = [cb computeCommandEncoder];
      [enc setComputePipelineState:pso];
      [enc setBuffer:bCells offset:0 atIndex:0];
      [enc setBuffer:bErr offset:0 atIndex:1];
      [enc dispatchThreads:MTLSizeMake(NCELLS, 1, 1) threadsPerThreadgroup:MTLSizeMake(256, 1, 1)];
      [enc endEncoding];
      double t0 = sec_now(); [cb commit]; [cb waitUntilCompleted]; double dt = sec_now() - t0;
      if (it > 0 && dt < best) best = dt;
    }
    uint32_t gpu_errs = *(uint32_t *)raw_err;
    uint64_t tag_ok = ((cells[NCELLS - 1].hdr_seq >> 56) == 5ULL) ? 1ULL : 0ULL;
    double gcuts_s = (double)NCELLS / (best * 1e9);
    double gbytes_s = ((double)BYTES * 2.0) / (best * 1e9); /* read + write in-place */
    double tbitops_s = gcuts_s * 512.0;
    printf("[HXP-METAL-UNIFIED] gpu=%s | cells=%zu (256MiB) | zero_copy=%d | errs=%u | %.2f G-hex-cuts/s | %.2f T-bit-ops/s | %.2f GB/s (%.3f ms)\n",
           [[dev name] UTF8String], NCELLS, zero_copy_ok, gpu_errs, gcuts_s, tbitops_s, gbytes_s, best * 1e3);
    free(raw_err); free(raw_cells);
    return (zero_copy_ok == 1 && gpu_errs == 0 && tag_ok == 1ULL) ? 0 : 1;
  }
}
/* end hx_hxp_metal.m */





