// Generated from lib/hx-supercomp.hypercubical — NVIDIA 8xH100 sm_90a Cluster Fabric Kernel
#include <cuda_runtime.h>
#include <stdint.h>
#include <stdio.h>

__global__ void h100_dor_1m_verify(const uint32_t* srcs, const uint32_t* dsts, uint32_t* hops_out, uint32_t* err_cnt, uint32_t n) {
  uint32_t tid = blockIdx.x * blockDim.x + threadIdx.x; if (tid >= n) return;
  uint32_t cur = srcs[tid] & 0xFFFFFu, dst = dsts[tid] & 0xFFFFFu;
  uint32_t h0 = __popc(cur ^ dst), prev_h = h0, hops = 0u;
  while (cur != dst && hops < 24u) {
    uint32_t diff = cur ^ dst; cur ^= (diff & (~diff + 1u));
    uint32_t nh = __popc(cur ^ dst);
    if (nh + 1u != prev_h) atomicAdd(err_cnt, 1u);
    prev_h = nh; hops++;
  }
  if (cur != dst || hops != h0) atomicAdd(err_cnt, 1u);
  hops_out[tid] = hops;
}

__global__ void h100_allreduce_hop(const float* src, float* dst, uint32_t stride, uint32_t n) {
  uint32_t tid = blockIdx.x * blockDim.x + threadIdx.x; if (tid >= n) return;
  dst[tid] = src[tid] + src[tid ^ stride];
}

int main(void) {
  int ng = 0; cudaGetDeviceCount(&ng);
  printf("HX-SUPERCOMP 8xH100 Fabric Engine (%d CUDA GPUs) | 48b/64b BF16 Wire Codec + DOR-20\n", ng);
  return 0;
}
