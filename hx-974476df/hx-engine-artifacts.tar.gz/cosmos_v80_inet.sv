// ============================================================================
// Generated from lib/hx-cosmos.hypercubical (28th engine: hx cosmos)
// Target: AMD Alveo V80 (Versal HBM XCV80: 2,574,208 LUTs, 32 GB HBM2e @ 820 GB/s)
// Certified: cos-thm-v80-fits (8,192 tiles + 477,056 LUT shell), cos-thm-cbf-forward-invariant
// ============================================================================

module hx_meta_cub_face_conflict4(input logic w0, input logic w1, input logic w2, input logic w3, output logic y);
  wire w4 = ~(w2 & w2);
  wire w5 = ~(w3 & w4);
  wire w6 = ~(w5 & w4);
  wire w7 = ~(w6 & w1);
  wire w8 = ~(w6 & w0);
  wire w9 = ~(w8 & w7);
  assign y = w9;
endmodule
module hx_meta_cub_demorgan_alu4(input logic w0, input logic w1, input logic w2, input logic w3, output logic y);
  wire w4 = ~(w3 & w1);
  wire w5 = ~(w2 & w0);
  wire w6 = ~(w2 & w5);
  wire w7 = ~(w3 & w4);
  wire w8 = ~(w5 & w0);
  wire w9 = ~(w8 & w6);
  wire w10 = ~(w4 & w1);
  wire w11 = ~(w7 & w9);
  wire w12 = ~(w11 & w10);
  assign y = w12;
endmodule
module hx_meta_inet_era_either4(input logic w0, input logic w1, input logic w2, input logic w3, output logic y);
  wire w4 = ~(w3 & w3);
  wire w5 = ~(w2 & w4);
  wire w6 = ~(w5 & w4);
  wire w7 = ~(w0 & w6);
  wire w8 = ~(w1 & w7);
  wire w9 = ~(w8 & w7);
  wire w10 = ~(w9 & w6);
  assign y = w10;
endmodule
module hx_meta_inet_commute4(input logic w0, input logic w1, input logic w2, input logic w3, output logic y);
  wire w4 = ~(w0 & w2);
  wire w5 = ~(w1 & w0);
  wire w6 = ~(w0 & w3);
  wire w7 = ~(w3 & w2);
  wire w8 = ~(w7 & w5);
  wire w9 = ~(w6 & w4);
  wire w10 = ~(w9 & w8);
  wire w11 = ~(w10 & w9);
  wire w12 = ~(w11 & w11);
  assign y = w12;
endmodule
module hx_meta_inet_annihilate4(input logic w0, input logic w1, input logic w2, input logic w3, output logic y);
  wire w4 = ~(w1 & w0);
  wire w5 = ~(w2 & w4);
  wire w6 = ~(w0 & w3);
  wire w7 = ~(w5 & w0);
  wire w8 = ~(w6 & w4);
  wire w9 = ~(w8 & w5);
  wire w10 = ~(w1 & w2);
  wire w11 = ~(w6 & w7);
  wire w12 = ~(w9 & w11);
  wire w13 = ~(w12 & w12);
  assign y = w13;
endmodule
module hx_meta_inet_vxchg_arb4(input logic w0, input logic w1, input logic w2, input logic w3, output logic y);
  wire w4 = ~(w1 & w0);
  wire w5 = ~(w0 & w4);
  wire w6 = ~(w4 & w1);
  wire w7 = ~(w3 & w2);
  wire w8 = ~(w5 & w6);
  wire w9 = ~(w7 & w8);
  wire w10 = ~(w9 & w2);
  wire w11 = ~(w2 & w10);
  wire w12 = ~(w11 & w11);
  assign y = w12;
endmodule
module hx_meta_inet_tag_neq4(input logic w0, input logic w1, input logic w2, input logic w3, output logic y);
  wire w4 = ~(w0 & w2);
  wire w5 = ~(w0 & w4);
  wire w6 = ~(w2 & w4);
  wire w7 = ~(w1 & w3);
  wire w8 = ~(w1 & w7);
  wire w9 = ~(w3 & w7);
  wire w10 = ~(w5 & w8);
  wire w11 = ~(w10 & w10);
  wire w12 = ~(w6 & w9);
  wire w13 = ~(w12 & w12);
  wire w14 = ~(w11 & w13);
  assign y = w14;
endmodule
// Generated from lib/hx-supercomp.hypercubical (24th engine: hx supercomp)
// Certified by: sc-thm-dor-decr (deadlock-free all d), sc-thm-bisection-exact, sc-thm-wire-codec-4x3, kir-opt-sound
module hx_dor_router #(parameter int DIM = 20) (
  input  logic [DIM-1:0] cur_id,
  input  logic [DIM-1:0] dst_id,
  output logic           arrived,
  output logic [$clog2(DIM)-1:0] out_dim,
  output logic [DIM-1:0] next_id
);
  logic [DIM-1:0] diff;
  assign diff    = cur_id ^ dst_id;
  assign arrived = (diff == '0);
  always_comb begin
    out_dim = '0;
    next_id = cur_id;
    for (int d = 0; d < DIM; d++) begin
      if (diff[d]) begin
        out_dim = d[$clog2(DIM)-1:0];
        next_id = cur_id ^ (DIM'(1) << d);
        break;
      end
    end
  end
endmodule

// 1-Cycle Hardware Control Barrier Function (CBF) Physical Actuator Safety Interlock
// Physically enforces h(x_next) >= SAFE_MIN + EPS_TOTAL + D_MAX before ANY actuator/stimulator pulse!
module hx_cbf_hw_interlock #(
  parameter int W = 16,
  parameter logic [W-1:0] SAFE_MIN  = 16'd256,
  parameter logic [W-1:0] EPS_TOTAL = 16'd32,
  parameter logic [W-1:0] D_MAX     = 16'd64
) (
  input  logic [W-1:0] h_pred,
  input  logic [W-1:0] u_cmd,
  input  logic [W-1:0] u_safe_fallback,
  output logic         cbf_safe,
  output logic [W-1:0] u_out
);
  localparam logic [W-1:0] FLOOR = SAFE_MIN + EPS_TOTAL + D_MAX;
  assign cbf_safe = (h_pred >= FLOOR);
  assign u_out    = cbf_safe ? u_cmd : u_safe_fallback;
endmodule

// Single Hardware Cubical Interaction-Net Rewrite Tile (embeds 61-NAND2 MetaCircuit ALU + DOR router)
module hx_v80_inet_tile #(parameter int DIM = 13) (
  input  logic           clk,
  input  logic           rst_n,
  input  logic [DIM-1:0] tile_id,
  input  logic           pair_valid,
  input  logic [3:0]     pair_tag,
  input  logic [DIM-1:0] dst_id,
  output logic           rewrite_fired,
  output logic [6:0]     rule_vec,
  output logic           pkt_arrived,
  output logic [DIM-1:0] next_hop
);
  logic r0, r1, r2, r3, r4, r5, r6;
  cub_face_conflict4 u0 (.w0(pair_tag[0]), .w1(pair_tag[1]), .w2(pair_tag[2]), .w3(pair_tag[3]), .y(r0));
  cub_demorgan_alu4  u1 (.w0(pair_tag[0]), .w1(pair_tag[1]), .w2(pair_tag[2]), .w3(pair_tag[3]), .y(r1));
  inet_era_either4   u2 (.w0(pair_tag[0]), .w1(pair_tag[1]), .w2(pair_tag[2]), .w3(pair_tag[3]), .y(r2));
  inet_commute4      u3 (.w0(pair_tag[0]), .w1(pair_tag[1]), .w2(pair_tag[2]), .w3(pair_tag[3]), .y(r3));
  inet_annihilate4   u4 (.w0(pair_tag[0]), .w1(pair_tag[1]), .w2(pair_tag[2]), .w3(pair_tag[3]), .y(r4));
  inet_vxchg_arb4    u5 (.w0(pair_tag[0]), .w1(pair_tag[1]), .w2(pair_tag[2]), .w3(pair_tag[3]), .y(r5));
  inet_tag_neq4      u6 (.w0(pair_tag[0]), .w1(pair_tag[1]), .w2(pair_tag[2]), .w3(pair_tag[3]), .y(r6));
  logic [$clog2(DIM)-1:0] out_dim;
  hx_dor_router #(.DIM(DIM)) u_dor (.cur_id(tile_id), .dst_id(dst_id), .arrived(pkt_arrived), .out_dim(out_dim), .next_id(next_hop));
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin rewrite_fired <= 1'b0; rule_vec <= 7'b0; end
    else begin rewrite_fired <= pair_valid; rule_vec <= {r6, r5, r4, r3, r2, r1, r0}; end
  end
endmodule

// Parametric Alveo V80 Supercomputer Fabric Top (NUM_TILES=8192 for 1x V80, 32768 for 4x V80)
module hx_v80_supercomp_top #(parameter int DIM = 13, parameter int BANKS = 32) (
  input  logic                  clk,
  input  logic                  rst_n,
  input  logic [BANKS-1:0]      hbm_valid,
  input  logic [BANKS*4-1:0]    hbm_tags,
  input  logic [BANKS*DIM-1:0]  hbm_dsts,
  input  logic [15:0]           cbf_h_pred,
  input  logic [15:0]           act_u_cmd,
  output logic [BANKS-1:0]      bank_fired,
  output logic                  act_safe,
  output logic [15:0]           act_u_out
);
  genvar g;
  generate for (g = 0; g < BANKS; g = g + 1) begin : gen_bank
    logic [6:0] rv; logic arr; logic [DIM-1:0] nh;
    hx_v80_inet_tile #(.DIM(DIM)) u_tile (
      .clk(clk), .rst_n(rst_n), .tile_id(g[DIM-1:0]),
      .pair_valid(hbm_valid[g]), .pair_tag(hbm_tags[g*4 +: 4]), .dst_id(hbm_dsts[g*DIM +: DIM]),
      .rewrite_fired(bank_fired[g]), .rule_vec(rv), .pkt_arrived(arr), .next_hop(nh)
    );
  end endgenerate
  hx_cbf_hw_interlock u_cbf (.h_pred(cbf_h_pred), .u_cmd(act_u_cmd), .u_safe_fallback(16'd0), .cbf_safe(act_safe), .u_out(act_u_out));
endmodule
