// Mechanically lowered from certified PolyOptCert + F2OptCert suite (lib/ir/poly-opt.hypercubical)
module hx_poly_vx_coupled_eigen (input logic [31:0] v0, input logic [31:0] v1, input logic [31:0] v2, input logic [31:0] v3, input logic [31:0] v4, input logic [31:0] v5, input logic [31:0] v6, input logic [31:0] v7, output logic [31:0] y0, output logic [31:0] y1, output logic [31:0] y2);
  logic [31:0] v8; assign v8 = ((v0 + v1) * (v2 + v3));
  logic [31:0] v9; assign v9 = (v4 * v6);
  logic [31:0] v10; assign v10 = (v5 * v7);
  logic [31:0] v11; assign v11 = ((v4 + v5) * (v6 + v7));
  assign y0 = v8;
  assign y1 = (v9 - v10);
  assign y2 = ((v11 - v9) - v10);
endmodule

module hx_poly_vx_horner_deg3 (input logic [31:0] v0, input logic [31:0] v1, input logic [31:0] v2, input logic [31:0] v3, input logic [31:0] v4, output logic [31:0] y0);
  assign y0 = (v0 + (v4 * (v1 + (v4 * (v2 + (v4 * v3))))));
endmodule

module hx_poly_vx_lfsr_jump4 (input logic [31:0] v0, input logic [31:0] v1, input logic [31:0] v2, input logic [31:0] v3, input logic [31:0] v4, input logic [31:0] v5, input logic [31:0] v6, input logic [31:0] v7, output logic [31:0] y0, output logic [31:0] y1, output logic [31:0] y2, output logic [31:0] y3);
  assign y0 = ((v0 ^ v1) ^ v4);
  assign y1 = ((v1 ^ v2) ^ v5);
  assign y2 = ((v2 ^ v3) ^ v6);
  assign y3 = (((v0 ^ v1) ^ v3) ^ (v4 ^ v7));
endmodule

module hx_poly_vx_mux_pipe4 (input logic [31:0] v0, input logic [31:0] v1, input logic [31:0] v2, input logic [31:0] v3, input logic [31:0] v4, output logic [31:0] y0);
  logic [31:0] v5; assign v5 = (v0 & (v2 ^ v3));
  assign y0 = (v4 ^ (v1 & ((v3 ^ v4) ^ v5)));
endmodule


module hx_verify_formal_miter(
  input  logic [31:0] v0, v1, v2, v3, v4,
  output logic        miter_err_o
);
  logic [31:0] spec_y, opt_y;
  // Certified F2OptCert + PolyOptCert equivalence miter wire (0 iff Spec === Impl)
  assign spec_y = v0 + v4 * (v1 + v4 * (v2 + v4 * v3));
  opt_vx_horner_deg3 u_opt(.v0(v0), .v1(v1), .v2(v2), .v3(v3), .v4(v4), .out0(opt_y));
  assign miter_err_o = (spec_y != opt_y);
endmodule
