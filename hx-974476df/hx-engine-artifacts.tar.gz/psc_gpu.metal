// hx_psc1.metal — Single-Source PSC-1 Apple Metal GPU Compute Kernels (128b Coalesced 16-Weight/Iter)
#include <metal_stdlib>
using namespace metal;

inline float bf16_to_f32(uint32_t b) { return as_type<float>(b << 16); }

inline float unpack4_fma(uint32_t s4, uint32_t q4, threadgroup const uint32_t* p, device const uint8_t* esc_e, uint base4, float4 xv, float acc) {
  uint32_t i0 = q4 & 15u, i1 = (q4 >> 4) & 15u, i2 = (q4 >> 8) & 15u, i3 = (q4 >> 12) & 15u;
  uint32_t e0 = (i0 == 15u) ? (uint32_t(esc_e[base4+0u]) << 7) : p[i0];
  uint32_t e1 = (i1 == 15u) ? (uint32_t(esc_e[base4+1u]) << 7) : p[i1];
  uint32_t e2 = (i2 == 15u) ? (uint32_t(esc_e[base4+2u]) << 7) : p[i2];
  uint32_t e3 = (i3 == 15u) ? (uint32_t(esc_e[base4+3u]) << 7) : p[i3];
  acc = fma(bf16_to_f32(((s4 & 0x80u) << 8) | e0 | (s4 & 0x7Fu)), xv.x, acc);
  acc = fma(bf16_to_f32((((s4 >> 8) & 0x80u) << 8) | e1 | ((s4 >> 8) & 0x7Fu)), xv.y, acc);
  acc = fma(bf16_to_f32((((s4 >> 16) & 0x80u) << 8) | e2 | ((s4 >> 16) & 0x7Fu)), xv.z, acc);
  acc = fma(bf16_to_f32((((s4 >> 24) & 0x80u) << 8) | e3 | ((s4 >> 24) & 0x7Fu)), xv.w, acc);
  return acc;
}

// Plane 1+2: Fused 48b->64b Wire-Speed Lossless BF16 Unzip + Exact FP32 GEMV (128b coalesced!)
kernel void psc1_gemv_bf16_zip(
  device const uint4*    sm16     [[buffer(0)]],
  device const ushort4*  idx16    [[buffer(1)]],
  device const uint8_t*  pal      [[buffer(2)]],
  device const uint8_t*  esc_e    [[buffer(3)]],
  device const float4*   x4       [[buffer(4)]],
  device float*          y        [[buffer(5)]],
  constant uint32_t&     K4       [[buffer(6)]],
  uint row [[threadgroup_position_in_grid]],
  uint tid [[thread_index_in_threadgroup]],
  uint tgs [[threads_per_threadgroup]])
{
  threadgroup uint32_t p[16];
  if (tid < 16u) p[tid] = uint32_t(pal[row * 16u + tid]) << 7;
  threadgroup_barrier(mem_flags::mem_threadgroup);
  float acc = 0.0f;
  uint K16 = K4 >> 2;
  uint base16 = row * K16;
  for (uint j = tid; j < K16; j += tgs) {
    uint4 s16 = sm16[base16 + j];
    ushort4 q16 = idx16[base16 + j];
    uint j4 = j << 2;
    uint b4 = (base16 + j) << 4;
    acc = unpack4_fma(s16.x, uint32_t(q16.x), p, esc_e, b4 + 0u,  x4[j4 + 0u], acc);
    acc = unpack4_fma(s16.y, uint32_t(q16.y), p, esc_e, b4 + 4u,  x4[j4 + 1u], acc);
    acc = unpack4_fma(s16.z, uint32_t(q16.z), p, esc_e, b4 + 8u,  x4[j4 + 2u], acc);
    acc = unpack4_fma(s16.w, uint32_t(q16.w), p, esc_e, b4 + 12u, x4[j4 + 3u], acc);
  }
  acc = simd_sum(acc);
  threadgroup float tg[8];
  if ((tid & 31u) == 0u) tg[tid >> 5] = acc;
  threadgroup_barrier(mem_flags::mem_threadgroup);
  if (tid == 0u) {
    float s = 0.0f;
    uint nw = (tgs + 31u) >> 5;
    for (uint w = 0; w < nw; ++w) s += tg[w];
    y[row] = s;
  }
}

// Baseline: Vectorized 128b-Coalesced Uncompressed 64b/4-weight Raw BF16 GEMV
kernel void psc1_gemv_bf16_raw(
  device const ushort4*  W4       [[buffer(0)]],
  device const float4*   x4       [[buffer(1)]],
  device float*          y        [[buffer(2)]],
  constant uint32_t&     K4       [[buffer(3)]],
  uint row [[threadgroup_position_in_grid]],
  uint tid [[thread_index_in_threadgroup]],
  uint tgs [[threads_per_threadgroup]])
{
  float acc = 0.0f;
  uint K16 = K4 >> 2;
  uint base4 = row * K4;
  for (uint j = tid; j < K16; j += tgs) {
    uint j4 = j << 2;
    for (uint u = 0; u < 4u; ++u) {
      ushort4 w = W4[base4 + j4 + u];
      float4 xv = x4[j4 + u];
      acc = fma(bf16_to_f32(w.x), xv.x, acc);
      acc = fma(bf16_to_f32(w.y), xv.y, acc);
      acc = fma(bf16_to_f32(w.z), xv.z, acc);
      acc = fma(bf16_to_f32(w.w), xv.w, acc);
    }
  }
  acc = simd_sum(acc);
  threadgroup float tg[8];
  if ((tid & 31u) == 0u) tg[tid >> 5] = acc;
  threadgroup_barrier(mem_flags::mem_threadgroup);
  if (tid == 0u) {
    float s = 0.0f;
    uint nw = (tgs + 31u) >> 5;
    for (uint w = 0; w < nw; ++w) s += tg[w];
    y[row] = s;
  }
}

// Plane 3: Parallel 8-lane packed uint4 (L:XOR, Q:AND) Symbolic Fiber Propagation
kernel void psc1_fiber_bench(
  device uint32_t* out [[buffer(0)]],
  constant uint32_t& iters [[buffer(1)]],
  uint gid [[thread_position_in_grid]])
{
  uint32_t a = 0x9F63A5C1u ^ (gid * 0x9E3779B9u);
  uint32_t b = 0x5A3C96F1u ^ (gid * 0x85EBCA6Bu);
  for (uint i = 0; i < iters; ++i) {
    uint32_t a0=a&0x11111111u, a1=(a>>1)&0x11111111u, a2=(a>>2)&0x11111111u, a3=(a>>3)&0x11111111u;
    uint32_t b0=b&0x11111111u, b1=(b>>1)&0x11111111u, b2=(b>>2)&0x11111111u, b3=(b>>3)&0x11111111u;
    uint32_t c0=(a0&b0)|(a1&b1)|(a2&b2)|(a3&b3);
    uint32_t c1=(a0&b1)|(a1&b0)|(a2&b3)|(a3&b2);
    uint32_t c2=(a0&b2)|(a2&b0)|(a1&b3)|(a3&b1);
    uint32_t c3=(a0&b3)|(a3&b0)|(a1&b2)|(a2&b1);
    a = c0 | (c1<<1) | (c2<<2) | (c3<<3);
    b = (b << 4) | (b >> 28);
  }
  out[gid] = a;
}
