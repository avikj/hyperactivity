// Generated from lib/hx-omni.hypercubical — Apple Silicon Metal Unified Omni GPU Engine
#include <metal_stdlib>
using namespace metal;

inline uint32_t opt_cub_face_conflict4(uint32_t w0, uint32_t w1, uint32_t w2, uint32_t w3) {
  uint32_t w4 = ~(w2 & w2);
  uint32_t w5 = ~(w3 & w4);
  uint32_t w6 = ~(w5 & w4);
  uint32_t w7 = ~(w6 & w1);
  uint32_t w8 = ~(w6 & w0);
  uint32_t w9 = ~(w8 & w7);
  return w9;
}
inline uint32_t opt_cub_demorgan_alu4(uint32_t w0, uint32_t w1, uint32_t w2, uint32_t w3) {
  uint32_t w4 = ~(w3 & w1);
  uint32_t w5 = ~(w2 & w0);
  uint32_t w6 = ~(w2 & w5);
  uint32_t w7 = ~(w3 & w4);
  uint32_t w8 = ~(w5 & w0);
  uint32_t w9 = ~(w8 & w6);
  uint32_t w10 = ~(w4 & w1);
  uint32_t w11 = ~(w7 & w9);
  uint32_t w12 = ~(w11 & w10);
  return w12;
}
inline uint32_t opt_inet_era_either4(uint32_t w0, uint32_t w1, uint32_t w2, uint32_t w3) {
  uint32_t w4 = ~(w3 & w3);
  uint32_t w5 = ~(w2 & w4);
  uint32_t w6 = ~(w5 & w4);
  uint32_t w7 = ~(w0 & w6);
  uint32_t w8 = ~(w1 & w7);
  uint32_t w9 = ~(w8 & w7);
  uint32_t w10 = ~(w9 & w6);
  return w10;
}
inline uint32_t opt_inet_commute4(uint32_t w0, uint32_t w1, uint32_t w2, uint32_t w3) {
  uint32_t w4 = ~(w0 & w2);
  uint32_t w5 = ~(w1 & w0);
  uint32_t w6 = ~(w0 & w3);
  uint32_t w7 = ~(w3 & w2);
  uint32_t w8 = ~(w7 & w5);
  uint32_t w9 = ~(w6 & w4);
  uint32_t w10 = ~(w9 & w8);
  uint32_t w11 = ~(w10 & w9);
  uint32_t w12 = ~(w11 & w11);
  return w12;
}
inline uint32_t opt_inet_annihilate4(uint32_t w0, uint32_t w1, uint32_t w2, uint32_t w3) {
  uint32_t w4 = ~(w1 & w0);
  uint32_t w5 = ~(w2 & w4);
  uint32_t w6 = ~(w0 & w3);
  uint32_t w7 = ~(w5 & w0);
  uint32_t w8 = ~(w6 & w4);
  uint32_t w9 = ~(w8 & w5);
  uint32_t w10 = ~(w1 & w2);
  uint32_t w11 = ~(w6 & w7);
  uint32_t w12 = ~(w9 & w11);
  uint32_t w13 = ~(w12 & w12);
  return w13;
}
inline uint32_t opt_inet_vxchg_arb4(uint32_t w0, uint32_t w1, uint32_t w2, uint32_t w3) {
  uint32_t w4 = ~(w1 & w0);
  uint32_t w5 = ~(w0 & w4);
  uint32_t w6 = ~(w4 & w1);
  uint32_t w7 = ~(w3 & w2);
  uint32_t w8 = ~(w5 & w6);
  uint32_t w9 = ~(w7 & w8);
  uint32_t w10 = ~(w9 & w2);
  uint32_t w11 = ~(w2 & w10);
  uint32_t w12 = ~(w11 & w11);
  return w12;
}
inline uint32_t opt_inet_tag_neq4(uint32_t w0, uint32_t w1, uint32_t w2, uint32_t w3) {
  uint32_t w4 = ~(w0 & w2);
  uint32_t w5 = ~(w0 & w4);
  uint32_t w6 = ~(w2 & w4);
  uint32_t w7 = ~(w1 & w3);
  uint32_t w8 = ~(w1 & w7);
  uint32_t w9 = ~(w3 & w7);
  uint32_t w10 = ~(w5 & w8);
  uint32_t w11 = ~(w10 & w10);
  uint32_t w12 = ~(w6 & w9);
  uint32_t w13 = ~(w12 & w12);
  uint32_t w14 = ~(w11 & w13);
  return w14;
}
kernel void omni_metal_meta_inet(
  device const uint* seeds [[buffer(0)]],
  device uint* out_hash    [[buffer(1)]],
  constant uint& iters     [[buffer(2)]],
  uint tid [[thread_position_in_grid]]) {
  uint a = seeds[tid] ^ 0xAAAA5555u, b = (seeds[tid] * 2654435761u) ^ 0xCCCC3333u;
  uint c = (a ^ b) + 0xF0F00F0Fu, d = (a + b) ^ 0xFF0000FFu;
  uint acc = 0u;
  for (uint it = 0u; it < iters; it++) {
    uint r0 = opt_cub_face_conflict4(a, b, c, d);
    uint r1 = opt_cub_demorgan_alu4(a, b, c, d);
    uint r2 = opt_inet_era_either4(a, b, c, d);
    uint r3 = opt_inet_commute4(a, b, c, d);
    uint r4 = opt_inet_annihilate4(a, b, c, d);
    uint r5 = opt_inet_vxchg_arb4(a, b, c, d);
    uint r6 = opt_inet_tag_neq4(a, b, c, d);
    acc ^= (r0 ^ r1 ^ r2 ^ r3 ^ r4 ^ r5 ^ r6);
    a ^= (r0 + it); b ^= (r1 ^ r3); c ^= (r2 + r4); d ^= (r5 ^ r6);
  }
  out_hash[tid] = acc;
}

kernel void omni_metal_f2_tcount(
  device const uint* target_terms [[buffer(0)]],
  device uint* best_tcount        [[buffer(1)]],
  constant uint& n_terms          [[buffer(2)]],
  uint tid [[thread_position_in_grid]]) {
  uint rng = tid * 747796405u + 2891336453u;
  uchar acc_phase[64];
  for (uint i = 0u; i < 64u; i++) acc_phase[i] = 0;
  uint mask = 1u + (rng & 62u);
  for (uint k = 0u; k < n_terms; k++) {
    uint t = target_terms[k];
    uint par = t & 0x3Fu;
    uint ph  = (t >> 8u) & 7u;
    uint folded = (par & 32u) ? (par ^ (mask & 31u)) : par;
    acc_phase[folded] = (uchar)((acc_phase[folded] + ph) & 7u);
  }
  uint t_cnt = 0u;
  for (uint i = 1u; i < 64u; i++) t_cnt += (acc_phase[i] & 1u);
  best_tcount[tid] = t_cnt;
}

kernel void omni_metal_mps_contract(
  device const float* L_env [[buffer(0)]],
  device const float* A_mps [[buffer(1)]],
  device float* T_out       [[buffer(2)]],
  constant uint& chi        [[buffer(3)]],
  uint tid [[thread_position_in_grid]]) {
  uint c = tid % chi;
  uint tmp = tid / chi;
  uint s = tmp & 3u;
  uint tmp2 = tmp >> 2u;
  uint a = tmp2 % chi;
  uint site = tmp2 / chi;
  float sum = 0.0f;
  uint l_base = site * chi * chi + a * chi;
  uint a_base = site * 4u * chi * chi + s * chi * chi;
  for (uint b = 0u; b < chi; b++) sum = fma(L_env[l_base + b], A_mps[a_base + b * chi + c], sum);
  T_out[tid] = sum;
}

kernel void omni_metal_bf16_gemv_esc(
  device const uint* sm_packed   [[buffer(0)]],
  device const ushort* idx_pack  [[buffer(1)]],
  device const uchar* esc_exp    [[buffer(2)]],
  device const float* x          [[buffer(3)]],
  device float* y                [[buffer(4)]],
  constant uint& cols4           [[buffer(5)]],
  uint row [[thread_position_in_grid]]) {
  float acc = 0.0f;
  uint base = row * cols4;
  for (uint c = 0u; c < cols4; c++) {
    uint lo = sm_packed[base + c];
    uint hi = (uint)idx_pack[base + c];
    for (uint k = 0u; k < 4u; k++) {
      uint sm = (lo >> (k * 8u)) & 0xFFu;
      uint ix = (hi >> (k * 4u)) & 0xFu;
      uint ex = (ix == 15u) ? (uint)esc_exp[(base + c) * 4u + k] : (ix + 116u);
      uint u32 = (((sm & 0x80u) << 8u) | (ex << 7u) | (sm & 0x7Fu)) << 16u;
      acc = fma(as_type<float>(u32), x[c * 4u + k], acc);
    }
  }
  y[row] = acc;
}
