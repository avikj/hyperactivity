// Generated from lib/ir/hx-hxp-ir.hypercubical: 1-Cycle SerDes->Lut6 HXP Superconductor
module hxp_hexagram_superconductor (
  input  wire [5:0]  hex_in,
  input  wire [5:0]  moving_dh,
  input  wire [63:0] lut6_table,
  input  wire signed [31:0] w01_in, w12_in, w20_in,
  output wire [5:0]  hex_out,
  output wire        divination_bit,
  output wire signed [31:0] w01_meissner_healed,
  output wire signed [31:0] residual_curl
);
  assign hex_out             = hex_in ^ moving_dh;
  assign divination_bit      = lut6_table[hex_out];
  wire signed [31:0] curl    = w01_in + w12_in + w20_in;
  assign w01_meissner_healed = w01_in - curl;
  assign residual_curl       = w01_meissner_healed + w12_in + w20_in;
endmodule







