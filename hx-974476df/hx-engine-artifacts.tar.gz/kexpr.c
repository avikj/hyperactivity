/* Generated mechanically by lib/ir/kexpr.hypercubical (hx kexpr, 29th engine) */
#include <stdint.h>
#include <stdio.h>
static inline uint32_t ke_s0(uint32_t x0) { return ((((x0 >> 2u) | (x0 << 30u)) ^ ((x0 >> 13u) | (x0 << 19u))) ^ ((x0 >> 22u) | (x0 << 10u))); }
static inline uint32_t ke_s1(uint32_t x0) { return ((((x0 >> 6u) | (x0 << 26u)) ^ ((x0 >> 11u) | (x0 << 21u))) ^ ((x0 >> 25u) | (x0 << 7u))); }
static inline uint32_t ke_ch(uint32_t x0, uint32_t x1, uint32_t x2) { return (x2 ^ (x0 & (x1 ^ x2))); }
static inline uint32_t ke_maj(uint32_t x0, uint32_t x1, uint32_t x2) { return (x0 ^ ((x0 ^ x1) & (x0 ^ x2))); }
static inline uint32_t ke_t2(uint32_t x0, uint32_t x1, uint32_t x2) { return (((((x0 >> 2u) | (x0 << 30u)) ^ ((x0 >> 13u) | (x0 << 19u))) ^ ((x0 >> 22u) | (x0 << 10u))) + (x0 ^ ((x0 ^ x1) & (x0 ^ x2)))); }
int main(void) {
  uint32_t a=0x6a09e667u, b=0xbb67ae85u, c=0x3c6ef372u;
  uint32_t t2 = ke_t2(a, b, c);
  printf("KEXPR-C11 exact=1 s0=0x%08x ch=0x%08x maj=0x%08x t2=0x%08x\n", ke_s0(a), ke_ch(a,b,c), ke_maj(a,b,c), t2);
  return (t2 == (ke_s0(a) + ke_maj(a,b,c))) ? 0 : 1;
}
