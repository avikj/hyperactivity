// Generated from lib/hx-omni.hypercubical — NVIDIA 8xH100 sm_90a Unified Omni Engine
// Mechanically lowers ALL 7 MetaCircuit 61-NAND2 blocks + Escape-Safe Warp-LUT BF16 GEMV
#include <cuda_runtime.h>
#include <stdint.h>
#include <stdio.h>

__device__ __forceinline__ uint32_t mc_cub_face_conflict4(uint32_t w0, uint32_t w1, uint32_t w2, uint32_t w3) {
  uint32_t w4 = ~(w2 & w2);
  uint32_t w5 = ~(w3 & w4);
  uint32_t w6 = ~(w5 & w4);
  uint32_t w7 = ~(w6 & w1);
  uint32_t w8 = ~(w6 & w0);
  uint32_t w9 = ~(w8 & w7);
  return w9;
}

__device__ __forceinline__ uint32_t mc_cub_demorgan_alu4(uint32_t w0, uint32_t w1, uint32_t w2, uint32_t w3) {
  uint32_t w4 = ~(w3 & w1);
  uint32_t w5 = ~(w2 & w0);
  uint32_t w6 = ~(w2 & w5);
  uint32_t w7 = ~(w3 & w4);
  uint32_t w8 = ~(w5 & w0);
  uint32_t w9 = ~(w8 & w6);
  uint32_t w10 = ~(w4 & w1);
  uint32_t w11 = ~(w7 & w9);
  uint32_t w12 = ~(w11 & w10);
  return w12;
}

__device__ __forceinline__ uint32_t mc_inet_era_either4(uint32_t w0, uint32_t w1, uint32_t w2, uint32_t w3) {
  uint32_t w4 = ~(w3 & w3);
  uint32_t w5 = ~(w2 & w4);
  uint32_t w6 = ~(w5 & w4);
  uint32_t w7 = ~(w0 & w6);
  uint32_t w8 = ~(w1 & w7);
  uint32_t w9 = ~(w8 & w7);
  uint32_t w10 = ~(w9 & w6);
  return w10;
}

__device__ __forceinline__ uint32_t mc_inet_commute4(uint32_t w0, uint32_t w1, uint32_t w2, uint32_t w3) {
  uint32_t w4 = ~(w0 & w2);
  uint32_t w5 = ~(w1 & w0);
  uint32_t w6 = ~(w0 & w3);
  uint32_t w7 = ~(w3 & w2);
  uint32_t w8 = ~(w7 & w5);
  uint32_t w9 = ~(w6 & w4);
  uint32_t w10 = ~(w9 & w8);
  uint32_t w11 = ~(w10 & w9);
  uint32_t w12 = ~(w11 & w11);
  return w12;
}

__device__ __forceinline__ uint32_t mc_inet_annihilate4(uint32_t w0, uint32_t w1, uint32_t w2, uint32_t w3) {
  uint32_t w4 = ~(w1 & w0);
  uint32_t w5 = ~(w2 & w4);
  uint32_t w6 = ~(w0 & w3);
  uint32_t w7 = ~(w5 & w0);
  uint32_t w8 = ~(w6 & w4);
  uint32_t w9 = ~(w8 & w5);
  uint32_t w10 = ~(w1 & w2);
  uint32_t w11 = ~(w6 & w7);
  uint32_t w12 = ~(w9 & w11);
  uint32_t w13 = ~(w12 & w12);
  return w13;
}

__device__ __forceinline__ uint32_t mc_inet_vxchg_arb4(uint32_t w0, uint32_t w1, uint32_t w2, uint32_t w3) {
  uint32_t w4 = ~(w1 & w0);
  uint32_t w5 = ~(w0 & w4);
  uint32_t w6 = ~(w4 & w1);
  uint32_t w7 = ~(w3 & w2);
  uint32_t w8 = ~(w5 & w6);
  uint32_t w9 = ~(w7 & w8);
  uint32_t w10 = ~(w9 & w2);
  uint32_t w11 = ~(w2 & w10);
  uint32_t w12 = ~(w11 & w11);
  return w12;
}

__device__ __forceinline__ uint32_t mc_inet_tag_neq4(uint32_t w0, uint32_t w1, uint32_t w2, uint32_t w3) {
  uint32_t w4 = ~(w0 & w2);
  uint32_t w5 = ~(w0 & w4);
  uint32_t w6 = ~(w2 & w4);
  uint32_t w7 = ~(w1 & w3);
  uint32_t w8 = ~(w1 & w7);
  uint32_t w9 = ~(w3 & w7);
  uint32_t w10 = ~(w5 & w8);
  uint32_t w11 = ~(w10 & w10);
  uint32_t w12 = ~(w6 & w9);
  uint32_t w13 = ~(w12 & w12);
  uint32_t w14 = ~(w11 & w13);
  return w14;
}

__global__ void omni_h100_meta_inet(const uint32_t* in0, const uint32_t* in1, const uint32_t* in2, const uint32_t* in3, uint32_t* out, uint32_t n) {
  uint32_t tid = blockIdx.x * blockDim.x + threadIdx.x; if (tid >= n) return;
  uint32_t a = in0[tid], b = in1[tid], c = in2[tid], d = in3[tid];
  uint32_t r = mc_cub_face_conflict4(a, b, c, d) ^ mc_cub_demorgan_alu4(a, b, c, d)
             ^ mc_inet_era_either4(a, b, c, d) ^ mc_inet_commute4(a, b, c, d)
             ^ mc_inet_annihilate4(a, b, c, d) ^ mc_inet_vxchg_arb4(a, b, c, d) ^ mc_inet_tag_neq4(a, b, c, d);
  out[tid] = r;
}

__device__ __forceinline__ float bf16_to_f32_u16(uint32_t h) {
  uint32_t u = h << 16u; return __uint_as_float(u);
}
__global__ void omni_h100_bf16_gemv_esc(const uint32_t* sm_packed, const uint16_t* idx_packed,
  const uint8_t* esc_exp, const float* x, float* y, uint32_t rows, uint32_t cols4) {
  uint32_t r = blockIdx.x * blockDim.y + threadIdx.y;
  if (r >= rows) return;
  uint32_t lane = threadIdx.x; float acc = 0.0f; uint32_t base = r * cols4;
  for (uint32_t c = lane; c < cols4; c += 32u) {
    uint32_t lo = sm_packed[base + c]; uint32_t hi = idx_packed[base + c];
    #pragma unroll
    for (int k = 0; k < 4; k++) {
      uint32_t sm = (lo >> (k * 8)) & 0xFFu;
      uint32_t ix = (hi >> (k * 4)) & 0xFu;
      uint32_t ex = (ix == 15u) ? (uint32_t)esc_exp[(base + c) * 4u + k] : (ix + 116u);
      uint32_t w16 = ((sm & 0x80u) << 8u) | (ex << 7u) | (sm & 0x7Fu);
      acc = fmaf(bf16_to_f32_u16(w16), x[c * 4u + k], acc);
    }
  }
  for (int off = 16; off > 0; off >>= 1) acc += __shfl_down_sync(0xFFFFFFFFu, acc, off);
  if (lane == 0u) y[r] = acc;
}

int main(void) {
  int ng = 0; cudaGetDeviceCount(&ng);
  printf("HX-OMNI 8xH100 sm_90a Engine (%d GPUs) | 7 MetaCircuit NAND2 + Escape-Safe BF16 GEMV\n", ng);
  return 0;
}
