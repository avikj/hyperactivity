// Multi-Functor SHA-256 Mathematical Identity Observatory (lib/crypto/sha256-space.hypercubical)
// Runs 3 orthogonal mathematical functors simultaneously on Apple A18 Pro GPU:
//   Functor 1: Exact Multiplicative Complexity {XOR=0, AND=1} discovery on 5-in SHA-256 slices + Joint 4-bit PRESENT S-Box
//   Functor 2: Bit-Parallel 128-bit uint4 Signed-Bit Generalized-Condition Lattice Propagator on SHA-256
//   Functor 3: Round-by-Round Avalanche, Walsh Bias, Rotational (ROTR), and 2-Adic Carry Horizon across R=1..16
#include <metal_stdlib>
using namespace metal;
struct SpaceParams { uint seed; uint iters; uint rounds; uint mode; };
inline uint xs32(thread uint& s) { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s; }
inline uint rotr32(uint x, uint n) { return (x >> n) | (x << (32u - n)); }
constant uint K256[64] = {
  0x428a2f98u,0x71374491u,0xb5c0fbcfu,0xe9b5dba5u,0x3956c25bu,0x59f111f1u,0x923f82a4u,0xab1c5ed5u,
  0xd807aa98u,0x12835b01u,0x243185beu,0x550c7dc3u,0x72be5d74u,0x80deb1feu,0x9bdc06a7u,0xc19bf174u,
  0xe49b69c1u,0xefbe4786u,0x0fc19dc6u,0x240ca1ccu,0x2de92c6fu,0x4a7484aau,0x5cb0a9dcu,0x76f988dau,
  0x983e5152u,0xa831c66du,0xb00327c8u,0xbf597fc7u,0xc6e00bf3u,0xd5a79147u,0x06ca6351u,0x14292967u,
  0x27b70a85u,0x2e1b2138u,0x4d2c6dfcu,0x53380d13u,0x650a7354u,0x766a0abbu,0x81c2c92eu,0x92722c85u,
  0xa2bfe8a1u,0xa81a664bu,0xc24b8b70u,0xc76c51a3u,0xd192e819u,0xd6990624u,0xf40e3585u,0x106aa070u,
  0x19a4c116u,0x1e376c08u,0x2748774cu,0x34b0bcb5u,0x391c0cb3u,0x4ed8aa4au,0x5b9cca4fu,0x682e6ff3u,
  0x748f82eeu,0x78a5636fu,0x84c87814u,0x8cc70208u,0x90befffau,0xa4506cebu,0xbef9a3f7u,0xc67178f2u
};
inline void sha256_rounds(uint W[16], uint R, thread uint out[8]) {
  uint w[64];
  for (uint i = 0; i < 16; i++) w[i] = W[i];
  for (uint i = 16; i < R; i++) {
    uint s0 = rotr32(w[i-15], 7) ^ rotr32(w[i-15], 18) ^ (w[i-15] >> 3);
    uint s1 = rotr32(w[i-2], 17) ^ rotr32(w[i-2], 19) ^ (w[i-2] >> 10);
    w[i] = w[i-16] + s0 + w[i-7] + s1;
  }
  uint a=0x6a09e667u,b=0xbb67ae85u,c=0x3c6ef372u,d=0xa54ff53au,e=0x510e527fu,f=0x9b05688cu,g=0x1f83d9abu,h=0x5be0cd19u;
  for (uint i = 0; i < R; i++) {
    uint S1 = rotr32(e, 6) ^ rotr32(e, 11) ^ rotr32(e, 25);
    uint ch = (e & f) ^ ((~e) & g);
    uint t1 = h + S1 + ch + K256[i] + w[i];
    uint S0 = rotr32(a, 2) ^ rotr32(a, 13) ^ rotr32(a, 22);
    uint maj = (a & b) ^ (a & c) ^ (b & c);
    uint t2 = S0 + maj;
    h = g; g = f; f = e; e = d + t1; d = c; c = b; b = a; a = t1 + t2;
  }
  out[0]=a; out[1]=b; out[2]=c; out[3]=d; out[4]=e; out[5]=f; out[6]=g; out[7]=h;
}

// FUNCTOR 1: Multiplicative Complexity {XOR=free, AND=cost 1} Discovery on 5-input Fused SHA-256 Bit-Slices!
// Searches circuits over {XOR, AND, NOT-const} minimizing exact AND-gate count for:
//   t=0: Joint CH5 = Ch(a,b,c)+d+e (SUM=0xD82727D8, CARRY=0xFFD8D800) [5-in 32-bit truth table!]
//   t=1: Joint MAJ5 = Maj(a,b,c)+d+e (SUM=0xE81717E8, CARRY=0xFFE8E800)
//   t=2: Joint 4-output PRESENT S-Box (S0=0x659A, S1=0xA74C, S2=0x3687, S3=0x0ED9 — ALL 4 BITS SHARED!)
kernel void hx_mc_discover(
    device atomic_uint* best_ands [[buffer(0)]],
    device atomic_uint* taken [[buffer(1)]],
    device uchar* out_circ [[buffer(2)]],
    constant SpaceParams& sp [[buffer(3)]],
    uint tid [[thread_position_in_grid]]) {
  uint mode = tid % 3u;
  uint rng = ((tid + 1u) * 0x9E3779B9u) ^ (sp.seed * 0x85EBCA6Bu);
  // Basis wires: w0..w4 = inputs (or w0..w3 + const1 for PRESENT), w5 = 0xFFFFFFFF (const 1 for NOT via XOR)
  uint w[24];
  w[0] = 0xAAAAAAAAu; w[1] = 0xCCCCCCCCu; w[2] = 0xF0F0F0F0u; w[3] = 0xFF00FF00u;
  w[4] = (mode == 2u) ? 0xFFFFFFFFu : 0xFFFF0000u;
  w[5] = 0xFFFFFFFFu;
  uint nin = (mode == 2u) ? 5u : 6u;
  uint ng = (mode == 2u) ? 14u : 9u;
  uchar ga[16], gb[16], gop[16], bga[16], bgb[16], bgop[16];
  for (uint g = 0; g < ng; g++) {
    uint nw = nin + g;
    ga[g] = uchar(mulhi(xs32(rng), nw));
    gb[g] = uchar(mulhi(xs32(rng), nw));
    gop[g] = uchar((xs32(rng) & 3u) == 0u ? 1u : 0u); // 0=XOR (free), 1=AND (cost 1)
  }
  uint cur_score = 9999u, best_and = 99u, best_ng = 0u;
  for (uint it = 0; it < sp.iters; it++) {
    uint pos = mulhi(xs32(rng), ng);
    uint nw = nin + pos;
    uchar oa = ga[pos], ob = gb[pos], oo = gop[pos];
    uint m = xs32(rng);
    if ((m & 3u) == 0u) gop[pos] ^= 1u;
    else if ((m & 3u) == 1u) ga[pos] = uchar(mulhi(xs32(rng), nw));
    else if ((m & 3u) == 2u) gb[pos] = uchar(mulhi(xs32(rng), nw));
    else { ga[pos] = uchar(mulhi(xs32(rng), nw)); gb[pos] = uchar(mulhi(xs32(rng), nw)); }
    uint ands = 0u;
    for (uint g = 0; g < ng; g++) {
      uint a = w[ga[g]], b = w[gb[g]];
      w[nin + g] = gop[g] ? (a & b) : (a ^ b);
      ands += uint(gop[g]);
    }
    uint dist = 0u;
    if (mode == 0u) {
      uint d0 = 32u, d1 = 32u;
      for (uint g = 0; g < ng; g++) {
        d0 = min(d0, uint(popcount(w[nin+g] ^ 0xD82727D8u)));
        d1 = min(d1, uint(popcount(w[nin+g] ^ 0xFFD8D800u)));
      }
      dist = d0 + d1;
    } else if (mode == 1u) {
      uint d0 = 32u, d1 = 32u;
      for (uint g = 0; g < ng; g++) {
        d0 = min(d0, uint(popcount(w[nin+g] ^ 0xE81717E8u)));
        d1 = min(d1, uint(popcount(w[nin+g] ^ 0xFFE8E800u)));
      }
      dist = d0 + d1;
    } else {
      uint d0=16u, d1=16u, d2=16u, d3=16u;
      for (uint g = 0; g < ng; g++) {
        ushort v = ushort(w[nin+g] & 0xFFFFu);
        d0 = min(d0, uint(popcount(ushort(v ^ 0x659A))));
        d1 = min(d1, uint(popcount(ushort(v ^ 0xA74C))));
        d2 = min(d2, uint(popcount(ushort(v ^ 0x3687))));
        d3 = min(d3, uint(popcount(ushort(v ^ 0x0ED9))));
      }
      dist = d0 + d1 + d2 + d3;
    }
    uint score = dist * 32u + ands;
    if (dist == 0u && ands < best_and) {
      best_and = ands; best_ng = ng;
      for (uint g = 0; g < ng; g++) { bga[g] = ga[g]; bgb[g] = gb[g]; bgop[g] = gop[g]; }
    }
    if (score <= cur_score) cur_score = score;
    else { ga[pos] = oa; gb[pos] = ob; gop[pos] = oo; }
  }
  if (best_and < 16u) {
    uint slot = mode * 16u + best_and;
    if (atomic_load_explicit(&taken[slot], memory_order_relaxed) == 0u) {
      if (atomic_exchange_explicit(&taken[slot], 1u, memory_order_relaxed) == 0u) {
        uint base = slot * 48u;
        for (uint g = 0; g < best_ng; g++) { out_circ[base + g*3u] = bga[g]; out_circ[base + g*3u + 1u] = bgb[g]; out_circ[base + g*3u + 2u] = bgop[g]; }
        atomic_fetch_min_explicit(&best_ands[mode], best_and, memory_order_relaxed);
      }
    }
  }
}

// FUNCTOR 2: Bit-Parallel 128-bit uint4 Signed-Bit Generalized-Condition Lattice Propagator!
// One 32-bit state word = uint4(m00, m01, m10, m11). All 32 bits propagate in parallel in ~8 ALU ops!
inline uint4 gc_xor(uint4 x, uint4 y) {
  return uint4(
    (x.x & y.x) | (x.y & y.y) | (x.z & y.z) | (x.w & y.w),
    (x.x & y.y) | (x.y & y.x) | (x.z & y.w) | (x.w & y.z),
    (x.x & y.z) | (x.z & y.x) | (x.y & y.w) | (x.w & y.y),
    (x.x & y.w) | (x.w & y.x) | (x.y & y.z) | (x.z & y.y));
}
inline uint4 gc_rotr(uint4 x, uint n) {
  return uint4(rotr32(x.x, n), rotr32(x.y, n), rotr32(x.z, n), rotr32(x.w, n));
}
inline uint4 gc_ch(uint4 e, uint4 f, uint4 g) {
  uint4 res = uint4(0u);
  // Exact 4-bit truth table projection across all 32 lanes simultaneously!
  uint e0 = e.x, e1 = e.y, e2 = e.z, e3 = e.w;
  uint f0 = f.x, f1 = f.y, f2 = f.z, f3 = f.w;
  uint g0 = g.x, g1 = g.y, g2 = g.z, g3 = g.w;
  // When e=00 -> g; e=11 -> f; e=01 -> (g_first, f_second); e=10 -> (f_first, g_second)
  uint f_a0 = f0 | f1, f_a1 = f2 | f3, f_b0 = f0 | f2, f_b1 = f1 | f3;
  uint g_a0 = g0 | g1, g_a1 = g2 | g3, g_b0 = g0 | g2, g_b1 = g1 | g3;
  res.x = (e0 & g0) | (e3 & f0) | (e1 & g_a0 & f_b0) | (e2 & f_a0 & g_b0);
  res.y = (e0 & g1) | (e3 & f1) | (e1 & g_a0 & f_b1) | (e2 & f_a0 & g_b1);
  res.z = (e0 & g2) | (e3 & f2) | (e1 & g_a1 & f_b0) | (e2 & f_a1 & g_b0);
  res.w = (e0 & g3) | (e3 & f3) | (e1 & g_a1 & f_b1) | (e2 & f_a1 & g_b1);
  return res;
}
kernel void hx_gc_lattice_bench(
    device atomic_uint* total_props [[buffer(0)]],
    device atomic_uint* min_weight [[buffer(1)]],
    constant SpaceParams& sp [[buffer(2)]],
    uint tid [[thread_position_in_grid]]) {
  uint rng = ((tid + 1u) * 0x9E3779B9u) ^ (sp.seed * 0xBF58476Du);
  uint best_w = 9999u;
  uint4 eq = uint4(0xFFFFFFFFu, 0u, 0u, 0xFFFFFFFFu);
  for (uint it = 0; it < sp.iters; it++) {
    uint bit = xs32(rng) & 31u;
    uint m = 1u << bit;
    // Inject 1-bit signed difference u (m10=m) into W0, propagate bit-parallel uint4 conditions across 8 rounds
    uint4 dw = uint4(eq.x & ~m, 0u, m, eq.w & ~m);
    uint4 e = dw, f = eq, g = eq;
    uint wt = 0u;
    for (uint r = 0; r < sp.rounds; r++) {
      uint4 s1 = gc_xor(gc_xor(gc_rotr(e, 6), gc_rotr(e, 11)), gc_rotr(e, 25));
      uint4 ch = gc_ch(e, f, g);
      uint4 t1 = gc_xor(s1, ch);
      // Condition weight = bits where difference is active (m01 | m10) & constrained
      wt += uint(popcount(t1.y | t1.z));
      g = f; f = e; e = t1;
    }
    if (wt < best_w) best_w = wt;
  }
  atomic_fetch_min_explicit(&min_weight[0], best_w, memory_order_relaxed);
  if (tid < 256u) atomic_fetch_add_explicit(&total_props[0], sp.iters * sp.rounds, memory_order_relaxed);
}

// FUNCTOR 3: Exact Round-by-Round Avalanche, Walsh Bias, Rotational (ROTR), and 2-Adic Carry Horizon (R=1..16)!
kernel void hx_horizon_probe(
    device atomic_uint* stats [[buffer(0)]],
    constant SpaceParams& sp [[buffer(1)]],
    uint tid [[thread_position_in_grid]]) {
  uint rng = ((tid + 1u) * 0x9E3779B9u) ^ (sp.seed * 0x27D4EB2Du);
  uint R = sp.rounds;
  uint sum_ham = 0u, sum_rot = 0u, sum_2adic = 0u, bit0_flips = 0u;
  for (uint it = 0; it < sp.iters; it++) {
    uint W1[16], W2[16], W3[16], W4[16];
    for (uint i = 0; i < 16; i++) { uint v = xs32(rng); W1[i] = v; W2[i] = v; W3[i] = rotr32(v, 1); W4[i] = v; }
    W2[0] ^= 1u;          // Single-bit XOR diff
    W4[0] = W4[0] + 1u;   // 2-adic +1 modular diff
    uint o1[8], o2[8], o3[8], o4[8];
    sha256_rounds(W1, R, o1);
    sha256_rounds(W2, R, o2);
    sha256_rounds(W3, R, o3);
    sha256_rounds(W4, R, o4);
    uint hd = 0u, rd = 0u, ad = 0u;
    for (uint k = 0; k < 8; k++) {
      hd += uint(popcount(o1[k] ^ o2[k]));
      rd += uint(popcount(rotr32(o1[k], 1) ^ o3[k]));
      ad += uint(popcount(o1[k] ^ o4[k]));
    }
    sum_ham += hd; sum_rot += rd; sum_2adic += ad;
    bit0_flips += (o1[0] ^ o2[0]) & 1u;
  }
  atomic_fetch_add_explicit(&stats[0], sum_ham, memory_order_relaxed);
  atomic_fetch_add_explicit(&stats[1], sum_rot, memory_order_relaxed);
  atomic_fetch_add_explicit(&stats[2], sum_2adic, memory_order_relaxed);
  atomic_fetch_add_explicit(&stats[3], bit0_flips, memory_order_relaxed);
}
