#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
typedef struct { uint32_t M, N, K; } GemmDims;
typedef struct { uint32_t N, D; float scale; } AttnDims;
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1e3 + ts.tv_nsec * 1e-6; }
int main(void) { @autoreleasepool {
  id<MTLDevice> dev = MTLCreateSystemDefaultDevice();
  if (!dev) { printf(
"NO_METAL_DEVICE"); putchar(10); return 1; }
  NSError *err = nil;
  NSString *src = [NSString stringWithContentsOfFile:[NSString stringWithUTF8String:"/home/claude/hxb/out/gpu_flash.metal"] encoding:NSUTF8StringEncoding error:&err];
  id<MTLLibrary> lib = [dev newLibraryWithSource:src options:nil error:&err];
  if (!lib) { fprintf(stderr, 
"METAL_ERR: %s", err.localizedDescription.UTF8String); fputc(10, stderr); return 2; }
  id<MTLCommandQueue> q = [dev newCommandQueue];
  id<MTLComputePipelineState> pGemm = [dev newComputePipelineStateWithFunction:[lib newFunctionWithName:[NSString stringWithUTF8String:"hx_gemm_simd16"]] error:&err];
  id<MTLComputePipelineState> pAttn = [dev newComputePipelineStateWithFunction:[lib newFunctionWithName:[NSString stringWithUTF8String:"hx_flash_attn_simd16"]] error:&err];
  const uint32_t M = 2048, N = 2048, K = 2048;
  id<MTLBuffer> bA = [dev newBufferWithLength:M*K*2 options:MTLResourceStorageModeShared];
  id<MTLBuffer> bB = [dev newBufferWithLength:K*N*2 options:MTLResourceStorageModeShared];
  id<MTLBuffer> bC = [dev newBufferWithLength:M*N*4 options:MTLResourceStorageModeShared];
  _Float16 *A = bA.contents, *B = bB.contents; float *C = bC.contents;
  for (uint32_t i = 0; i < M*K; i++) A[i] = (_Float16)((float)((int)(i % 17) - 8) * 0.0625f);
  for (uint32_t i = 0; i < K*N; i++) B[i] = (_Float16)((float)((int)((i * 7) % 19) - 9) * 0.0625f);
  GemmDims gd = { M, N, K };
  MTLSize gGrid = MTLSizeMake(N/32, M/32, 1), gGrp = MTLSizeMake(128, 1, 1);
  id<MTLCommandBuffer> cb0 = [q commandBuffer]; id<MTLComputeCommandEncoder> e0 = [cb0 computeCommandEncoder];
  [e0 setComputePipelineState:pGemm]; [e0 setBuffer:bA offset:0 atIndex:0]; [e0 setBuffer:bB offset:0 atIndex:1]; [e0 setBuffer:bC offset:0 atIndex:2]; [e0 setBytes:&gd length:sizeof(gd) atIndex:3];
  [e0 dispatchThreadgroups:gGrid threadsPerThreadgroup:gGrp]; [e0 endEncoding]; [cb0 commit]; [cb0 waitUntilCompleted];
  double t0 = now_ms();
  id<MTLCommandBuffer> cbB = [q commandBuffer]; id<MTLComputeCommandEncoder> encB = [cbB computeCommandEncoder];
  [encB setComputePipelineState:pGemm]; [encB setBuffer:bA offset:0 atIndex:0]; [encB setBuffer:bB offset:0 atIndex:1]; [encB setBuffer:bC offset:0 atIndex:2]; [encB setBytes:&gd length:sizeof(gd) atIndex:3];
  for (int it = 0; it < 20; it++) [encB dispatchThreadgroups:gGrid threadsPerThreadgroup:gGrp];
  [encB endEncoding]; [cbB commit]; [cbB waitUntilCompleted];
  double gemm_ms = (now_ms() - t0) / 20.0;
  double gflops = (2.0 * M * N * K) / (gemm_ms * 1e6);
  double max_gerr = 0.0;
  for (uint32_t r = 0; r < M; r += 128) for (uint32_t c = 0; c < N; c += 128) {
    double ref = 0.0; for (uint32_t k = 0; k < K; k++) ref += (double)A[r*K+k] * (double)B[k*N+c];
    double e = fabs((double)C[r*N+c] - ref); if (e > max_gerr) max_gerr = e;
  }
  const uint32_t AN = 1024, AD = 64; float sc = 1.0f / sqrtf((float)AD);
  id<MTLBuffer> bQ = [dev newBufferWithLength:AN*AD*2 options:MTLResourceStorageModeShared];
  id<MTLBuffer> bK = [dev newBufferWithLength:AN*AD*2 options:MTLResourceStorageModeShared];
  id<MTLBuffer> bV = [dev newBufferWithLength:AN*AD*2 options:MTLResourceStorageModeShared];
  id<MTLBuffer> bO = [dev newBufferWithLength:AN*AD*4 options:MTLResourceStorageModeShared];
  _Float16 *Q = bQ.contents, *Km = bK.contents, *V = bV.contents; float *O = bO.contents;
  for (uint32_t i = 0; i < AN*AD; i++) { Q[i] = (_Float16)(sinf(i*0.013f)*0.5f); Km[i] = (_Float16)(cosf(i*0.017f)*0.5f); V[i] = (_Float16)sinf(i*0.023f); }
  AttnDims ad = { AN, AD, sc };
  MTLSize aGrid = MTLSizeMake(AN/32, 1, 1), aGrp = MTLSizeMake(128, 1, 1);
  id<MTLCommandBuffer> cba0 = [q commandBuffer]; id<MTLComputeCommandEncoder> ea0 = [cba0 computeCommandEncoder];
  [ea0 setComputePipelineState:pAttn]; [ea0 setBuffer:bQ offset:0 atIndex:0]; [ea0 setBuffer:bK offset:0 atIndex:1]; [ea0 setBuffer:bV offset:0 atIndex:2]; [ea0 setBuffer:bO offset:0 atIndex:3]; [ea0 setBytes:&ad length:sizeof(ad) atIndex:4];
  [ea0 dispatchThreadgroups:aGrid threadsPerThreadgroup:aGrp]; [ea0 endEncoding]; [cba0 commit]; [cba0 waitUntilCompleted];
  double ta0 = now_ms();
  id<MTLCommandBuffer> cbA = [q commandBuffer]; id<MTLComputeCommandEncoder> encA = [cbA computeCommandEncoder];
  [encA setComputePipelineState:pAttn]; [encA setBuffer:bQ offset:0 atIndex:0]; [encA setBuffer:bK offset:0 atIndex:1]; [encA setBuffer:bV offset:0 atIndex:2]; [encA setBuffer:bO offset:0 atIndex:3]; [encA setBytes:&ad length:sizeof(ad) atIndex:4];
  for (int it = 0; it < 40; it++) [encA dispatchThreadgroups:aGrid threadsPerThreadgroup:aGrp];
  [encA endEncoding]; [cbA commit]; [cbA waitUntilCompleted];
  double attn_gpu_ms = (now_ms() - ta0) / 40.0;
  double tc0 = now_ms(); double max_aerr = 0.0;
  for (uint32_t i = 0; i < AN; i++) {
    double m = -1e30, l = 0.0, acc[64]; for (uint32_t d = 0; d < AD; d++) acc[d] = 0.0;
    for (uint32_t j = 0; j < AN; j++) {
      double dot = 0.0; for (uint32_t d = 0; d < AD; d++) dot += (double)Q[i*AD+d] * (double)Km[j*AD+d];
      double s = dot * sc, mn = s > m ? s : m, a = exp(m - mn), b = exp(s - mn);
      l = l * a + b; for (uint32_t d = 0; d < AD; d++) acc[d] = acc[d] * a + b * (double)V[j*AD+d]; m = mn;
    }
    for (uint32_t d = 0; d < AD; d++) { double e = fabs((double)O[i*AD+d] - acc[d]/l); if (e > max_aerr) max_aerr = e; }
  }
  double attn_cpu_ms = now_ms() - tc0;
  printf("GPU=%s | TensorIR SIMD16 GEMM 2048^3: %.2f ms (%.1f GFLOP/s, max_err=%.2e) | TensorIR FlashAttn2 1024x64: GPU=%.2f ms vs CPU=%.2f ms (%.1fx speedup, max_err=%.2e)", dev.name.UTF8String, gemm_ms, gflops, max_gerr, attn_gpu_ms, attn_cpu_ms, attn_cpu_ms / attn_gpu_ms, max_aerr); putchar(10);
  return (max_gerr < 1e-2 && max_aerr < 2e-3) ? 0 : 3;
} }
