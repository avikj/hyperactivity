// Generated mechanically from KernelIR (lib/ir/kernel-ir.hypercubical) — verified by kir-opt-sound
#include <stdint.h>
__device__ __forceinline__ uint32_t kir_ch(uint32_t x0, uint32_t x1, uint32_t x2) { return (x2 ^ (x0 & (x1 ^ x2))); }
__device__ __forceinline__ uint32_t kir_maj(uint32_t x0, uint32_t x1, uint32_t x2) { return (x0 ^ ((x0 ^ x1) & (x0 ^ x2))); }
__device__ __forceinline__ uint32_t kir_cancel(uint32_t x0, uint32_t x1, uint32_t x2) { return 0u; }
__global__ void kir_verify(const uint32_t* in, uint32_t* out, uint32_t n) {
  uint32_t tid = blockIdx.x * blockDim.x + threadIdx.x; if (tid >= n) return;
  uint32_t x0 = in[tid*3u], x1 = in[tid*3u+1u], x2 = in[tid*3u+2u];
  out[tid*3u] = kir_ch(x0,x1,x2); out[tid*3u+1u] = kir_maj(x0,x1,x2); out[tid*3u+2u] = kir_cancel(x0,x1,x2);
}
