#include <metal_stdlib>
using namespace metal;

// KERNEL-PROVEN 4-BIT SIGNED-BIT FIBER OPERATORS (exact match to hs-fiber-xor / hs-fiber-and / hs-fiber-and-bwd)
inline uint fiber_xor(uint a, uint b) {
  uint a0=a&1u, a1=(a>>1)&1u, a2=(a>>2)&1u, a3=(a>>3)&1u;
  uint b0=b&1u, b1=(b>>1)&1u, b2=(b>>2)&1u, b3=(b>>3)&1u;
  uint c0 = (a0&b0)|(a1&b1)|(a2&b2)|(a3&b3);
  uint c1 = (a0&b1)|(a1&b0)|(a2&b3)|(a3&b2);
  uint c2 = (a0&b2)|(a2&b0)|(a1&b3)|(a3&b1);
  uint c3 = (a0&b3)|(a3&b0)|(a1&b2)|(a2&b1);
  return c0 | (c1<<1) | (c2<<2) | (c3<<3);
}
inline uint fiber_and(uint x, uint y) {
  uint x0=x&1u, x1=(x>>1)&1u, x2=(x>>2)&1u, x3=(x>>3)&1u;
  uint y0=y&1u, y1=(y>>1)&1u, y2=(y>>2)&1u, y3=(y>>3)&1u;
  uint xa = (x!=0u)?1u:0u, ya = (y!=0u)?1u:0u;
  uint z0 = (x0&ya)|(y0&xa)|(x1&y2)|(x2&y1);
  uint z1 = (x1&(y1|y3))|(x3&y1);
  uint z2 = (x2&(y2|y3))|(x3&y2);
  uint z3 = x3 & y3;
  return z0 | (z1<<1) | (z2<<2) | (z3<<3);
}
inline uint fiber_and_bwd(uint y, uint z) {
  uint y0=y&1u, y1=(y>>1)&1u, y2=(y>>2)&1u, y3=(y>>3)&1u;
  uint z0=z&1u, z1=(z>>1)&1u, z2=(z>>2)&1u;
  uint ya = (y!=0u)?1u:0u;
  uint r0 = z0 & ya;
  uint r1 = (z0&(y0|y2))|(z1&(y1|y3));
  uint r2 = (z0&(y0|y1))|(z2&(y2|y3));
  uint r3 = ((y&z)!=0u)?1u:0u;
  return r0 | (r1<<1) | (r2<<2) | (r3<<3);
}

// EXACT 32-BIT FULL-CARRY SIGNED-BIT MODULAR ADDITION VIA (L, Q) COMPILATION!
// Each bit k: L-edge s_k = a_k ^ b_k ^ c_k; Q-edge c_{k+1} = c_k ^ ((a_k ^ c_k) & (b_k ^ c_k))
inline void gc_add32(uint4 a, uint4 b, thread uint4& out, thread uint& contr) {
  uint c = 1u; // bit 0 carry-in = (0,0)
  uint o0=0u, o1=0u, o2=0u, o3=0u;
  for (uint bit = 0u; bit < 32u; bit++) {
    uint w = bit >> 3, sh = (bit & 7u) << 2;
    uint da = (a[w] >> sh) & 15u;
    uint db = (b[w] >> sh) & 15u;
    uint axc = fiber_xor(da, c);
    uint bxc = fiber_xor(db, c);
    uint s = fiber_xor(axc, db);
    uint q = fiber_and(axc, bxc);
    uint cnext = fiber_xor(c, q);
    if (s == 0u || cnext == 0u) contr = 1u;
    if (w == 0u) o0 |= (s << sh); else if (w == 1u) o1 |= (s << sh);
    else if (w == 2u) o2 |= (s << sh); else o3 |= (s << sh);
    c = cnext;
  }
  out = uint4(o0, o1, o2, o3);
}
inline uint4 gc_rotr32(uint4 v, uint n) {
  uint r0=0u, r1=0u, r2=0u, r3=0u;
  for (uint bit = 0u; bit < 32u; bit++) {
    uint src = (bit + n) & 31u;
    uint nib = (v[src >> 3] >> ((src & 7u) << 2)) & 15u;
    uint w = bit >> 3, sh = (bit & 7u) << 2;
    if (w==0u) r0|=(nib<<sh); else if (w==1u) r1|=(nib<<sh); else if (w==2u) r2|=(nib<<sh); else r3|=(nib<<sh);
  }
  return uint4(r0, r1, r2, r3);
}
inline uint4 gc_xor32(uint4 a, uint4 b) {
  uint r0=0u, r1=0u, r2=0u, r3=0u;
  for (uint i = 0u; i < 8u; i++) {
    uint sh = i << 2;
    r0 |= fiber_xor((a.x>>sh)&15u, (b.x>>sh)&15u) << sh;
    r1 |= fiber_xor((a.y>>sh)&15u, (b.y>>sh)&15u) << sh;
    r2 |= fiber_xor((a.z>>sh)&15u, (b.z>>sh)&15u) << sh;
    r3 |= fiber_xor((a.w>>sh)&15u, (b.w>>sh)&15u) << sh;
  }
  return uint4(r0, r1, r2, r3);
}
inline uint4 gc_ch32(uint4 e, uint4 f, uint4 g) {
  uint r0=0u, r1=0u, r2=0u, r3=0u;
  for (uint i = 0u; i < 8u; i++) {
    uint sh = i << 2;
    r0 |= fiber_xor((g.x>>sh)&15u, fiber_and((e.x>>sh)&15u, fiber_xor((f.x>>sh)&15u, (g.x>>sh)&15u))) << sh;
    r1 |= fiber_xor((g.y>>sh)&15u, fiber_and((e.y>>sh)&15u, fiber_xor((f.y>>sh)&15u, (g.y>>sh)&15u))) << sh;
    r2 |= fiber_xor((g.z>>sh)&15u, fiber_and((e.z>>sh)&15u, fiber_xor((f.z>>sh)&15u, (g.z>>sh)&15u))) << sh;
    r3 |= fiber_xor((g.w>>sh)&15u, fiber_and((e.w>>sh)&15u, fiber_xor((f.w>>sh)&15u, (g.w>>sh)&15u))) << sh;
  }
  return uint4(r0, r1, r2, r3);
}
inline uint4 gc_maj32(uint4 a, uint4 b, uint4 c) {
  uint r0=0u, r1=0u, r2=0u, r3=0u;
  for (uint i = 0u; i < 8u; i++) {
    uint sh = i << 2;
    uint ax=(a.x>>sh)&15u, bx=(b.x>>sh)&15u, cx=(c.x>>sh)&15u;
    uint ay=(a.y>>sh)&15u, by=(b.y>>sh)&15u, cy=(c.y>>sh)&15u;
    uint az=(a.z>>sh)&15u, bz=(b.z>>sh)&15u, cz=(c.z>>sh)&15u;
    uint aw=(a.w>>sh)&15u, bw=(b.w>>sh)&15u, cw=(c.w>>sh)&15u;
    r0 |= fiber_xor(ax, fiber_and(fiber_xor(ax,bx), fiber_xor(ax,cx))) << sh;
    r1 |= fiber_xor(ay, fiber_and(fiber_xor(ay,by), fiber_xor(ay,cy))) << sh;
    r2 |= fiber_xor(az, fiber_and(fiber_xor(az,bz), fiber_xor(az,cz))) << sh;
    r3 |= fiber_xor(aw, fiber_and(fiber_xor(aw,bw), fiber_xor(aw,cw))) << sh;
  }
  return uint4(r0, r1, r2, r3);
}
inline uint4 gc_const32(uint val) {
  uint r0=0u, r1=0u, r2=0u, r3=0u;
  for (uint bit = 0u; bit < 32u; bit++) {
    uint nib = ((val >> bit) & 1u) ? 8u : 1u; // (1,1) or (0,0)
    uint w = bit >> 3, sh = (bit & 7u) << 2;
    if (w==0u) r0|=(nib<<sh); else if (w==1u) r1|=(nib<<sh); else if (w==2u) r2|=(nib<<sh); else r3|=(nib<<sh);
  }
  return uint4(r0, r1, r2, r3);
}
inline uint gc_hamming_diff(uint4 v) {
  // Count bits where a non-zero difference (u=4 or n=2) is forced or possible (mask & 6 != 0)
  uint cnt = 0u;
  for (uint i = 0u; i < 8u; i++) {
    uint sh = i << 2;
    cnt += (((v.x>>sh)&6u)!=0u) + (((v.y>>sh)&6u)!=0u) + (((v.z>>sh)&6u)!=0u) + (((v.w>>sh)&6u)!=0u);
  }
  return cnt;
}

// KERNEL 1: REAL FULL-CARRY SIGNED-BIT SHA-256 DIFFERENTIAL BRANCH & PRUNE
kernel void hs_gpu_sha256_diff(
  device atomic_uint* stats [[buffer(0)]], // [0]=pruned_contradictions, [1]=surviving_trails, [2]=min_diff_bits
  constant uint& R [[buffer(1)]],
  uint tid [[thread_position_in_grid]])
{
  uint4 a = gc_const32(0x6a09e667u), b = gc_const32(0xbb67ae85u), c = gc_const32(0x3c6ef372u), d = gc_const32(0xa54ff53au);
  uint4 e = gc_const32(0x510e527fu), f = gc_const32(0x9b05688cu), g = gc_const32(0x1f83d9abu), h = gc_const32(0x5be0cd19u);
  // Inject signed-bit u/n differential pattern from thread ID into W[0] & W[1] (carry-canceling search!)
  uint4 w0 = gc_const32(0x61626380u);
  uint bitpos = tid & 31u;
  uint sign_nib = ((tid >> 5) & 1u) ? 4u : 2u; // u=(1,0) or n=(0,1)
  uint ww = bitpos >> 3, sh = (bitpos & 7u) << 2;
  w0[ww] = (w0[ww] & ~(15u << sh)) | (sign_nib << sh);
  // Optional compensating bit at bitpos+1 with opposite sign (real 2-adic carry cancellation!)
  if ((tid >> 6) & 1u) {
    uint bp2 = (bitpos + 1u) & 31u, w2 = bp2 >> 3, s2 = (bp2 & 7u) << 2;
    uint opp = (sign_nib == 4u) ? 2u : 4u;
    w0[w2] = (w0[w2] & ~(15u << s2)) | (opp << s2);
  }
  uint contr = 0u;
  for (uint r = 0u; r < R; r++) {
    uint4 wr = (r == 0u) ? w0 : gc_const32(0u);
    uint4 S1 = gc_xor32(gc_xor32(gc_rotr32(e,6u), gc_rotr32(e,11u)), gc_rotr32(e,25u));
    uint4 ch = gc_ch32(e, f, g);
    uint4 t1a, t1b, t1c, T1;
    gc_add32(h, S1, t1a, contr);
    gc_add32(t1a, ch, t1b, contr);
    gc_add32(t1b, gc_const32(0x428a2f98u + r * 0x11111111u), t1c, contr);
    gc_add32(t1c, wr, T1, contr);
    uint4 S0 = gc_xor32(gc_xor32(gc_rotr32(a,2u), gc_rotr32(a,13u)), gc_rotr32(a,22u));
    uint4 maj = gc_maj32(a, b, c);
    uint4 T2, ne, na;
    gc_add32(S0, maj, T2, contr);
    gc_add32(d, T1, ne, contr);
    gc_add32(T1, T2, na, contr);
    // Target boundary constraint: require bit 0 of round-R output `a` to have ZERO difference (mask & 9)!
    if (r + 1u == R) {
      uint a0 = na.x & 15u;
      if ((a0 & 9u) == 0u) contr = 1u;
    }
    h = g; g = f; f = e; e = ne; d = c; c = b; b = a; a = na;
  }
  if (contr) {
    atomic_fetch_add_explicit(&stats[0], 1u, memory_order_relaxed);
  } else {
    atomic_fetch_add_explicit(&stats[1], 1u, memory_order_relaxed);
    uint hd = gc_hamming_diff(a) + gc_hamming_diff(e);
    atomic_fetch_min_explicit(&stats[2], hd, memory_order_relaxed);
  }
}

// KERNEL 2: 8-INPUT 256-BIT BIT-SLICED (uint[8]) {XOR=0, AND=1} MC SYNTHESIZER (AES-128 S-BOX + GF(2^4) CORE!)
inline uint xs32(thread uint& s) { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s; }
kernel void hs_gpu_mc256_synth(
  device const uint* target_tt [[buffer(0)]], // 8 x uint32 = 256 bits of target Boolean function
  device atomic_uint* best_dist [[buffer(1)]], // [0]=min_hamming_err (0 = EXACT!), [1]=best_and_cnt
  device uint* best_prog [[buffer(2)]],        // winning (L, Q) program
  constant uint& max_gates [[buffer(3)]],
  constant uint& iters [[buffer(4)]],
  uint tid [[thread_position_in_grid]])
{
  uint rng = (tid + 1u) * 0x9e3779b9u ^ 0x85ebca6bu;
  // 8 basis input wires x0..x7 as 256-bit truth tables (8 x uint32):
  // x0: 0xAAAAAAAA, x1: 0xCCCCCCCC, x2: 0xF0F0F0F0, x3: 0xFF00FF00, x4: 0xFFFF0000,
  // x5: word bit 0, x6: word bit 1, x7: word bit 2!
  uint W[24][8];
  for (uint w = 0u; w < 8u; w++) {
    W[0][w] = 0xAAAAAAAAu; W[1][w] = 0xCCCCCCCCu; W[2][w] = 0xF0F0F0F0u;
    W[3][w] = 0xFF00FF00u; W[4][w] = 0xFFFF0000u;
    W[5][w] = (w & 1u) ? 0xFFFFFFFFu : 0u;
    W[6][w] = (w & 2u) ? 0xFFFFFFFFu : 0u;
    W[7][w] = (w & 4u) ? 0xFFFFFFFFu : 0u;
  }
  uint tgt[8]; for (uint w = 0u; w < 8u; w++) tgt[w] = target_tt[w];
  uint best_d = 256u;
  uint op[16], ia[16], ib[16];
  for (uint g = 0u; g < max_gates; g++) {
    uint nw = 8u + g;
    op[g] = xs32(rng) & 1u; // 0=XOR (free), 1=AND (MC=1)
    ia[g] = mulhi(xs32(rng), nw);
    ib[g] = mulhi(xs32(rng), nw);
  }
  for (uint it = 0u; it < iters; it++) {
    uint mg = mulhi(xs32(rng), max_gates);
    uint old_op = op[mg], old_a = ia[mg], old_b = ib[mg];
    uint kind = xs32(rng) & 3u;
    uint nw = 8u + mg;
    if (kind == 0u) op[mg] ^= 1u;
    else if (kind == 1u) ia[mg] = mulhi(xs32(rng), nw);
    else if (kind == 2u) ib[mg] = mulhi(xs32(rng), nw);
    else { ia[mg] = mulhi(xs32(rng), nw); ib[mg] = mulhi(xs32(rng), nw); }
    uint ands = 0u;
    for (uint g = 0u; g < max_gates; g++) {
      uint a = ia[g], b = ib[g], o = op[g]; ands += o;
      if (o == 0u) { for (uint w = 0u; w < 8u; w++) W[8u+g][w] = W[a][w] ^ W[b][w]; }
      else         { for (uint w = 0u; w < 8u; w++) W[8u+g][w] = W[a][w] & W[b][w]; }
    }
    uint d = 0u;
    for (uint w = 0u; w < 8u; w++) d += popcount(W[8u + max_gates - 1u][w] ^ tgt[w]);
    uint d_inv = 256u - d; if (d_inv < d) d = d_inv;
    if (d <= best_d) {
      best_d = d;
      uint prev = atomic_fetch_min_explicit(&best_dist[0], d, memory_order_relaxed);
      if (d == 0u) {
        uint pa = atomic_fetch_min_explicit(&best_dist[1], ands, memory_order_relaxed);
        if (ands < pa) {
          for (uint g = 0u; g < max_gates; g++) best_prog[g] = (op[g]<<16)|(ia[g]<<8)|ib[g];
        }
      } else if (d < prev) {
        atomic_store_explicit(&best_dist[1], ands, memory_order_relaxed);
      }
    } else {
      op[mg] = old_op; ia[mg] = old_a; ib[mg] = old_b;
    }
  }
}

// KERNEL 3: EXACT RESIDUAL (L, Q) FACTOR-GRAPH #SAT TENSOR-NETWORK CONTRACTION ON GPU
// Evaluates exact indicator tensor Product_{L} 1[xor=rhs] * Product_{Q} 1[z=x&y] over residual free vars!
kernel void hs_gpu_tn_residual(
  device const uint* L_masks [[buffer(0)]], // nL linear masks over <=24 free residual vars
  device const uint* L_rhs   [[buffer(1)]],
  device const uint* Q_triples [[buffer(2)]], // nQ packed (x | (y<<8) | (z<<16))
  device atomic_uint* sat_cnt [[buffer(3)]],
  constant uint4& dims [[buffer(4)]], // x=nVars, y=nL, z=nQ, w=chunk_per_thread
  uint tid [[thread_position_in_grid]])
{
  uint total = 1u << dims.x;
  uint start = tid * dims.w;
  uint end = min(start + dims.w, total);
  uint local_sat = 0u;
  for (uint asgn = start; asgn < end; asgn++) {
    uint ok = 1u;
    for (uint i = 0u; i < dims.y; i++) {
      if ((popcount(asgn & L_masks[i]) & 1u) != L_rhs[i]) { ok = 0u; break; }
    }
    if (ok) {
      for (uint j = 0u; j < dims.z; j++) {
        uint q = Q_triples[j];
        uint x = (asgn >> (q & 31u)) & 1u;
        uint y = (asgn >> ((q >> 8) & 31u)) & 1u;
        uint z = (asgn >> ((q >> 16) & 31u)) & 1u;
        if (z != (x & y)) { ok = 0u; break; }
      }
    }
    local_sat += ok;
  }
  if (local_sat) atomic_fetch_add_explicit(&sat_cnt[0], local_sat, memory_order_relaxed);
}
