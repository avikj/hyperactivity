// Mechanically lowered from PolyOptCert + F2OptCert (SystemVerilog RTL — exact 32-bit combinational)
module hx_poly_karatsuba (input logic [31:0] v0, input logic [31:0] v1, input logic [31:0] v2, input logic [31:0] v3, output logic [31:0] y0, output logic [31:0] y1, output logic [31:0] y2);
  logic [31:0] v4; assign v4 = (v0 * v2);
  logic [31:0] v5; assign v5 = (v1 * v3);
  logic [31:0] v6; assign v6 = ((v0 + v1) * (v2 + v3));
  assign y0 = v4;
  assign y1 = ((v6 - v4) - v5);
  assign y2 = v5;
endmodule

module hx_poly_gauss_complex (input logic [31:0] v0, input logic [31:0] v1, input logic [31:0] v2, input logic [31:0] v3, output logic [31:0] y0, output logic [31:0] y1);
  logic [31:0] v4; assign v4 = (v0 * (v2 + v3));
  logic [31:0] v5; assign v5 = (v3 * (v0 + v1));
  logic [31:0] v6; assign v6 = (v2 * (v1 - v0));
  assign y0 = (v4 - v5);
  assign y1 = (v4 + v6);
endmodule

module hx_poly_horner_cubic (input logic [31:0] v0, input logic [31:0] v1, input logic [31:0] v2, input logic [31:0] v3, input logic [31:0] v4, output logic [31:0] y0);
  assign y0 = (v1 + (v0 * (v2 + (v0 * (v3 + (v0 * v4))))));
endmodule

module hx_poly_cayley_su2_err (input logic [31:0] v0, input logic [31:0] v1, input logic [31:0] v2, output logic [31:0] y0);
  assign y0 = 32'd0;
endmodule

module hx_poly_brahmagupta_norm (input logic [31:0] v0, input logic [31:0] v1, input logic [31:0] v2, input logic [31:0] v3, output logic [31:0] y0);
  assign y0 = (((v0 * v0) + (v1 * v1)) * ((v2 * v2) + (v3 * v3)));
endmodule

module hx_poly_sha256_ch (input logic [31:0] v0, input logic [31:0] v1, input logic [31:0] v2, output logic [31:0] y0);
  assign y0 = (v2 ^ (v0 & (v1 ^ v2)));
endmodule

module hx_poly_sha256_maj (input logic [31:0] v0, input logic [31:0] v1, input logic [31:0] v2, output logic [31:0] y0);
  assign y0 = (v0 ^ ((v0 ^ v1) & (v0 ^ v2)));
endmodule

module hx_poly_full_adder (input logic [31:0] v0, input logic [31:0] v1, input logic [31:0] v2, output logic [31:0] y0, output logic [31:0] y1);
  logic [31:0] v3; assign v3 = (v0 ^ v2);
  logic [31:0] v4; assign v4 = (v1 ^ v2);
  assign y0 = (v3 ^ v1);
  assign y1 = (v2 ^ (v3 & v4));
endmodule

