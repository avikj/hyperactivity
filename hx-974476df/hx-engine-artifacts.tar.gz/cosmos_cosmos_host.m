#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <stdio.h>
#include <stdint.h>
#include <sys/time.h>
static double now_ms(void){ struct timeval tv; gettimeofday(&tv,NULL); return tv.tv_sec*1000.0 + tv.tv_usec/1000.0; }
int main(void){
  @autoreleasepool {
    id<MTLDevice> dev = MTLCreateSystemDefaultDevice();
    if (!dev) { printf("No Metal device\n"); return 1; }
    NSError* err = nil;
    NSString* src = [NSString stringWithContentsOfFile:@"/home/claude/hxb/out/cosmos_cosmos.metal" encoding:NSUTF8StringEncoding error:&err];
    id<MTLLibrary> lib = [dev newLibraryWithSource:src options:nil error:&err];
    if (!lib) { printf("Metal err: %s\n", [[err localizedDescription] UTF8String]); return 1; }
    id<MTLCommandQueue> q = [dev newCommandQueue];
    uint32_t N = 65536u, ne = 512u;
    id<MTLBuffer> bU = [dev newBufferWithLength:ne*4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> bV = [dev newBufferWithLength:ne*4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> bE = [dev newBufferWithLength:N*4 options:MTLResourceStorageModeShared];
    uint32_t* up=(uint32_t*)[bU contents]; uint32_t* vp=(uint32_t*)[bV contents];
    for (uint32_t i=0;i<ne;i++){ up[i]=(i*37u)&4095u; vp[i]=((i&3u)?((i*37u+((i&7u)+1u))&4095u):((i*101u)&4095u)); }
    id<MTLComputePipelineState> p1 = [dev newComputePipelineStateWithFunction:[lib newFunctionWithName:@"cos_metal_manifold_search"] error:&err];
    float best[3] = {1e9f, 1e9f, 1e9f}; double dt_m = 0.0;
    for (uint32_t m=0;m<3;m++) {
      double t0 = now_ms();
      id<MTLCommandBuffer> cb = [q commandBuffer]; id<MTLComputeCommandEncoder> en = [cb computeCommandEncoder];
      [en setComputePipelineState:p1]; [en setBuffer:bU offset:0 atIndex:0]; [en setBuffer:bV offset:0 atIndex:1];
      [en setBuffer:bE offset:0 atIndex:2]; [en setBytes:&ne length:4 atIndex:3]; [en setBytes:&m length:4 atIndex:4];
      [en dispatchThreads:MTLSizeMake(N,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)]; [en endEncoding]; [cb commit]; [cb waitUntilCompleted];
      dt_m += now_ms() - t0;
      float* ep = (float*)[bE contents]; for (uint32_t i=0;i<N;i++) if (ep[i]<best[m]) best[m]=ep[i];
    }
    printf("HX-COSMOS GPU (%s): 196,608 manifold evals in %.2f ms | best avg wire: 2D=%.2f -> 3D_SoIC=%.2f -> Optical_HC=%.2f (%.2fx collapse!)\n", [[dev name] UTF8String], dt_m, best[0], best[1], best[2], best[0]/best[2]);
    id<MTLBuffer> bViol = [dev newBufferWithLength:4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> bMin  = [dev newBufferWithLength:N*4 options:MTLResourceStorageModeShared];
    *(uint32_t*)[bViol contents] = 0u;
    id<MTLComputePipelineState> p2 = [dev newComputePipelineStateWithFunction:[lib newFunctionWithName:@"cos_metal_cbf_reach"] error:&err];
    double t2 = now_ms();
    id<MTLCommandBuffer> cb2 = [q commandBuffer]; id<MTLComputeCommandEncoder> e2 = [cb2 computeCommandEncoder];
    [e2 setComputePipelineState:p2]; [e2 setBuffer:bViol offset:0 atIndex:0]; [e2 setBuffer:bMin offset:0 atIndex:1];
    [e2 dispatchThreads:MTLSizeMake(N,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)]; [e2 endEncoding]; [cb2 commit]; [cb2 waitUntilCompleted];
    double dt2 = now_ms() - t2;
    float* mp=(float*)[bMin contents]; float gmin=1e9f; for (uint32_t i=0;i<N;i++) if (mp[i]<gmin) gmin=mp[i];
    printf("  [GPU CBF] 65,536 adversarial trajectories x 256 steps (16.77M steps) in %.2f ms | violations=%u | global_min_margin=%.4f (>=0.2000)\n", dt2, *(uint32_t*)[bViol contents], gmin);
  }
  return 0;
}
