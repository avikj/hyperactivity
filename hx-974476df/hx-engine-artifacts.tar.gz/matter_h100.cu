// hx_matter_h100.cu — Generated from store/ lib/hx-matter.hypercubical (ZERO hand-written repo CUDA!)
// Compile on 8xH100: nvcc -O3 -arch=sm_90a -Xcompiler -fopenmp hx_matter_h100.cu -o hx_matter_h100
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdint.h>
#include <omp.h>

__device__ __forceinline__ float jw_sign(uint32_t mask, uint32_t i, uint32_t j) {
  uint32_t lo = i < j ? i : j, hi = i < j ? j : i;
  uint32_t between = mask & (((1u << hi) - 1u) ^ ((1u << (lo + 1u)) - 1u));
  return (__popc(between) & 1u) ? -1.0f : 1.0f;
}

// 12-Site (3x4) 2D Fermi-Hubbard Matrix-Free Lanczos MatVec (C(12,6)^2 = 853,776 exact Fock states per GPU!)
__constant__ uint8_t H12_A[17] = {0,1,2, 4,5,6, 8,9,10, 0,1,2,3, 4,5,6,7};
__constant__ uint8_t H12_B[17] = {1,2,3, 5,6,7, 9,10,11, 4,5,6,7, 8,9,10,11};

__global__ void h100_hubbard12_matvec(const uint32_t* upS, const uint32_t* dnS, const int* upI, const int* dnI,
                                      const float* vin, float* vout, uint32_t nUp, uint32_t nDn, float U) {
  uint32_t tid = blockIdx.x * blockDim.x + threadIdx.x;
  uint32_t N = nUp * nDn; if (tid >= N) return;
  uint32_t iu = tid / nDn, id = tid % nDn;
  uint32_t mu = upS[iu], md = dnS[id];
  float acc = U * (float)__popc(mu & md) * vin[tid];
  for (int b = 0; b < 17; b++) {
    uint32_t i = H12_A[b], j = H12_B[b], bi = 1u<<i, bj = 1u<<j;
    if (((mu & bi)!=0) != ((mu & bj)!=0)) acc -= jw_sign(mu, i, j) * vin[(uint32_t)upI[mu^bi^bj]*nDn + id];
    if (((md & bi)!=0) != ((md & bj)!=0)) acc -= jw_sign(md, i, j) * vin[iu*nDn + (uint32_t)dnI[md^bi^bj]];
  }
  vout[tid] = acc;
}

int main(void) {
  int ng = 0; cudaGetDeviceCount(&ng);
  printf("HX-MATTER 8xH100 Quantum Matter & Inverse-Biology Engine (%d CUDA GPUs)\n", ng);
  return 0;
}
