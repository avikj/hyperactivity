// Generated mechanically by lib/ir/kexpr.hypercubical (hx kexpr, 29th engine)
#include <stdint.h>
__device__ __forceinline__ uint32_t ke_s0(uint32_t x0) { return ((((x0 >> 2u) | (x0 << 30u)) ^ ((x0 >> 13u) | (x0 << 19u))) ^ ((x0 >> 22u) | (x0 << 10u))); }
__device__ __forceinline__ uint32_t ke_s1(uint32_t x0) { return ((((x0 >> 6u) | (x0 << 26u)) ^ ((x0 >> 11u) | (x0 << 21u))) ^ ((x0 >> 25u) | (x0 << 7u))); }
__device__ __forceinline__ uint32_t ke_ch(uint32_t x0, uint32_t x1, uint32_t x2) { return (x2 ^ (x0 & (x1 ^ x2))); }
__device__ __forceinline__ uint32_t ke_maj(uint32_t x0, uint32_t x1, uint32_t x2) { return (x0 ^ ((x0 ^ x1) & (x0 ^ x2))); }
__device__ __forceinline__ uint32_t ke_t2(uint32_t x0, uint32_t x1, uint32_t x2) { return (((((x0 >> 2u) | (x0 << 30u)) ^ ((x0 >> 13u) | (x0 << 19u))) ^ ((x0 >> 22u) | (x0 << 10u))) + (x0 ^ ((x0 ^ x1) & (x0 ^ x2)))); }
__global__ void ke_verify(const uint32_t* in, uint32_t* out, uint32_t n) {
  uint32_t tid = blockIdx.x * blockDim.x + threadIdx.x; if (tid >= n) return;
  out[tid] = ke_t2(in[tid*3u], in[tid*3u+1u], in[tid*3u+2u]) ^ ke_s1(in[tid*3u]);
}
