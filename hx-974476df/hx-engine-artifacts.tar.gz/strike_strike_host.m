#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <stdio.h>
#include <stdint.h>
#include <sys/time.h>
static double now_ms(void){ struct timeval tv; gettimeofday(&tv,NULL); return tv.tv_sec*1000.0 + tv.tv_usec/1000.0; }
int main(void){
  @autoreleasepool {
    id<MTLDevice> dev = MTLCreateSystemDefaultDevice();
    if (!dev) { printf("No Metal\n"); return 1; }
    NSError* err = nil;
    NSString* src = [NSString stringWithContentsOfFile:@"/home/claude/hxb/out/strike_strike.metal" encoding:NSUTF8StringEncoding error:&err];
    id<MTLLibrary> lib = [dev newLibraryWithSource:src options:nil error:&err];
    if (!lib) { printf("Metal err: %s\n", [[err localizedDescription] UTF8String]); return 1; }
    id<MTLCommandQueue> q = [dev newCommandQueue];
    id<MTLComputePipelineState> p = [dev newComputePipelineStateWithFunction:[lib newFunctionWithName:@"strike_5axis_superopt"] error:&err];
    const uint32_t N = 131072u, GENS = 8u;
    id<MTLBuffer> bSeed = [dev newBufferWithLength:4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> bSco  = [dev newBufferWithLength:N*4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> bCfg  = [dev newBufferWithLength:N*4 options:MTLResourceStorageModeShared];
    uint32_t* seedp = (uint32_t*)[bSeed contents]; *seedp = 0u;
    uint32_t best_fj = 0xFFFFFFu, best_cfg = 0u, gen0_avg = 0u, mono = 1u;
    double t0 = now_ms();
    for (uint32_t g = 0u; g < GENS; g++) {
      id<MTLCommandBuffer> cb = [q commandBuffer]; id<MTLComputeCommandEncoder> en = [cb computeCommandEncoder];
      [en setComputePipelineState:p]; [en setBuffer:bSeed offset:0 atIndex:0]; [en setBuffer:bSco offset:0 atIndex:1];
      [en setBuffer:bCfg offset:0 atIndex:2]; [en setBytes:&g length:4 atIndex:3];
      [en dispatchThreads:MTLSizeMake(N,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)];
      [en endEncoding]; [cb commit]; [cb waitUntilCompleted];
      uint32_t* sp = (uint32_t*)[bSco contents]; uint32_t* cp = (uint32_t*)[bCfg contents];
      uint32_t g_best = 0xFFFFFFu, g_cfg = 0u; uint64_t sum = 0; uint32_t valid = 0;
      for (uint32_t i = 0; i < N; i++) {
        if (sp[i] < 0xFFFFFFu) { sum += sp[i]; valid++; }
        if (sp[i] < g_best) { g_best = sp[i]; g_cfg = cp[i]; }
      }
      if (g == 0u && valid > 0u) gen0_avg = (uint32_t)(sum / valid);
      if (g > 0u && g_best > best_fj) mono = 0u;
      best_fj = g_best; best_cfg = g_cfg; *seedp = best_cfg;
    }
    double dt = now_ms() - t0;
    double m_per_s = ((double)N * (double)GENS) / (dt * 1e3);
    const char* m_nm[4] = {"Flat2D","FlexIC-Origami","3D-SoIC","3D+Optical-Cortex"};
    const char* h_nm[6] = {"A18","4xM5U-K4","1xV80","4xV80","3nm-ASIC","3D-SoIC-PCBox"};
    printf("[HX-STRIKE GPU %s] 1,048,576 5-axis machines superoptimized in %.2f ms (%.2f M-machines/s) | mono=%u\n", [[dev name] UTF8String], dt, m_per_s, mono);
    printf("  Global Pareto Optimum: %u fJ/op (vs %u fJ/op Gen0 avg -> %.2fx collapse!) | Manifold=%s | GateTier=%u/7 | BF16-48b=%u | HW=%s | CBF_res=%u | OptHub=%u\n", best_fj, gen0_avg, (double)gen0_avg/(double)best_fj, m_nm[best_cfg&3u], (best_cfg>>2u)&7u, (best_cfg>>5u)&1u, h_nm[(best_cfg>>6u)&7u], (best_cfg>>9u)&7u, (best_cfg>>12u)&15u);
  }
  return 0;
}
