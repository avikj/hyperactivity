// Mechanically lowered from GenesisCrystal (Apple Metal — identical AST to C11, CUDA, SV, WASM!)
#include <metal_stdlib>
using namespace metal;
inline void opt_howell8_quat(uint v0, uint v1, uint v2, uint v3, uint v4, uint v5, uint v6, uint v7, thread uint* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5; (void)v6; (void)v7;
  uint v8 = ((v0 + v1) * (v4 + v5));
  uint v9 = ((v3 - v2) * (v6 - v7));
  uint v10 = ((v0 - v1) * (v6 + v7));
  uint v11 = ((v2 + v3) * (v4 - v5));
  uint v12 = ((v1 + v3) * (v5 + v6));
  uint v13 = ((v1 - v3) * (v5 - v6));
  uint v14 = ((v0 + v2) * (v4 - v7));
  uint v15 = ((v0 - v2) * (v4 + v7));
  uint v16 = (v12 + v13);
  uint v17 = (v12 - v13);
  uint v18 = (v14 + v15);
  uint v19 = (v14 - v15);
  out[0] = ((v9 + v9) + (v18 - v16));
  out[1] = ((v8 + v8) - (v18 + v16));
  out[2] = ((v10 + v10) + (v19 + v17));
  out[3] = (((v11 + v11) - v19) + v17);
}
inline void opt_euler_4sq(uint v0, uint v1, uint v2, uint v3, uint v4, uint v5, uint v6, uint v7, thread uint* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5; (void)v6; (void)v7;
  uint v8 = (((v0 * v0) + (v1 * v1)) + ((v2 * v2) + (v3 * v3)));
  uint v9 = (((v4 * v4) + (v5 * v5)) + ((v6 * v6) + (v7 * v7)));
  out[0] = (v8 * v9);
}
inline void opt_adelic_hadamard(uint v0, uint v1, uint v2, uint v3, thread uint* out) {
  (void)v0; (void)v1; (void)v2; (void)v3;
  uint v4 = (v0 + v2);
  uint v5 = (v0 - v2);
  uint v6 = (v1 + v3);
  uint v7 = (v1 - v3);
  out[0] = (v4 + v6);
  out[1] = (v4 - v6);
  out[2] = (v5 + v7);
  out[3] = (v5 - v7);
}
inline void opt_poisson_plancherel(uint v0, uint v1, uint v2, uint v3, thread uint* out) {
  (void)v0; (void)v1; (void)v2; (void)v3;
  out[0] = 0u;
  out[1] = 0u;
  out[2] = 0u;
  out[3] = 0u;
  out[4] = 0u;
  out[5] = 0u;
}
inline void opt_alpoge_masullo(uint v0, uint v1, uint v2, uint v3, uint v4, uint v5, uint v6, uint v7, thread uint* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5; (void)v6; (void)v7;
  uint v8 = (v0 - v1);
  out[0] = 0u;
  out[1] = 0u;
  out[2] = (v8 * v8);
  out[3] = v8;
}
inline void opt_darwin_stokes(uint v0, uint v1, uint v2, uint v3, uint v4, uint v5, thread uint* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5;
  uint v6 = ((v0 - v1) * (v2 - v3));
  uint v7 = ((v0 * v4) + (v1 * v5));
  out[0] = (v6 + (v7 + v7));
  out[1] = 0u;
  out[2] = 0u;
  out[3] = 0u;
  out[4] = 0u;
  out[5] = 4u;
}
inline void opt_fredkin_1and(uint v0, uint v1, uint v2, thread uint* out) {
  uint v3 = (v1 ^ v2);
  uint v4 = (v0 & v3);
  out[0] = v0;
  out[1] = (v1 ^ v4);
  out[2] = (v2 ^ v4);
}
inline void opt_keccak_chi5(uint v0, uint v1, uint v2, uint v3, uint v4, thread uint* out) {
  out[0] = (v0 ^ ((~v1) & v2));
  out[1] = (v1 ^ ((~v2) & v3));
  out[2] = (v2 ^ ((~v3) & v4));
  out[3] = (v3 ^ ((~v4) & v0));
  out[4] = (v4 ^ ((~v0) & v1));
}
kernel void genesis_metal_kernel(device const uint* in [[buffer(0)]], device uint* out [[buffer(1)]], uint tid [[thread_position_in_grid]]) {
  uint x0=in[tid*4u], x1=in[tid*4u+1u], x2=in[tid*4u+2u], x3=in[tid*4u+3u];
  uint x4=x0^0x9e3779b9u, x5=x1^0x85ebca6bu, x6=x2^0xc2b2ae35u, x7=x3^0x27d4eb2fu;
  uint q[4], e[1], h[4], fr[3], kc[5];
  opt_howell8_quat(x0,x1,x2,x3,x4,x5,x6,x7,q);
  opt_euler_4sq(x0,x1,x2,x3,x4,x5,x6,x7,e);
  opt_adelic_hadamard(x0,x1,x2,x3,h);
  opt_fredkin_1and(x0,x1,x2,fr);
  opt_keccak_chi5(x0,x1,x2,x3,x4,kc);
  out[tid] = q[0] ^ q[1] ^ q[2] ^ q[3] ^ e[0] ^ h[0] ^ h[1] ^ fr[1] ^ fr[2] ^ kc[0] ^ kc[4];
}
