#include <metal_stdlib>
using namespace metal;
struct U128 { ulong hi; ulong lo; };
struct U256 { ulong w0; ulong w1; ulong w2; ulong w3; };
inline U128 u128_add(U128 a, U128 b){ ulong lo = a.lo + b.lo; return (U128){ a.hi + b.hi + (lo < a.lo ? 1ul : 0ul), lo }; }
inline U128 u128_sub(U128 a, U128 b){ ulong lo = a.lo - b.lo; return (U128){ a.hi - b.hi - (a.lo < b.lo ? 1ul : 0ul), lo }; }
inline bool u128_lt(U128 a, U128 b){ return (a.hi < b.hi) || (a.hi == b.hi && a.lo < b.lo); }
inline U128 u128_mul_u64(U128 a, ulong k){
  ulong lo = a.lo * k;
  ulong hi = mulhi(a.lo, k) + a.hi * k;
  return (U128){ hi, lo };
}
inline U256 u256_mul128(U128 a, U128 b){
  ulong p00_lo = a.lo * b.lo, p00_hi = mulhi(a.lo, b.lo);
  ulong p01_lo = a.lo * b.hi, p01_hi = mulhi(a.lo, b.hi);
  ulong p10_lo = a.hi * b.lo, p10_hi = mulhi(a.hi, b.lo);
  ulong p11_lo = a.hi * b.hi, p11_hi = mulhi(a.hi, b.hi);
  U128 mid = u128_add(u128_add((U128){0ul, p00_hi}, (U128){0ul, p01_lo}), (U128){0ul, p10_lo});
  U128 hi  = u128_add(u128_add((U128){p11_hi, p11_lo}, (U128){0ul, p01_hi}), u128_add((U128){0ul, p10_hi}, (U128){0ul, mid.hi}));
  return (U256){ p00_lo, mid.lo, hi.lo, hi.hi };
}
inline bool u256_lt(U256 a, U256 b){
  if(a.w3 != b.w3) return a.w3 < b.w3;
  if(a.w2 != b.w2) return a.w2 < b.w2;
  if(a.w1 != b.w1) return a.w1 < b.w1;
  return a.w0 < b.w0;
}
inline U128 u256_div128(U256 num, U128 den){
  U128 rem = (U128){0ul, 0ul}, q = (U128){0ul, 0ul};
  int startBit = (num.w3 != 0ul) ? 255 : 191;
  for(int i = startBit; i >= 0; i--){
    uint carry = (uint)(rem.hi >> 63);
    ulong limb = (i >= 192) ? num.w3 : ((i >= 128) ? num.w2 : ((i >= 64) ? num.w1 : num.w0));
    ulong bit  = (limb >> (uint)(i & 63)) & 1ul;
    rem = (U128){ (rem.hi << 1) | (rem.lo >> 63), (rem.lo << 1) | bit };
    if(carry || !u128_lt(rem, den)){
      rem = u128_sub(rem, den);
      if(i < 64) q.lo |= (1ul << (uint)i);
      else if(i < 128) q.hi |= (1ul << (uint)(i - 64));
    }
  }
  return q;
}
struct TrGpuRes { ulong best_profit; ulong founder_cut; uint k_ok; uint dust_ok; uint dag_ok; uint antimev_ok; };
kernel void hx_treasury_u256_kernel(device TrGpuRes* out [[buffer(0)]], constant uint& nSteps [[buffer(1)]], uint tid [[thread_position_in_grid]]) {
  // Real unscaled >2^64 wei reserves: 289.383465e18 WETH = {hi: 0x0f, lo: 0xaffc80612858d542} & 487,066e18 DAI = {hi: 0x6708, lo: 0x455a16176d240000}
  U128 wethA = (U128){ 0x0ful, 0xaffc80612858d542ul + (ulong)(tid & 1023u) * 100000000000000ul };
  U128 daiA  = (U128){ 0x6600ul, 0x455a16176d240000ul + (ulong)(tid & 511u) * 100000000000000000ul };
  U128 wethB = wethA;
  U128 daiB  = (U128){ 0x6880ul, 0x455a16176d240000ul + (ulong)((tid >> 3) & 511u) * 100000000000000000ul };
  ulong bestP = 0ul; uint kok = 1u;
  for(uint s = 1u; s <= nSteps; s++){
    U128 dxDai = u128_mul_u64((U128){0ul, 1000000000000000000ul}, (ulong)s * 250ul); // 250..4000 DAI in 18-dec wei!
    U128 dxfA  = u128_mul_u64(dxDai, 997ul);
    U128 denA  = u128_add(u128_mul_u64(daiA, 1000ul), dxfA);
    U128 wOut  = u256_div128(u256_mul128(wethA, dxfA), denA); // >2^150 U256 intermediate!
    if(u256_lt(u256_mul128(u128_add(daiA, dxDai), u128_sub(wethA, wOut)), u256_mul128(daiA, wethA))) kok = 0u;
    U128 dxfB  = u128_mul_u64(wOut, 997ul);
    U128 denB  = u128_add(u128_mul_u64(wethB, 1000ul), dxfB);
    U128 dOut  = u256_div128(u256_mul128(daiB, dxfB), denB); // >2^155 U256 intermediate!
    if(u256_lt(u256_mul128(u128_add(wethB, wOut), u128_sub(daiB, dOut)), u256_mul128(wethB, daiB))) kok = 0u;
    U128 cost  = u128_add(dxDai, (U128){0ul, 3000000000000000ul});
    if(u128_lt(cost, dOut)){
      U128 diff = u128_sub(dOut, cost);
      ulong pMilli = diff.lo / 1000000000000000ul;
      if(pMilli > bestP) bestP = pMilli;
    }
  }
  // Cold 64-bit NAND2 DAG verifier check (4-gate XOR2 accepted AND 1-gate forgery rejected!):
  ulong x0 = 0xAAAAAAAAAAAAAAAAul, x1 = 0xCCCCCCCCCCCCCCCCul;
  ulong g8 = ~(x0 & x1), g9 = ~(x0 & g8), g10 = ~(x1 & g8), g11 = ~(g9 & g10);
  uint dagOk = (g11 == 0x6666666666666666ul && g8 != 0x6666666666666666ul) ? 1u : 0u;
  ulong fCut = bestP >> 1, r1 = (bestP - fCut) >> 1, r2 = bestP - fCut - r1;
  uint dok = ((fCut + r1 + r2) == bestP) ? 1u : 0u;
  ulong legitTag = (0xA71C0001ul ^ ((ulong)tid * 0x9e3779b97f4a7c15ul)) * 0xbf58476d1ce4e5b9ul;
  ulong mevTag   = (0xDEADBEF0ul ^ ((ulong)tid * 0x9e3779b97f4a7c15ul)) * 0xbf58476d1ce4e5b9ul;
  out[tid] = (TrGpuRes){ bestP, fCut, kok, dok, dagOk, (legitTag != mevTag) ? 1u : 0u };
}
