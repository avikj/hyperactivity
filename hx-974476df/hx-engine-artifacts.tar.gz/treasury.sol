// SPDX-License-Identifier: MIT
// Generated from lib/hx-treasury.hypercubical + lib/ir/treasury-ir.hypercubical
pragma solidity ^0.8.24;

interface IERC20Minimal {
  function balanceOf(address account) external view returns (uint256);
  function transfer(address to, uint256 amount) external returns (bool);
}

interface IUniV2Pair {
  function token0() external view returns (address);
  function token1() external view returns (address);
  function getReserves() external view returns (uint112 r0, uint112 r1, uint32 ts);
  function swap(uint256 amount0Out, uint256 amount1Out, address to, bytes calldata data) external;
}

contract HyperactivitySovereignTreasury {
  address public immutable founderBeneficiary;
  uint256 private _locked = 1;
  address private _activeBorrowPool;
  modifier nonReentrant() { require(_locked == 1, "REENTRANT"); _locked = 2; _; _locked = 1; }

  struct Bounty {
    address sponsor;
    uint64  specTruthTable;
    uint256 rewardWei;
    uint64  maxTargetCost;
    uint64  deadline;
    bool    settled;
  }
  struct Commitment { bytes32 commitHash; uint64 blockNum; }
  struct FlashParams { address borrowPool; address sellPool; address midToken; address repayToken; bool borrowToken0; bool sellMidIs0; uint256 minProfit; }
  uint256 public nextBountyId;
  uint256 public totalFounderPaidWei;
  mapping(uint256 => Bounty) public bounties;
  mapping(uint256 => mapping(address => Commitment)) public commits;

  event FlashArbExecuted(address indexed caller, address indexed token, uint256 netProfit, uint256 founderPaid);
  event BountyPosted(uint256 indexed bountyId, uint64 specTruthTable, uint256 rewardWei, uint64 maxTargetCost);
  event SolutionCommitted(uint256 indexed bountyId, address indexed solver, bytes32 commitHash);
  event BountySettled(uint256 indexed bountyId, address indexed solver, bytes32 solutionHash, uint64 achievedCost, uint256 founderCut, uint256 solverCut);
  event ComputeLicensePaid(address indexed payer, bytes32 indexed jobSpecHash, uint256 amountWei);

  constructor(address _founder) { require(_founder != address(0), "ZERO_FOUNDER"); founderBeneficiary = _founder; }

  // RAIL 1: Direct Sovereign Compute / Silicon / Superoptimization Meter (0% VC, instant non-custodial sweep)
  function payComputeLicense(bytes32 jobSpecHash) external payable nonReentrant {
    require(msg.value > 0, "ZERO_VALUE");
    totalFounderPaidWei += msg.value;
    (bool ok, ) = founderBeneficiary.call{value: msg.value}("");
    require(ok, "TRANSFER_FAILED");
    emit ComputeLicensePaid(msg.sender, jobSpecHash, msg.value);
  }
  // Cold on-chain 6-input 64-bit NAND2 DAG truth-table verifier (up to 248 gates; closes unverified reveal drains!)
  function verifyNandDag64(uint64 specTT, uint16[] calldata gates) public pure returns (bool) {
    uint256 n = gates.length;
    if (n == 0 || n > 248) return false;
    uint64[256] memory w;
    w[0] = 0x0000000000000000; w[1] = 0xFFFFFFFFFFFFFFFF;
    w[2] = 0xAAAAAAAAAAAAAAAA; w[3] = 0xCCCCCCCCCCCCCCCC;
    w[4] = 0xF0F0F0F0F0F0F0F0; w[5] = 0xFF00FF00FF00FF00;
    w[6] = 0xFFFF0000FFFF0000; w[7] = 0xFFFFFFFF00000000;
    for (uint256 i = 0; i < n; i++) {
      uint256 idx = 8 + i;
      uint256 a = uint256(gates[i] >> 8);
      uint256 b = uint256(gates[i] & 0xFF);
      if (a >= idx || b >= idx) return false;
      w[idx] = ~(w[a] & w[b]);
    }
    return w[8 + n - 1] == specTT;
  }
  // RAIL 2: On-Chain Cold-Verified Anti-MEV Commit-Reveal PoUW Superoptimization Bounty Escrow
  function postBounty(uint64 specTruthTable, uint64 maxTargetCost, uint64 durationSecs) external payable nonReentrant returns (uint256 id) {
    require(msg.value > 0 && maxTargetCost > 0 && maxTargetCost <= 248 && durationSecs >= 60, "INVALID_BOUNTY");
    id = nextBountyId++;
    bounties[id] = Bounty(msg.sender, specTruthTable, msg.value, maxTargetCost, uint64(block.timestamp) + durationSecs, false);
    emit BountyPosted(id, specTruthTable, msg.value, maxTargetCost);
  }

  function commitSolution(uint256 bountyId, bytes32 commitHash) external {
    require(!bounties[bountyId].settled, "ALREADY_SETTLED");
    commits[bountyId][msg.sender] = Commitment(commitHash, uint64(block.number));
    emit SolutionCommitted(bountyId, msg.sender, commitHash);
  }

  function revealAndSettle(uint256 bountyId, uint16[] calldata gates, bytes32 salt) external nonReentrant {
    Bounty storage b = bounties[bountyId];
    Commitment memory c = commits[bountyId][msg.sender];
    uint64 achievedCost = uint64(gates.length);
    bytes32 solutionHash = keccak256(abi.encodePacked(gates));
    require(!b.settled && block.timestamp <= b.deadline, "EXPIRED_OR_SETTLED");
    require(c.commitHash != bytes32(0) && block.number > c.blockNum, "WAIT_1_BLOCK_ANTIMEV");
    require(keccak256(abi.encodePacked(msg.sender, bountyId, solutionHash, achievedCost, salt)) == c.commitHash, "BAD_COMMIT");
    require(achievedCost > 0 && achievedCost <= b.maxTargetCost, "COST_TOO_HIGH");
    require(verifyNandDag64(b.specTruthTable, gates), "SPEC_MISMATCH");
    b.settled = true;
    uint256 founderCut = (msg.sender == founderBeneficiary) ? b.rewardWei : (b.rewardWei >> 1);
    uint256 solverCut  = b.rewardWei - founderCut;
    totalFounderPaidWei += founderCut;
    (bool okF, ) = founderBeneficiary.call{value: founderCut}(""); require(okF);
    if (solverCut > 0) { (bool okS, ) = msg.sender.call{value: solverCut}(""); require(okS); }
    emit BountySettled(bountyId, msg.sender, solutionHash, achievedCost, founderCut, solverCut);
  }
  function refundExpiredBounty(uint256 bountyId) external nonReentrant {
    Bounty storage b = bounties[bountyId];
    require(!b.settled && block.timestamp > b.deadline && b.rewardWei > 0);
    b.settled = true;
    (bool ok, ) = b.sponsor.call{value: b.rewardWei}(""); require(ok);
  }

  // RAIL 3: Zero-Principal Atomic Uniswap V2 Flash-Swap Arbitrage + Zero-Dust Waterfall
  function distributeTokenWaterfall(IERC20Minimal token, uint256 netProfit, address[] calldata chain) internal returns (uint256 founderPaid) {
    if (chain.length == 0) {
      require(token.transfer(founderBeneficiary, netProfit));
      return netProfit;
    }
    uint256 rem = netProfit;
    founderPaid = rem >> 1;
    rem -= founderPaid;
    require(token.transfer(founderBeneficiary, founderPaid));
    for (uint256 i = 0; i < chain.length; i++) {
      uint256 sh = (i + 1 == chain.length) ? rem : (rem >> 1);
      rem -= sh;
      if (sh > 0) require(token.transfer(chain[i], sh));
    }
  }
  function executeFlashArb(FlashParams calldata fp, uint256 borrowMidAmt, address[] calldata chain) external nonReentrant {
    require(borrowMidAmt > 0 && fp.minProfit > 0, "ZERO_FLASH_PARAMS");
    uint256 preBal = IERC20Minimal(fp.repayToken).balanceOf(address(this));
    _activeBorrowPool = fp.borrowPool;
    uint256 a0 = fp.borrowToken0 ? borrowMidAmt : 0;
    uint256 a1 = fp.borrowToken0 ? 0 : borrowMidAmt;
    IUniV2Pair(fp.borrowPool).swap(a0, a1, address(this), abi.encode(fp));
    _activeBorrowPool = address(0);
    uint256 postBal = IERC20Minimal(fp.repayToken).balanceOf(address(this));
    require(postBal >= preBal + fp.minProfit, "ATOMIC_NO_PROFIT_REVERT");
    uint256 netProfit = postBal - preBal;
    uint256 fPaid = distributeTokenWaterfall(IERC20Minimal(fp.repayToken), netProfit, chain);
    emit FlashArbExecuted(msg.sender, fp.repayToken, netProfit, fPaid);
  }

  function uniswapV2Call(address sender, uint256 amount0, uint256 amount1, bytes calldata data) external {
    require(_locked == 2 && msg.sender == _activeBorrowPool && sender == address(this), "BAD_V2_CALLBACK");
    _activeBorrowPool = address(0); // Single-shot callback lock prevents sellPool callback re-entry
    FlashParams memory fp = abi.decode(data, (FlashParams));
    uint256 borrowed = fp.borrowToken0 ? amount0 : amount1;
    (uint112 br0, uint112 br1, ) = IUniV2Pair(fp.borrowPool).getReserves();
    uint256 rInBorrow  = fp.borrowToken0 ? uint256(br1) : uint256(br0);
    uint256 rOutBorrow = fp.borrowToken0 ? uint256(br0) : uint256(br1);
    uint256 repayIn = ((rInBorrow * borrowed * 1000) / ((rOutBorrow - borrowed) * 997)) + 1;
    (uint112 sr0, uint112 sr1, ) = IUniV2Pair(fp.sellPool).getReserves();
    uint256 rInSell  = fp.sellMidIs0 ? uint256(sr0) : uint256(sr1);
    uint256 rOutSell = fp.sellMidIs0 ? uint256(sr1) : uint256(sr0);
    uint256 sellOut  = ((borrowed * 997) * rOutSell) / (rInSell * 1000 + (borrowed * 997));
    require(sellOut >= repayIn + fp.minProfit, "SPREAD_BELOW_FEES");
    require(IERC20Minimal(fp.midToken).transfer(fp.sellPool, borrowed));
    IUniV2Pair(fp.sellPool).swap(fp.sellMidIs0 ? 0 : sellOut, fp.sellMidIs0 ? sellOut : 0, address(this), new bytes(0));
    require(IERC20Minimal(fp.repayToken).transfer(fp.borrowPool, repayIn));
  }
}
