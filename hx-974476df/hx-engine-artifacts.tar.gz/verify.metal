#include <metal_stdlib>
using namespace metal;
inline void spec_vx_coupled_eigen(uint v0, uint v1, uint v2, uint v3, uint v4, uint v5, uint v6, uint v7, thread uint* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5; (void)v6; (void)v7;
  out[0] = (((v0 * v2) + (v0 * v3)) + ((v1 * v2) + (v1 * v3)));
  out[1] = ((v4 * v6) - (v5 * v7));
  out[2] = ((v4 * v7) + (v5 * v6));
}
inline void opt_vx_coupled_eigen(uint v0, uint v1, uint v2, uint v3, uint v4, uint v5, uint v6, uint v7, thread uint* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5; (void)v6; (void)v7;
  uint v8 = ((v0 + v1) * (v2 + v3));
  uint v9 = (v4 * v6);
  uint v10 = (v5 * v7);
  uint v11 = ((v4 + v5) * (v6 + v7));
  out[0] = v8;
  out[1] = (v9 - v10);
  out[2] = ((v11 - v9) - v10);
}
inline void spec_vx_horner_deg3(uint v0, uint v1, uint v2, uint v3, uint v4, thread uint* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4;
  out[0] = ((v0 + (v1 * v4)) + ((v2 * (v4 * v4)) + (v3 * (v4 * (v4 * v4)))));
}
inline void opt_vx_horner_deg3(uint v0, uint v1, uint v2, uint v3, uint v4, thread uint* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4;
  out[0] = (v0 + (v4 * (v1 + (v4 * (v2 + (v4 * v3))))));
}
inline void spec_vx_lfsr_jump4(uint v0, uint v1, uint v2, uint v3, uint v4, uint v5, uint v6, uint v7, thread uint* out) {
  uint v8 = ((v0 ^ v1) ^ v4);
  uint v9 = ((v1 ^ v2) ^ v5);
  uint v10 = ((v2 ^ v3) ^ v6);
  uint v11 = ((v3 ^ v8) ^ v7);
  out[0] = v8;
  out[1] = v9;
  out[2] = v10;
  out[3] = v11;
}
inline void opt_vx_lfsr_jump4(uint v0, uint v1, uint v2, uint v3, uint v4, uint v5, uint v6, uint v7, thread uint* out) {
  out[0] = ((v0 ^ v1) ^ v4);
  out[1] = ((v1 ^ v2) ^ v5);
  out[2] = ((v2 ^ v3) ^ v6);
  out[3] = (((v0 ^ v1) ^ v3) ^ (v4 ^ v7));
}
inline void spec_vx_mux_pipe4(uint v0, uint v1, uint v2, uint v3, uint v4, thread uint* out) {
  uint v5 = ((v0 & v2) | ((~v0) & v3));
  out[0] = ((v1 & v5) | ((~v1) & v4));
}
inline void opt_vx_mux_pipe4(uint v0, uint v1, uint v2, uint v3, uint v4, thread uint* out) {
  uint v5 = (v0 & (v2 ^ v3));
  out[0] = (v4 ^ (v1 & ((v3 ^ v4) ^ v5)));
}
kernel void vx_verify_miter_kernel(device const uint* inBuf [[buffer(0)]], device uint* outErr [[buffer(1)]], device uint* outSig [[buffer(2)]], uint tid [[thread_position_in_grid]]) {
  uint b = tid * 4u;
  uint x0=inBuf[b], x1=inBuf[b+1u], x2=inBuf[b+2u], x3=inBuf[b+3u];
  uint x4=x0^0x9e3779b9u, x5=x1^0x85ebca6bu, x6=x2^0xc2b2ae35u, x7=x3^0x27d4eb2fu;
  uint s0[4], c0[4], s1[1], c1[1], s2[3], c2[3], s3[1], c3[1];
  spec_vx_lfsr_jump4(x0,x1,x2,x3,x4,x5,x6,x7,s0); opt_vx_lfsr_jump4(x0,x1,x2,x3,x4,x5,x6,x7,c0);
  spec_vx_mux_pipe4(x0,x1,x2,x3,x4,s1); opt_vx_mux_pipe4(x0,x1,x2,x3,x4,c1);
  spec_vx_coupled_eigen(x0,x1,x2,x3,x4,x5,x6,x7,s2); opt_vx_coupled_eigen(x0,x1,x2,x3,x4,x5,x6,x7,c2);
  spec_vx_horner_deg3(x0,x1,x2,x3,x4,s3); opt_vx_horner_deg3(x0,x1,x2,x3,x4,c3);
  uint miter = (s0[0]^c0[0]) | (s0[1]^c0[1]) | (s0[2]^c0[2]) | (s0[3]^c0[3]) | (s1[0]^c1[0]) | (s2[0]^c2[0]) | (s2[1]^c2[1]) | (s2[2]^c2[2]) | (s3[0]^c3[0]);
  // 4-step streaming Direct-Form vs Transposed-Systolic filter miter on GPU
  uint h1=0u, h2=0u, h3=0u, p0=0u, p1=0u, p2=0u;
  uint xs[4] = { x0, x1, x2, x3 };
  for (uint k = 0u; k < 4u; k++) {
    uint u = xs[k];
    uint ys = 2u*u + 3u*h1 + 5u*h2 + 7u*h3, yi = 2u*u + p0;
    miter |= (ys ^ yi);
    h3=h2; h2=h1; h1=u; p0=3u*u+p1; p1=5u*u+p2; p2=7u*u;
  }
  outErr[tid] = miter;
  outSig[tid] = c0[0] ^ c1[0] ^ c2[0] ^ c3[0] ^ p0;
}
