#include <metal_stdlib>
using namespace metal;

// ==========================================================================
// ENGINE 1: MATRIX-FREE GPU LANCZOS FOR 2D FERMI-HUBBARD MODEL (2x4 LADDER)
//   Exact Jordan-Wigner fermionic anticommutation signs + Pauli exclusion!
// ==========================================================================
constant uchar BOND_A[10] = { 0,1,2, 4,5,6, 0,1,2,3 };
constant uchar BOND_B[10] = { 1,2,3, 5,6,7, 4,5,6,7 };

inline float jw_sign(uint mask, uint i, uint j) {
  uint lo = min(i, j), hi = max(i, j);
  uint between = mask & (((1u << hi) - 1u) ^ ((1u << (lo + 1u)) - 1u));
  return (popcount(between) & 1u) ? -1.0f : 1.0f;
}

kernel void hm_hubbard_matvec(
  device const uint* up_states [[buffer(0)]],
  device const uint* dn_states [[buffer(1)]],
  device const int*  up_idx    [[buffer(2)]], // 256-entry O(1) bitmask -> index table
  device const int*  dn_idx    [[buffer(3)]],
  device const float* vin      [[buffer(4)]],
  device float*       vout     [[buffer(5)]],
  constant uint4& dims         [[buffer(6)]], // x=nUp, y=nDn, z=nTot
  constant float& U            [[buffer(7)]],
  uint tid [[thread_position_in_grid]])
{
  if (tid >= dims.z) return;
  uint iu = tid / dims.y, id = tid % dims.y;
  uint mu = up_states[iu], md = dn_states[id];
  // Diagonal on-site Hubbard repulsion U * sum_i n_{i,up} * n_{i,dn}
  float acc = U * float(popcount(mu & md)) * vin[tid];
  // Off-diagonal hopping -t * sum_{<i,j>, sigma} (c+_{i,s} c_{j,s} + h.c.) with exact Jordan-Wigner sign!
  for (uint b = 0u; b < 10u; b++) {
    uint i = BOND_A[b], j = BOND_B[b];
    uint bi = 1u << i, bj = 1u << j;
    if (((mu & bi) != 0u) != ((mu & bj) != 0u)) {
      uint mu2 = mu ^ bi ^ bj;
      int iu2 = up_idx[mu2];
      acc -= jw_sign(mu, i, j) * vin[uint(iu2) * dims.y + id];
    }
    if (((md & bi) != 0u) != ((md & bj) != 0u)) {
      uint md2 = md ^ bi ^ bj;
      int id2 = dn_idx[md2];
      acc -= jw_sign(md, i, j) * vin[iu * dims.y + uint(id2)];
    }
  }
  vout[tid] = acc;
}

// ==========================================================================
// ENGINE 2: CERTIFIED GPU BRANCH-AND-BOUND OVER 16,777,216 (16^6) POCKET BINDERS
//   Lennard-Jones 12-6 steric + directional n_O->sigma*_NH H-bond + Coulomb + Born
// ==========================================================================
kernel void hm_pocket_bnb(
  device const int* site_e    [[buffer(0)]], // 6 x 16 unary binding energies (milli-kcal/mol)
  device const int* pair_e    [[buffer(1)]], // 15 x 256 pairwise LJ + H-bond + Coulomb terms
  device const int* rem_lb    [[buffer(2)]], // certified lower bound for remaining subsites
  device atomic_int* best_e   [[buffer(3)]], // [0]=global min energy (milli-kcal/mol)
  device atomic_uint* stats   [[buffer(4)]], // [0]=pruned_subtrees, [1]=eval_confs, [2]=best_code
  uint tid [[thread_position_in_grid]])
{
  // Each thread owns a 256-conformation subtree (s0, s1, s2, s3 fixed by tid in 0..65535; s4, s5 searched!)
  uint s0 = (tid >> 12) & 15u, s1 = (tid >> 8) & 15u, s2 = (tid >> 4) & 15u, s3 = tid & 15u;
  int e0123 = site_e[0*16+s0] + site_e[1*16+s1] + site_e[2*16+s2] + site_e[3*16+s3]
            + pair_e[0*256 + s0*16 + s1] + pair_e[1*256 + s0*16 + s2] + pair_e[2*256 + s0*16 + s3]
            + pair_e[3*256 + s1*16 + s2] + pair_e[4*256 + s1*16 + s3] + pair_e[5*256 + s2*16 + s3];
  // Certified Branch-and-Bound prune (sound by hm-thm-bnb-prune-sound!):
  int cur_best = atomic_load_explicit(&best_e[0], memory_order_relaxed);
  if (e0123 + rem_lb[4] > cur_best) {
    atomic_fetch_add_explicit(&stats[0], 256u, memory_order_relaxed);
    return;
  }
  int loc_best = cur_best; uint loc_code = 0u; uint ev = 0u; uint pr = 0u;
  for (uint s4 = 0u; s4 < 16u; s4++) {
    int e4 = e0123 + site_e[4*16+s4]
           + pair_e[6*256 + s0*16 + s4] + pair_e[7*256 + s1*16 + s4]
           + pair_e[8*256 + s2*16 + s4] + pair_e[9*256 + s3*16 + s4];
    if (e4 + rem_lb[5] > loc_best) { pr += 16u; continue; }
    for (uint s5 = 0u; s5 < 16u; s5++) {
      ev++;
      int tot = e4 + site_e[5*16+s5]
              + pair_e[10*256 + s0*16 + s5] + pair_e[11*256 + s1*16 + s5]
              + pair_e[12*256 + s2*16 + s5] + pair_e[13*256 + s3*16 + s5] + pair_e[14*256 + s4*16 + s5];
      if (tot < loc_best) {
        loc_best = tot;
        loc_code = (s0<<20)|(s1<<16)|(s2<<12)|(s3<<8)|(s4<<4)|s5;
      }
    }
  }
  atomic_fetch_add_explicit(&stats[0], pr, memory_order_relaxed);
  atomic_fetch_add_explicit(&stats[1], ev, memory_order_relaxed);
  int prev = atomic_fetch_min_explicit(&best_e[0], loc_best, memory_order_relaxed);
  if (loc_best < prev) atomic_store_explicit(&stats[2], loc_code, memory_order_relaxed);
}

// ==========================================================================
// ENGINE 3: 32,768 PARALLEL GPU SE(3) PROTEIN BACKBONE FOLDER (TRP-CAGE 1L2Y)
//   20 residues: N L Y I Q W L K D G G P S S G R P P P S
// ==========================================================================
constant uchar TRP_HYDRO[20] = { 0,1,1,1,0,2,1,0,0,0,0,1,0,0,0,0,1,1,1,0 }; // 2=Trp6 core, 1=hydrophobic
inline uint xs32(thread uint& s) { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s; }

kernel void hm_fold_trpcage(
  device float* out_E  [[buffer(0)]],
  device float* out_Rg [[buffer(1)]],
  constant uint& steps [[buffer(2)]],
  uint tid [[thread_position_in_grid]])
{
  uint rng = (tid + 1u) * 0x9e3779b9u ^ 0x517cc1b7u;
  float phi[20], psi[20];
  // Initialize from Ramachandran basins (alpha-helix res 1..8, 3_10/turn 9..14, polyproline 15..19)
  for (uint i = 0u; i < 20u; i++) {
    float u1 = float(xs32(rng) & 0xFFFFu) / 65536.0f;
    float u2 = float(xs32(rng) & 0xFFFFu) / 65536.0f;
    phi[i] = (i >= 1u && i <= 8u) ? (-1.05f + 0.35f*(u1-0.5f)) : (-1.2f + 1.8f*(u1-0.5f));
    psi[i] = (i >= 1u && i <= 8u) ? (-0.75f + 0.35f*(u2-0.5f)) : ( 1.8f + 1.8f*(u2-0.5f));
  }
  float bestE = 1e9f, bestRg = 99.0f;
  float3 pos[20];
  for (uint st = 0u; st < steps; st++) {
    uint m = xs32(rng) % 20u;
    float ophi = phi[m], opsi = psi[m];
    float d1 = (float(xs32(rng) & 0xFFFFu) / 65536.0f - 0.5f) * 0.4f;
    float d2 = (float(xs32(rng) & 0xFFFFu) / 65536.0f - 0.5f) * 0.4f;
    phi[m] += d1; psi[m] += d2;
    // Forward SE(3) chain kinematics (Ca-Ca bond = 3.8 Angstrom, exact orthonormal Frenet frame!)
    float3 p = float3(0.0f), tx = float3(1.0f,0.0f,0.0f), ny = float3(0.0f,1.0f,0.0f), bz = float3(0.0f,0.0f,1.0f);
    pos[0] = p;
    float3 cm = p;
    for (uint i = 1u; i < 20u; i++) {
      float cp = cos(phi[i]), sp = sin(phi[i]), cs = cos(psi[i]), ss = sin(psi[i]);
      // Exact SO(3) rotation around local frame axes (preserves unit norm & orthogonality!)
      float3 ny2 = cp * ny + sp * bz;
      float3 bz2 = -sp * ny + cp * bz;
      float3 tx2 = cs * tx + ss * ny2;
      float3 ny3 = -ss * tx + cs * ny2;
      tx = normalize(tx2); ny = normalize(ny3); bz = cross(tx, ny);
      p += 3.8f * tx;
      pos[i] = p; cm += p;
    }
    cm *= 0.05f;
    float rg2 = 0.0f; for (uint i = 0u; i < 20u; i++) { float3 d = pos[i] - cm; rg2 += dot(d, d); }
    float rg = sqrt(rg2 * 0.05f);
    // Pairwise contact energy: LJ steric clash + hydrophobic core packing + helix i->i+4 H-bond
    float E = 0.0f;
    for (uint i = 0u; i < 20u; i++) {
      for (uint j = i + 2u; j < 20u; j++) {
        float3 dv = pos[i] - pos[j];
        float r2 = dot(dv, dv);
        if (r2 < 14.44f) E += 40.0f * (14.44f - r2); // steric clash penalty (r < 3.8 A)
        else if (r2 < 56.25f) {
          uint hi = TRP_HYDRO[i], hj = TRP_HYDRO[j];
          if (hi > 0u && hj > 0u) E -= float(hi * hj) * 2.5f * exp(-0.12f * (r2 - 25.0f));
          if (j == i + 4u && i >= 1u && i <= 5u && r2 < 38.0f) E -= 2.2f; // alpha-helix i->i+4 H-bond
        }
      }
    }
    if (E < bestE) { bestE = E; bestRg = rg; }
    else { phi[m] = ophi; psi[m] = opsi; }
  }
  out_E[tid] = bestE; out_Rg[tid] = bestRg;
}
