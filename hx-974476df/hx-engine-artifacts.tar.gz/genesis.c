/* Mechanically lowered from certified GenesisCrystal in lib/ir/poly-opt.hypercubical */
#include <stdint.h>
#include <stdio.h>
static inline void spec_howell8_quat(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t v6, uint32_t v7, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5; (void)v6; (void)v7;
  uint32_t v8 = (v0 + v0);
  uint32_t v9 = (v1 + v1);
  uint32_t v10 = (v2 + v2);
  uint32_t v11 = (v3 + v3);
  out[0] = ((((v8 * v4) - (v9 * v5)) - (v10 * v6)) - (v11 * v7));
  out[1] = ((((v8 * v5) + (v9 * v4)) + (v10 * v7)) - (v11 * v6));
  out[2] = ((((v8 * v6) - (v9 * v7)) + (v10 * v4)) + (v11 * v5));
  out[3] = ((((v8 * v7) + (v9 * v6)) - (v10 * v5)) + (v11 * v4));
}
static inline void opt_howell8_quat(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t v6, uint32_t v7, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5; (void)v6; (void)v7;
  uint32_t v8 = ((v0 + v1) * (v4 + v5));
  uint32_t v9 = ((v3 - v2) * (v6 - v7));
  uint32_t v10 = ((v0 - v1) * (v6 + v7));
  uint32_t v11 = ((v2 + v3) * (v4 - v5));
  uint32_t v12 = ((v1 + v3) * (v5 + v6));
  uint32_t v13 = ((v1 - v3) * (v5 - v6));
  uint32_t v14 = ((v0 + v2) * (v4 - v7));
  uint32_t v15 = ((v0 - v2) * (v4 + v7));
  uint32_t v16 = (v12 + v13);
  uint32_t v17 = (v12 - v13);
  uint32_t v18 = (v14 + v15);
  uint32_t v19 = (v14 - v15);
  out[0] = ((v9 + v9) + (v18 - v16));
  out[1] = ((v8 + v8) - (v18 + v16));
  out[2] = ((v10 + v10) + (v19 + v17));
  out[3] = (((v11 + v11) - v19) + v17);
}
static inline void spec_euler_4sq(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t v6, uint32_t v7, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5; (void)v6; (void)v7;
  uint32_t v8 = ((((v0 * v4) - (v1 * v5)) - (v2 * v6)) - (v3 * v7));
  uint32_t v9 = ((((v0 * v5) + (v1 * v4)) + (v2 * v7)) - (v3 * v6));
  uint32_t v10 = ((((v0 * v6) - (v1 * v7)) + (v2 * v4)) + (v3 * v5));
  uint32_t v11 = ((((v0 * v7) + (v1 * v6)) - (v2 * v5)) + (v3 * v4));
  out[0] = (((v8 * v8) + (v9 * v9)) + ((v10 * v10) + (v11 * v11)));
}
static inline void opt_euler_4sq(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t v6, uint32_t v7, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5; (void)v6; (void)v7;
  uint32_t v8 = (((v0 * v0) + (v1 * v1)) + ((v2 * v2) + (v3 * v3)));
  uint32_t v9 = (((v4 * v4) + (v5 * v5)) + ((v6 * v6) + (v7 * v7)));
  out[0] = (v8 * v9);
}
static inline void spec_adelic_hadamard(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3;
  out[0] = (((1u * v0) + (1u * v1)) + ((1u * v2) + (1u * v3)));
  out[1] = (((1u * v0) + ((0u - 1u) * v1)) + ((1u * v2) + ((0u - 1u) * v3)));
  out[2] = (((1u * v0) + (1u * v1)) + (((0u - 1u) * v2) + ((0u - 1u) * v3)));
  out[3] = (((1u * v0) + ((0u - 1u) * v1)) + (((0u - 1u) * v2) + (1u * v3)));
}
static inline void opt_adelic_hadamard(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3;
  uint32_t v4 = (v0 + v2);
  uint32_t v5 = (v0 - v2);
  uint32_t v6 = (v1 + v3);
  uint32_t v7 = (v1 - v3);
  out[0] = (v4 + v6);
  out[1] = (v4 - v6);
  out[2] = (v5 + v7);
  out[3] = (v5 - v7);
}
static inline void spec_poisson_plancherel(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3;
  uint32_t v4 = ((v0 + v1) + (v2 + v3));
  uint32_t v5 = ((v0 - v1) + (v2 - v3));
  uint32_t v6 = ((v0 + v1) - (v2 + v3));
  uint32_t v7 = ((v0 - v1) - (v2 - v3));
  uint32_t v8 = ((v4 + v5) + (v6 + v7));
  uint32_t v9 = ((v4 - v5) + (v6 - v7));
  uint32_t v10 = ((v4 + v5) - (v6 + v7));
  uint32_t v11 = ((v4 - v5) - (v6 - v7));
  uint32_t v12 = (((v0 * v0) + (v1 * v1)) + ((v2 * v2) + (v3 * v3)));
  uint32_t v13 = (((v4 * v4) + (v5 * v5)) + ((v6 * v6) + (v7 * v7)));
  out[0] = (((v0 + v2) + (v0 + v2)) - (v4 + v5));
  out[1] = (v13 - ((v12 + v12) + (v12 + v12)));
  out[2] = (v8 - ((v0 + v0) + (v0 + v0)));
  out[3] = (v9 - ((v1 + v1) + (v1 + v1)));
  out[4] = (v10 - ((v2 + v2) + (v2 + v2)));
  out[5] = (v11 - ((v3 + v3) + (v3 + v3)));
}
static inline void opt_poisson_plancherel(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3;
  out[0] = 0u;
  out[1] = 0u;
  out[2] = 0u;
  out[3] = 0u;
  out[4] = 0u;
  out[5] = 0u;
}
static inline void spec_alpoge_masullo(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t v6, uint32_t v7, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5; (void)v6; (void)v7;
  uint32_t v8 = ((((v0 * v4) + (v1 * v5)) * v6) + (((v2 * v4) + (v3 * v5)) * v7));
  uint32_t v9 = ((v4 * ((v0 * v6) + (v2 * v7))) + (v5 * ((v1 * v6) + (v3 * v7))));
  uint32_t v10 = (((v0 * v4) + (v1 * v6)) + ((v2 * v5) + (v3 * v7)));
  uint32_t v11 = (((v4 * v0) + (v5 * v2)) + ((v6 * v1) + (v7 * v3)));
  out[0] = (v8 - v9);
  out[1] = (v10 - v11);
  out[2] = ((((v0 * v0) + (v1 * v1)) + ((v0 * v0) + (v1 * v1))) - ((v0 + v1) * (v0 + v1)));
  out[3] = (((v0 - ((v1 + v2) + v3)) + v3) + v2);
}
static inline void opt_alpoge_masullo(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t v6, uint32_t v7, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5; (void)v6; (void)v7;
  uint32_t v8 = (v0 - v1);
  out[0] = 0u;
  out[1] = 0u;
  out[2] = (v8 * v8);
  out[3] = v8;
}
static inline void spec_darwin_stokes(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5;
  uint32_t v6 = (v0 * (v2 + v4));
  uint32_t v7 = (v1 * (v3 + v5));
  uint32_t v8 = ((v0 + v1) * (v2 + v3));
  uint32_t v9 = (v0 + v1);
  uint32_t v10 = (v2 - v0);
  uint32_t v11 = ((0u - v1) - v2);
  uint32_t v12 = (v0 + v3);
  uint32_t v13 = (v1 - v3);
  uint32_t v14 = (v2 + v3);
  uint32_t v15 = (v0 * (v1 * v1));
  uint32_t v16 = (2u - v15);
  out[0] = (((v6 + v7) + (v6 + v7)) - v8);
  out[1] = (((0u - v9) - v10) - v11);
  out[2] = ((v9 - v12) - v13);
  out[3] = ((v10 + v12) - v14);
  out[4] = ((v11 + v13) + v14);
  out[5] = ((v16 * v16) + (v15 * (4u - v15)));
}
static inline void opt_darwin_stokes(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5;
  uint32_t v6 = ((v0 - v1) * (v2 - v3));
  uint32_t v7 = ((v0 * v4) + (v1 * v5));
  out[0] = (v6 + (v7 + v7));
  out[1] = 0u;
  out[2] = 0u;
  out[3] = 0u;
  out[4] = 0u;
  out[5] = 4u;
}
static inline void spec_fredkin_1and(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t* out) {
  out[0] = v0;
  out[1] = (((~v0) & v1) | (v0 & v2));
  out[2] = (((~v0) & v2) | (v0 & v1));
}
static inline void opt_fredkin_1and(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t* out) {
  uint32_t v3 = (v1 ^ v2);
  uint32_t v4 = (v0 & v3);
  out[0] = v0;
  out[1] = (v1 ^ v4);
  out[2] = (v2 ^ v4);
}
static inline void spec_keccak_chi5(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t* out) {
  out[0] = ((v0 & (~((~v1) & v2))) | ((~v0) & ((~v1) & v2)));
  out[1] = ((v1 & (~((~v2) & v3))) | ((~v1) & ((~v2) & v3)));
  out[2] = ((v2 & (~((~v3) & v4))) | ((~v2) & ((~v3) & v4)));
  out[3] = ((v3 & (~((~v4) & v0))) | ((~v3) & ((~v4) & v0)));
  out[4] = ((v4 & (~((~v0) & v1))) | ((~v4) & ((~v0) & v1)));
}
static inline void opt_keccak_chi5(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t* out) {
  out[0] = (v0 ^ ((~v1) & v2));
  out[1] = (v1 ^ ((~v2) & v3));
  out[2] = (v2 ^ ((~v3) & v4));
  out[3] = (v3 ^ ((~v4) & v0));
  out[4] = (v4 ^ ((~v0) & v1));
}
int main(void) {
  uint32_t s[8], c[8], err = 0u;
  uint64_t rng = 0x243f6a8885a308d3ULL;
  for (uint32_t i = 0u; i < 200000u; i++) {
    rng ^= rng << 13; rng ^= rng >> 7; rng ^= rng << 17;
    uint32_t x0=(uint32_t)rng, x1=(uint32_t)(rng>>8), x2=(uint32_t)(rng>>16), x3=(uint32_t)(rng>>24);
    uint32_t x4=(uint32_t)(rng>>32), x5=(uint32_t)(rng>>40), x6=x0^0x9e3779b9u, x7=x4+i*2654435761u;
    spec_howell8_quat(x0,x1,x2,x3,x4,x5,x6,x7,s); opt_howell8_quat(x0,x1,x2,x3,x4,x5,x6,x7,c);
    if (s[0]!=c[0]||s[1]!=c[1]||s[2]!=c[2]||s[3]!=c[3]) err++;
    spec_euler_4sq(x0,x1,x2,x3,x4,x5,x6,x7,s); opt_euler_4sq(x0,x1,x2,x3,x4,x5,x6,x7,c);
    if (s[0]!=c[0]) err++;
    spec_adelic_hadamard(x0,x1,x2,x3,s); opt_adelic_hadamard(x0,x1,x2,x3,c);
    if (s[0]!=c[0]||s[1]!=c[1]||s[2]!=c[2]||s[3]!=c[3]) err++;
    spec_poisson_plancherel(x0,x1,x2,x3,s); opt_poisson_plancherel(x0,x1,x2,x3,c);
    if (s[0]!=0u||s[1]!=0u||s[2]!=0u||s[3]!=0u||s[4]!=0u||s[5]!=0u||c[0]!=0u) err++;
    spec_alpoge_masullo(x0,x1,x2,x3,x4,x5,x6,x7,s); opt_alpoge_masullo(x0,x1,x2,x3,x4,x5,x6,x7,c);
    if (s[0]!=0u||s[1]!=0u||s[2]!=c[2]||s[3]!=c[3]) err++;
    spec_darwin_stokes(x0,x1,x2,x3,x4,x5,s); opt_darwin_stokes(x0,x1,x2,x3,x4,x5,c);
    if (s[0]!=c[0]||s[1]!=0u||s[2]!=0u||s[3]!=0u||s[4]!=0u||s[5]!=4u||c[5]!=4u) err++;
    spec_fredkin_1and(x0,x1,x2,s); opt_fredkin_1and(x0,x1,x2,c);
    if (s[0]!=c[0]||s[1]!=c[1]||s[2]!=c[2]) err++;
    spec_keccak_chi5(x0,x1,x2,x3,x4,s); opt_keccak_chi5(x0,x1,x2,x3,x4,c);
    if (s[0]!=c[0]||s[1]!=c[1]||s[2]!=c[2]||s[3]!=c[3]||s[4]!=c[4]) err++;
  }
  printf("HX-GENESIS C11 Verifier: 8/8 universal superopts x 200,000 vectors = 1,600,000 checks | errors=%u\n", err);
  return err ? 1 : 0;
}
