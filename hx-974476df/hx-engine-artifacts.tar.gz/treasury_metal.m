#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <stdint.h>
#include <stdio.h>
#include <mach/mach_time.h>
static const char* kTrMetalPath = "/home/claude/hxb/out/treasury.metal";
typedef struct { uint64_t best_profit; uint64_t founder_cut; uint32_t k_ok; uint32_t dust_ok; uint32_t dag_ok; uint32_t antimev_ok; } TrGpuRes;
int main(void) {
  @autoreleasepool {
    id<MTLDevice> dev = MTLCreateSystemDefaultDevice();
    if (!dev) { printf("NO_METAL_DEVICE\n"); return 1; }
    NSError* err = nil;
    NSString* src = [NSString stringWithContentsOfFile:[NSString stringWithUTF8String:kTrMetalPath] encoding:NSUTF8StringEncoding error:&err];
    MTLCompileOptions* opts = [[MTLCompileOptions alloc] init];
    opts.mathMode = MTLMathModeSafe;
    id<MTLLibrary> lib = [dev newLibraryWithSource:src options:opts error:&err];
    if (!lib) { fprintf(stderr, "Metal err: %s\n", [[err localizedDescription] UTF8String]); return 1; }
    id<MTLFunction> fn = [lib newFunctionWithName:@"hx_treasury_u256_kernel"];
    id<MTLComputePipelineState> pso = [dev newComputePipelineStateWithFunction:fn error:&err];
    id<MTLCommandQueue> q = [dev newCommandQueue];
    const uint32_t N = 65536u, STEPS = 16u; // 1,048,576 full 256-bit (U256 >2^155 wei) counterfactual AMM routes!
    id<MTLBuffer> bOut = [dev newBufferWithLength:(size_t)N*sizeof(TrGpuRes) options:MTLResourceStorageModeShared];
    mach_timebase_info_data_t tb; mach_timebase_info(&tb);
    uint64_t t0 = mach_absolute_time();
    id<MTLCommandBuffer> cb = [q commandBuffer];
    id<MTLComputeCommandEncoder> enc = [cb computeCommandEncoder];
    [enc setComputePipelineState:pso]; [enc setBuffer:bOut offset:0 atIndex:0]; [enc setBytes:&STEPS length:4 atIndex:1];
    [enc dispatchThreads:MTLSizeMake(N,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)];
    [enc endEncoding]; [cb commit]; [cb waitUntilCompleted];
    uint64_t t1 = mach_absolute_time();
    double sec = (double)(t1 - t0) * (double)tb.numer / ((double)tb.denom * 1e9);
    TrGpuRes* r = (TrGpuRes*)[bOut contents];
    uint32_t kok=1u, dok=1u, gok=1u, mok=1u, pos=0u; uint64_t fSum=0ull;
    for(uint32_t i=0;i<N;i++){ kok&=r[i].k_ok; dok&=r[i].dust_ok; gok&=r[i].dag_ok; mok&=r[i].antimev_ok; if(r[i].best_profit>0) pos++; fSum+=r[i].founder_cut; }
    uint64_t routes = (uint64_t)N * (uint64_t)STEPS;
    printf("[HX-TREASURY METAL U256 SIM (%s)] routes=%llu | time=%.3f ms | %.2f M-u256-routes/s | k_ok=%u dust_ok=%u dag_ok=%u antimev_ok=%u arb_pools=%u/%u\n", [[dev name] UTF8String], (unsigned long long)routes, sec*1e3, (double)routes/(sec*1e6), kok, dok, gok, mok, pos, N);
    return (kok && dok && gok && mok && pos == N && fSum > 0ull) ? 0 : 1;
  }
}
