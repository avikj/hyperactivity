// Mechanically lowered from GenesisCrystal (NVIDIA CUDA sm_90a — 42-GPU H100/H200 Fleet Target!)
#include <stdint.h>
__device__ __forceinline__ void opt_howell8_quat(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t v6, uint32_t v7, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5; (void)v6; (void)v7;
  uint32_t v8 = ((v0 + v1) * (v4 + v5));
  uint32_t v9 = ((v3 - v2) * (v6 - v7));
  uint32_t v10 = ((v0 - v1) * (v6 + v7));
  uint32_t v11 = ((v2 + v3) * (v4 - v5));
  uint32_t v12 = ((v1 + v3) * (v5 + v6));
  uint32_t v13 = ((v1 - v3) * (v5 - v6));
  uint32_t v14 = ((v0 + v2) * (v4 - v7));
  uint32_t v15 = ((v0 - v2) * (v4 + v7));
  uint32_t v16 = (v12 + v13);
  uint32_t v17 = (v12 - v13);
  uint32_t v18 = (v14 + v15);
  uint32_t v19 = (v14 - v15);
  out[0] = ((v9 + v9) + (v18 - v16));
  out[1] = ((v8 + v8) - (v18 + v16));
  out[2] = ((v10 + v10) + (v19 + v17));
  out[3] = (((v11 + v11) - v19) + v17);
}
__device__ __forceinline__ void opt_euler_4sq(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t v6, uint32_t v7, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5; (void)v6; (void)v7;
  uint32_t v8 = (((v0 * v0) + (v1 * v1)) + ((v2 * v2) + (v3 * v3)));
  uint32_t v9 = (((v4 * v4) + (v5 * v5)) + ((v6 * v6) + (v7 * v7)));
  out[0] = (v8 * v9);
}
__device__ __forceinline__ void opt_adelic_hadamard(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3;
  uint32_t v4 = (v0 + v2);
  uint32_t v5 = (v0 - v2);
  uint32_t v6 = (v1 + v3);
  uint32_t v7 = (v1 - v3);
  out[0] = (v4 + v6);
  out[1] = (v4 - v6);
  out[2] = (v5 + v7);
  out[3] = (v5 - v7);
}
__device__ __forceinline__ void opt_poisson_plancherel(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3;
  out[0] = 0u;
  out[1] = 0u;
  out[2] = 0u;
  out[3] = 0u;
  out[4] = 0u;
  out[5] = 0u;
}
__device__ __forceinline__ void opt_alpoge_masullo(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t v6, uint32_t v7, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5; (void)v6; (void)v7;
  uint32_t v8 = (v0 - v1);
  out[0] = 0u;
  out[1] = 0u;
  out[2] = (v8 * v8);
  out[3] = v8;
}
__device__ __forceinline__ void opt_darwin_stokes(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5;
  uint32_t v6 = ((v0 - v1) * (v2 - v3));
  uint32_t v7 = ((v0 * v4) + (v1 * v5));
  out[0] = (v6 + (v7 + v7));
  out[1] = 0u;
  out[2] = 0u;
  out[3] = 0u;
  out[4] = 0u;
  out[5] = 4u;
}
__device__ __forceinline__ void opt_fredkin_1and(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t* out) {
  uint32_t v3 = (v1 ^ v2);
  uint32_t v4 = (v0 & v3);
  out[0] = v0;
  out[1] = (v1 ^ v4);
  out[2] = (v2 ^ v4);
}
__device__ __forceinline__ void opt_keccak_chi5(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t* out) {
  out[0] = (v0 ^ ((~v1) & v2));
  out[1] = (v1 ^ ((~v2) & v3));
  out[2] = (v2 ^ ((~v3) & v4));
  out[3] = (v3 ^ ((~v4) & v0));
  out[4] = (v4 ^ ((~v0) & v1));
}
__global__ void genesis_cuda_kernel(const uint32_t* in, uint32_t* out, uint32_t n) {
  uint32_t tid = blockIdx.x * blockDim.x + threadIdx.x; if (tid >= n) return;
  uint32_t x0=in[tid*4u], x1=in[tid*4u+1u], x2=in[tid*4u+2u], x3=in[tid*4u+3u];
  uint32_t x4=x0^0x9e3779b9u, x5=x1^0x85ebca6bu, x6=x2^0xc2b2ae35u, x7=x3^0x27d4eb2fu;
  uint32_t q[4], e[1], h[4], fr[3], kc[5];
  opt_howell8_quat(x0,x1,x2,x3,x4,x5,x6,x7,q); opt_euler_4sq(x0,x1,x2,x3,x4,x5,x6,x7,e);
  opt_adelic_hadamard(x0,x1,x2,x3,h); opt_fredkin_1and(x0,x1,x2,fr); opt_keccak_chi5(x0,x1,x2,x3,x4,kc);
  out[tid] = q[0] ^ q[1] ^ q[2] ^ q[3] ^ e[0] ^ h[0] ^ h[1] ^ fr[1] ^ fr[2] ^ kc[0] ^ kc[4];
}
