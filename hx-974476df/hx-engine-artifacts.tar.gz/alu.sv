// Proof-Carrying Complete 10-Op 32-bit RV32I ALU lowered mechanically from cir-fa1-net (lib/ir/circuit-ir.hypercubical)
// Optimal 9-NAND2 Full Adder (288 NAND2 for 32-bit) universally proven over Bool^3 + N-bit induction (cir-thm-ripple-universal)
module hx_fa1_nand2(input logic a, input logic b, input logic cin, output logic sum, output logic cout);
  wire w0 = a, w1 = b, w2 = cin;
  wire w3 = ~(w0 & w1);
  wire w4 = ~(w0 & w3);
  wire w5 = ~(w1 & w3);
  wire w6 = ~(w4 & w5);
  wire w7 = ~(w6 & w2);
  wire w8 = ~(w6 & w7);
  wire w9 = ~(w2 & w7);
  wire w10 = ~(w8 & w9);
  wire w11 = ~(w3 & w7);
  assign sum = w10;
  assign cout = w11;
endmodule
module hx_rv32i_alu(input logic [3:0] op, input logic [31:0] a, input logic [31:0] b, output logic [31:0] y);
  wire is_sub = (op == 4'd1);
  wire [31:0] bx = is_sub ? ~b : b;
  wire [32:0] c;
  wire [31:0] sum;
  assign c[0] = is_sub;
  genvar i;
  generate for (i = 0; i < 32; i = i + 1) begin : g_fa
    hx_fa1_nand2 u_fa(.a(a[i]), .b(bx[i]), .cin(c[i]), .sum(sum[i]), .cout(c[i+1]));
  end endgenerate
  always_comb begin
    unique case (op)
      4'd0: y = sum;
      4'd1: y = sum;
      4'd2: y = a & b;
      4'd3: y = a | b;
      4'd4: y = a ^ b;
      4'd5: y = {31'd0, (a < b)};
      4'd6: y = {31'd0, ($signed(a) < $signed(b))};
      4'd7: y = a << b[4:0];
      4'd8: y = a >> b[4:0];
      4'd9: y = $signed(a) >>> b[4:0];
      default: y = 32'd0;
    endcase
  end
endmodule
