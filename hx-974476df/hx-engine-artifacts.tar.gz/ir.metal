// Generated mechanically from KernelIR (lib/ir/kernel-ir.hypercubical) — verified by kir-opt-sound
#include <metal_stdlib>
using namespace metal;
inline uint kir_ch(uint x0, uint x1, uint x2) { return (x2 ^ (x0 & (x1 ^ x2))); }
inline uint kir_maj(uint x0, uint x1, uint x2) { return (x0 ^ ((x0 ^ x1) & (x0 ^ x2))); }
inline uint kir_cancel(uint x0, uint x1, uint x2) { return 0u; }
kernel void kir_verify(device const uint* in [[buffer(0)]], device uint* out [[buffer(1)]], uint tid [[thread_position_in_grid]]) {
  uint x0 = in[tid*3u], x1 = in[tid*3u+1u], x2 = in[tid*3u+2u];
  out[tid*3u] = kir_ch(x0,x1,x2); out[tid*3u+1u] = kir_maj(x0,x1,x2); out[tid*3u+2u] = kir_cancel(x0,x1,x2);
}
