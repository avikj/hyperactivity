// hx_meta_inet.sv — Universal GPU-Superoptimized 4-Input Cubical Interaction-Net Silicon (61 NAND2)
// EVERY gate below was discovered by Apple A18 Pro GPU synthesis and lowered MECHANICALLY from ms-all-circuits!
module hx_meta_cub_face_conflict4(input logic w0, input logic w1, input logic w2, input logic w3, output logic y);
  wire w4 = ~(w2 & w2);
  wire w5 = ~(w3 & w4);
  wire w6 = ~(w5 & w4);
  wire w7 = ~(w6 & w1);
  wire w8 = ~(w6 & w0);
  wire w9 = ~(w8 & w7);
  assign y = w9;
endmodule
module hx_meta_cub_demorgan_alu4(input logic w0, input logic w1, input logic w2, input logic w3, output logic y);
  wire w4 = ~(w3 & w1);
  wire w5 = ~(w2 & w0);
  wire w6 = ~(w2 & w5);
  wire w7 = ~(w3 & w4);
  wire w8 = ~(w5 & w0);
  wire w9 = ~(w8 & w6);
  wire w10 = ~(w4 & w1);
  wire w11 = ~(w7 & w9);
  wire w12 = ~(w11 & w10);
  assign y = w12;
endmodule
module hx_meta_inet_era_either4(input logic w0, input logic w1, input logic w2, input logic w3, output logic y);
  wire w4 = ~(w3 & w3);
  wire w5 = ~(w2 & w4);
  wire w6 = ~(w5 & w4);
  wire w7 = ~(w0 & w6);
  wire w8 = ~(w1 & w7);
  wire w9 = ~(w8 & w7);
  wire w10 = ~(w9 & w6);
  assign y = w10;
endmodule
module hx_meta_inet_commute4(input logic w0, input logic w1, input logic w2, input logic w3, output logic y);
  wire w4 = ~(w0 & w2);
  wire w5 = ~(w1 & w0);
  wire w6 = ~(w0 & w3);
  wire w7 = ~(w3 & w2);
  wire w8 = ~(w7 & w5);
  wire w9 = ~(w6 & w4);
  wire w10 = ~(w9 & w8);
  wire w11 = ~(w10 & w9);
  wire w12 = ~(w11 & w11);
  assign y = w12;
endmodule
module hx_meta_inet_annihilate4(input logic w0, input logic w1, input logic w2, input logic w3, output logic y);
  wire w4 = ~(w1 & w0);
  wire w5 = ~(w2 & w4);
  wire w6 = ~(w0 & w3);
  wire w7 = ~(w5 & w0);
  wire w8 = ~(w6 & w4);
  wire w9 = ~(w8 & w5);
  wire w10 = ~(w1 & w2);
  wire w11 = ~(w6 & w7);
  wire w12 = ~(w9 & w11);
  wire w13 = ~(w12 & w12);
  assign y = w13;
endmodule
module hx_meta_inet_vxchg_arb4(input logic w0, input logic w1, input logic w2, input logic w3, output logic y);
  wire w4 = ~(w1 & w0);
  wire w5 = ~(w0 & w4);
  wire w6 = ~(w4 & w1);
  wire w7 = ~(w3 & w2);
  wire w8 = ~(w5 & w6);
  wire w9 = ~(w7 & w8);
  wire w10 = ~(w9 & w2);
  wire w11 = ~(w2 & w10);
  wire w12 = ~(w11 & w11);
  assign y = w12;
endmodule
module hx_meta_inet_tag_neq4(input logic w0, input logic w1, input logic w2, input logic w3, output logic y);
  wire w4 = ~(w0 & w2);
  wire w5 = ~(w0 & w4);
  wire w6 = ~(w2 & w4);
  wire w7 = ~(w1 & w3);
  wire w8 = ~(w1 & w7);
  wire w9 = ~(w3 & w7);
  wire w10 = ~(w5 & w8);
  wire w11 = ~(w10 & w10);
  wire w12 = ~(w6 & w9);
  wire w13 = ~(w12 & w12);
  wire w14 = ~(w11 & w13);
  assign y = w14;
endmodule

module hx_meta_inet_tile (
  input  logic       pair_valid,
  input  logic [1:0] tag_a, tag_b,
  input  logic [3:0] fa0, fa1, fb0, fb1,
  input  logic       iv_a, iv_b, iv_neg, iv_and,
  input  logic       arr_a, arr_b, vx_wait,
  output logic       out_conflict, out_era, out_tag_neq, out_commute, out_annihilate, out_vx_arb, out_iv
);
  wire [3:0] fc;
  genvar d;
  generate for (d = 0; d < 4; d = d + 1) begin : g_fc4
    hx_meta_cub_face_conflict4 u_fc (.w0(fa0[d]), .w1(fb0[d]), .w2(fa1[d]), .w3(fb1[d]), .y(fc[d]));
  end endgenerate
  assign out_conflict = |fc;
  hx_meta_inet_era_either4  u_era (.w0(tag_a[0]), .w1(tag_a[1]), .w2(tag_b[0]), .w3(tag_b[1]), .y(out_era));
  hx_meta_inet_tag_neq4     u_tnq (.w0(tag_a[0]), .w1(tag_a[1]), .w2(tag_b[0]), .w3(tag_b[1]), .y(out_tag_neq));
  wire pruned = out_conflict | out_era;
  hx_meta_inet_commute4     u_cm  (.w0(pair_valid), .w1(pruned), .w2(tag_a[0]), .w3(tag_b[0]), .y(out_commute));
  hx_meta_inet_annihilate4  u_an  (.w0(pair_valid), .w1(pruned), .w2(tag_a[0]), .w3(tag_b[0]), .y(out_annihilate));
  hx_meta_inet_vxchg_arb4   u_vx  (.w0(arr_a), .w1(arr_b), .w2(vx_wait), .w3(pruned), .y(out_vx_arb));
  hx_meta_cub_demorgan_alu4 u_dm  (.w0(iv_a), .w1(iv_b), .w2(iv_neg), .w3(iv_and), .y(out_iv));
endmodule

module tt_um_hx_meta_inet (
  input logic [7:0] ui_in, output logic [7:0] uo_out,
  input logic [7:0] uio_in, output logic [7:0] uio_out, output logic [7:0] uio_oe,
  input logic ena, input logic clk, input logic rst_n
);
  hx_meta_inet_tile u_t (
    .pair_valid(ui_in[0]), .tag_a(ui_in[2:1]), .tag_b(ui_in[4:3]),
    .fa0({3'b0,ui_in[5]}), .fa1({3'b0,ui_in[6]}), .fb0({3'b0,ui_in[7]}), .fb1({3'b0,uio_in[0]}),
    .iv_a(uio_in[1]), .iv_b(uio_in[2]), .iv_neg(uio_in[3]), .iv_and(uio_in[4]),
    .arr_a(uio_in[5]), .arr_b(uio_in[6]), .vx_wait(uio_in[7]),
    .out_conflict(uo_out[0]), .out_era(uo_out[1]), .out_tag_neq(uo_out[2]),
    .out_commute(uo_out[3]), .out_annihilate(uo_out[4]), .out_vx_arb(uo_out[5]), .out_iv(uo_out[6])
  );
  assign uo_out[7] = 1'b0; assign uio_out = 8'd0; assign uio_oe = 8'd0;
endmodule
