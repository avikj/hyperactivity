// Generated mechanically from KernelIR (lib/ir/kernel-ir.hypercubical) — verified by kir-opt-sound
module hx_kir_core (input logic [31:0] x0, input logic [31:0] x1, input logic [31:0] x2,
                    output logic [31:0] y_ch, output logic [31:0] y_maj, output logic [31:0] y_cancel);
  assign y_ch     = (x2 ^ (x0 & (x1 ^ x2)));
  assign y_maj    = (x0 ^ ((x0 ^ x1) & (x0 ^ x2)));
  assign y_cancel = 32'h0;
endmodule
