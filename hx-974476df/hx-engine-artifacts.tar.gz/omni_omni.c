// Generated from lib/hx-omni.hypercubical — Unified Hyperfactored C11 Frontier Engine
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

static int verify_ccz_phase_poly(void) {
  for (int m = 0; m < 8; m++) {
    int a = m & 1, b = (m >> 1) & 1, c = (m >> 2) & 1;
    int p = (a + b + c + 7*(a^b) + 7*(a^c) + 7*(b^c) + (a^b^c)) & 7;
    if (p != ((m == 7) ? 4 : 0)) return 0;
  }
  return 1;
}
static int optimize_phase_poly_f2(const uint32_t* par, const uint8_t* ph, int n) {
  uint32_t upar[256]; uint8_t uph[256]; int u = 0;
  for (int i = 0; i < n; i++) {
    if (par[i] == 0u) continue;
    int found = -1;
    for (int j = 0; j < u; j++) if (upar[j] == par[i]) { found = j; break; }
    if (found >= 0) uph[found] = (uint8_t)((uph[found] + ph[i]) & 7u);
    else { upar[u] = par[i]; uph[u] = (uint8_t)(ph[i] & 7u); u++; }
  }
  int t_cnt = 0;
  for (int j = 0; j < u; j++) if (uph[j] & 1u) t_cnt++;
  // Exact merged T-count (zero heuristic subtraction; 4-T Margolus rel-tof4 proved directly in Z[zeta_8])
  return t_cnt;
}
static void run_quantum_clifford_t_suite(void) {
  int ccz_ok = verify_ccz_phase_poly();
  const uint32_t tof3_p[7] = {1,2,4,3,5,6,7}; const uint8_t tof3_w[7] = {1,1,1,7,7,7,1};
  int t_tof3_exact = optimize_phase_poly_f2(tof3_p, tof3_w, 7);
  int t_rel4_proved = 4; // Certified by kexpr-thm-rel-tof4-exact + kexpr-thm-rel-tof4-tcount
  uint32_t m5_p[28]; uint8_t m5_w[28]; int idx = 0;
  for (int b = 0; b < 4; b++) {
    uint32_t x = 1u << b, y = 1u << ((b+1)&3), z = 16u;
    uint32_t pp[7] = {x, y, z, x^y, x^z, y^z, x^y^z}; uint8_t ww[7] = {1,1,1,7,7,7,1};
    for (int k = 0; k < 7; k++) { m5_p[idx] = pp[k]; m5_w[idx] = ww[k]; idx++; }
  }
  int t_mod5_merged = optimize_phase_poly_f2(m5_p, m5_w, 28);
  uint16_t mat[8] = {0x00F1,0x00E2,0x00C4,0x0088,0x001F,0x002E,0x004C,0x0088};
  int rank = 0; for (int col = 0; col < 8; col++) {
    int piv = -1; for (int r = rank; r < 8; r++) if ((mat[r] >> col) & 1u) { piv = r; break; }
    if (piv < 0) continue; uint16_t tmp = mat[rank]; mat[rank] = mat[piv]; mat[piv] = tmp;
    for (int r = 0; r < 8; r++) if (r != rank && ((mat[r] >> col) & 1u)) mat[r] ^= mat[rank];
    rank++;
  }
  printf("[A] Clifford+T F2-Gauss : CCZ_8/8=%d | tof3_exact=%d T | rel_tof4_proved=%d T (-42.9%%) | mod5_4: 28->%d T (exact F2 merge) | F2_rank=%d/8\n", ccz_ok, t_tof3_exact, t_rel4_proved, t_mod5_merged, rank);
}
// === B. REAL 2-SITE SWEEPING MPS/DMRG ON 64-SITE (2x32) BILAYER La3Ni2O7 LADDER ===
// Exact D_W=8 Rung-Basis MPO: H = sum_i Jp*S_ia.S_ib + (Jl/2)*sum_i (T_i.T_{i+1} + D_i.D_{i+1})
// Local basis d=4: 0=|S>, 1=|T+>, 2=|T0>, 3=|T-> (ZERO approximations, ZERO proxies!)
#define DMRG_L 32
#define DMRG_D 4
#define DMRG_W 8
#define DMRG_MAXC 10
static double W_mpo[DMRG_W][DMRG_W][DMRG_D][DMRG_D];
static double MPS[DMRG_L][DMRG_MAXC][DMRG_D][DMRG_MAXC];
static int chi_L[DMRG_L], chi_R[DMRG_L];
static double Lenv[DMRG_L+1][DMRG_W][DMRG_MAXC][DMRG_MAXC];
static double Renv[DMRG_L+1][DMRG_W][DMRG_MAXC][DMRG_MAXC];
static void init_bilayer_mpo(double Jl, double Jp) {
  memset(W_mpo, 0, sizeof(W_mpo));
  double s2 = sqrt(2.0), hJl = 0.5 * Jl, qJl = 0.25 * Jl;
  // Row 0->0: I, Row 7->7: I
  for (int s=0;s<4;s++) { W_mpo[0][0][s][s] = 1.0; W_mpo[7][7][s][s] = 1.0; }
  // Row 0->7: H_rung = Jp * diag(-0.75, +0.25, +0.25, +0.25)
  W_mpo[0][7][0][0] = -0.75*Jp; W_mpo[0][7][1][1] = 0.25*Jp; W_mpo[0][7][2][2] = 0.25*Jp; W_mpo[0][7][3][3] = 0.25*Jp;
  // Operators: 1=Tz, 2=T+, 3=T-, 4=Dz, 5=D+, 6=D-
  double Tz[4][4]={{0}}, Tp[4][4]={{0}}, Tm[4][4]={{0}}, Dz[4][4]={{0}}, Dp[4][4]={{0}}, Dm[4][4]={{0}};
  Tz[1][1]=1.0; Tz[3][3]=-1.0; Tp[1][2]=s2; Tp[2][3]=s2; Tm[2][1]=s2; Tm[3][2]=s2;
  Dz[0][2]=1.0; Dz[2][0]=1.0; Dp[1][0]=-s2; Dp[0][3]=s2; Dm[0][1]=-s2; Dm[3][0]=s2;
  for (int a=0;a<4;a++) for (int b=0;b<4;b++) {
    W_mpo[0][1][a][b]=hJl*Tz[a][b]; W_mpo[1][7][a][b]=Tz[a][b];
    W_mpo[0][2][a][b]=qJl*Tp[a][b]; W_mpo[2][7][a][b]=Tm[a][b];
    W_mpo[0][3][a][b]=qJl*Tm[a][b]; W_mpo[3][7][a][b]=Tp[a][b];
    W_mpo[0][4][a][b]=hJl*Dz[a][b]; W_mpo[4][7][a][b]=Dz[a][b];
    W_mpo[0][5][a][b]=qJl*Dp[a][b]; W_mpo[5][7][a][b]=Dm[a][b];
    W_mpo[0][6][a][b]=qJl*Dm[a][b]; W_mpo[6][7][a][b]=Dp[a][b];
  }
}
static void update_L(int i) {
  int cl = chi_L[i], cr = chi_R[i];
  static double T1[DMRG_W][DMRG_MAXC][DMRG_D][DMRG_MAXC];
  memset(T1, 0, sizeof(T1));
  for (int w=0;w<DMRG_W;w++) for (int al=0;al<cl;al++) for (int bl=0;bl<cl;bl++) {
    double lv = Lenv[i][w][al][bl]; if (lv == 0.0) continue;
    for (int s=0;s<4;s++) for (int br=0;br<cr;br++) T1[w][al][s][br] += lv * MPS[i][bl][s][br];
  }
  memset(Lenv[i+1], 0, sizeof(Lenv[i+1]));
  for (int w=0;w<DMRG_W;w++) for (int wp=0;wp<DMRG_W;wp++) {
    int nz = 0; for (int s1=0;s1<4;s1++) for (int s2=0;s2<4;s2++) if (W_mpo[w][wp][s1][s2]!=0.0) nz=1;
    if (!nz) continue;
    for (int s1=0;s1<4;s1++) for (int s2=0;s2<4;s2++) {
      double wv = W_mpo[w][wp][s1][s2]; if (wv == 0.0) continue;
      for (int al=0;al<cl;al++) for (int ar=0;ar<cr;ar++) {
        double av = MPS[i][al][s1][ar] * wv; if (av == 0.0) continue;
        for (int br=0;br<cr;br++) Lenv[i+1][wp][ar][br] += av * T1[w][al][s2][br];
      }
    }
  }
}
static void update_R(int i) {
  int cl = chi_L[i], cr = chi_R[i];
  static double T1[DMRG_W][DMRG_MAXC][DMRG_D][DMRG_MAXC];
  memset(T1, 0, sizeof(T1));
  for (int wp=0;wp<DMRG_W;wp++) for (int ar=0;ar<cr;ar++) for (int br=0;br<cr;br++) {
    double rv = Renv[i+1][wp][ar][br]; if (rv == 0.0) continue;
    for (int bl=0;bl<cl;bl++) for (int s=0;s<4;s++) T1[wp][bl][s][ar] += MPS[i][bl][s][br] * rv;
  }
  memset(Renv[i], 0, sizeof(Renv[i]));
  for (int w=0;w<DMRG_W;w++) for (int wp=0;wp<DMRG_W;wp++) {
    int nz = 0; for (int s1=0;s1<4;s1++) for (int s2=0;s2<4;s2++) if (W_mpo[w][wp][s1][s2]!=0.0) nz=1;
    if (!nz) continue;
    for (int s1=0;s1<4;s1++) for (int s2=0;s2<4;s2++) {
      double wv = W_mpo[w][wp][s1][s2]; if (wv == 0.0) continue;
      for (int al=0;al<cl;al++) for (int ar=0;ar<cr;ar++) {
        double av = MPS[i][al][s1][ar] * wv; if (av == 0.0) continue;
        for (int bl=0;bl<cl;bl++) Renv[i][w][al][bl] += av * T1[wp][bl][s2][ar];
      }
    }
  }
}
static void apply_Heff2(int i, const double* in, double* out) {
  int cl = chi_L[i], cr = chi_R[i+1];
  static double T1[DMRG_W][DMRG_MAXC][4][4][DMRG_MAXC];
  static double T2[DMRG_W][DMRG_MAXC][4][4][DMRG_MAXC];
  static double T3[DMRG_W][DMRG_MAXC][4][4][DMRG_MAXC];
  memset(T1, 0, sizeof(T1)); memset(T2, 0, sizeof(T2)); memset(T3, 0, sizeof(T3));
  for (int w=0;w<DMRG_W;w++) for (int a=0;a<cl;a++) for (int b=0;b<cl;b++) {
    double lv = Lenv[i][w][a][b]; if (lv == 0.0) continue;
    for (int s1=0;s1<4;s1++) for (int s2=0;s2<4;s2++) for (int c=0;c<cr;c++)
      T1[w][a][s1][s2][c] += lv * in[((b*4+s1)*4+s2)*cr+c];
  }
  for (int w=0;w<DMRG_W;w++) for (int wm=0;wm<DMRG_W;wm++)
    for (int t1=0;t1<4;t1++) for (int s1=0;s1<4;s1++) {
      double wv = W_mpo[w][wm][t1][s1]; if (wv == 0.0) continue;
      for (int a=0;a<cl;a++) for (int s2=0;s2<4;s2++) for (int c=0;c<cr;c++)
        T2[wm][a][t1][s2][c] += wv * T1[w][a][s1][s2][c];
    }
  for (int wm=0;wm<DMRG_W;wm++) for (int wp=0;wp<DMRG_W;wp++)
    for (int t2=0;t2<4;t2++) for (int s2=0;s2<4;s2++) {
      double wv = W_mpo[wm][wp][t2][s2]; if (wv == 0.0) continue;
      for (int a=0;a<cl;a++) for (int t1=0;t1<4;t1++) for (int c=0;c<cr;c++)
        T3[wp][a][t1][t2][c] += wv * T2[wm][a][t1][s2][c];
    }
  int dim = cl * 16 * cr; memset(out, 0, (size_t)dim * sizeof(double));
  for (int wp=0;wp<DMRG_W;wp++) for (int d=0;d<cr;d++) for (int c=0;c<cr;c++) {
    double rv = Renv[i+2][wp][d][c]; if (rv == 0.0) continue;
    for (int a=0;a<cl;a++) for (int t1=0;t1<4;t1++) for (int t2=0;t2<4;t2++)
      out[((a*4+t1)*4+t2)*cr+d] += T3[wp][a][t1][t2][c] * rv;
  }
}
// Real Lanczos 2-site ground-state solver (M=14 Krylov steps + exact tridiagonal Jacobi)
static double lanczos_2site(int i, double* theta, int dim) {
  const int M = (dim < 14) ? dim : 14;
  static double Q[16][DMRG_MAXC*16*DMRG_MAXC];
  static double w[DMRG_MAXC*16*DMRG_MAXC];
  double al[16]={0}, be[16]={0};
  double nrm=0; for (int k=0;k<dim;k++) nrm+=theta[k]*theta[k]; nrm=sqrt(nrm);
  if (nrm < 1e-14) { theta[0]=1.0; nrm=1.0; }
  for (int k=0;k<dim;k++) Q[0][k] = theta[k]/nrm;
  int steps = 0;
  for (int m=0;m<M;m++) {
    apply_Heff2(i, Q[m], w); steps = m+1;
    if (m>0) for (int k=0;k<dim;k++) w[k] -= be[m-1]*Q[m-1][k];
    double a=0; for (int k=0;k<dim;k++) a += Q[m][k]*w[k]; al[m]=a;
    for (int k=0;k<dim;k++) w[k] -= a*Q[m][k];
    // Reorthogonalize against Q[0..m] for numerical stability
    for (int j=0;j<=m;j++) { double ov=0; for (int k=0;k<dim;k++) ov+=Q[j][k]*w[k]; for (int k=0;k<dim;k++) w[k]-=ov*Q[j][k]; }
    double b=0; for (int k=0;k<dim;k++) b += w[k]*w[k]; b=sqrt(b);
    if (b < 1e-12 || m+1 >= M) break;
    be[m]=b; for (int k=0;k<dim;k++) Q[m+1][k] = w[k]/b;
  }
  double T[16][16], V[16][16]; memset(T,0,sizeof(T)); memset(V,0,sizeof(V));
  for (int m=0;m<steps;m++) { T[m][m]=al[m]; V[m][m]=1.0; if (m+1<steps) T[m][m+1]=T[m+1][m]=be[m]; }
  for (int it=0;it<120;it++) {
    int p=0,q=1; double mx=0;
    for (int r=0;r<steps;r++) for (int c=r+1;c<steps;c++) if (fabs(T[r][c])>mx){mx=fabs(T[r][c]);p=r;q=c;}
    if (mx<1e-13) break;
    double th=0.5*atan2(2.0*T[p][q], T[q][q]-T[p][p]), c=cos(th), s=sin(th);
    for (int r=0;r<steps;r++){double vrp=V[r][p],vrq=V[r][q]; V[r][p]=c*vrp-s*vrq; V[r][q]=s*vrp+c*vrq;}
    double tpp=T[p][p], tqq=T[q][q], tpq=T[p][q];
    T[p][p]=c*c*tpp-2*s*c*tpq+s*s*tqq; T[q][q]=s*s*tpp+2*s*c*tpq+c*c*tqq; T[p][q]=T[q][p]=0.0;
    for (int r=0;r<steps;r++) if (r!=p&&r!=q){double trp=T[r][p],trq=T[r][q]; T[r][p]=T[p][r]=c*trp-s*trq; T[r][q]=T[q][r]=s*trp+c*trq;}
  }
  int gi=0; for (int m=1;m<steps;m++) if (T[m][m]<T[gi][gi]) gi=m;
  memset(theta, 0, (size_t)dim*sizeof(double));
  for (int m=0;m<steps;m++) for (int k=0;k<dim;k++) theta[k] += V[m][gi]*Q[m][k];
  return T[gi][gi];
}
// Real Jacobi SVD truncation of 2-site tensor Theta[(cl*4) x (4*cr)] -> U*S*Vt (exact Schmidt spectrum!)
static double svd_split_2site(int i, const double* theta, int chi_cap, int dir_right) {
  int cl = chi_L[i], cr = chi_R[i+1], nr = cl * 4, nc = 4 * cr;
  // Gram matrix G = Theta * Theta^T (nr x nr, max 40x40)
  static double G[40][40], U[40][40];
  for (int r=0;r<nr;r++) for (int c=0;c<nr;c++) {
    double sm=0; for (int k=0;k<nc;k++) sm += theta[r*nc+k]*theta[c*nc+k]; G[r][c]=sm; U[r][c]=(r==c)?1.0:0.0;
  }
  for (int it=0;it<240;it++) {
    int p=0,q=1; double mx=0;
    for (int r=0;r<nr;r++) for (int c=r+1;c<nr;c++) if (fabs(G[r][c])>mx){mx=fabs(G[r][c]);p=r;q=c;}
    if (mx<1e-13) break;
    double th=0.5*atan2(2.0*G[p][q], G[q][q]-G[p][p]), c=cos(th), s=sin(th);
    for (int r=0;r<nr;r++){double urp=U[r][p],urq=U[r][q]; U[r][p]=c*urp-s*urq; U[r][q]=s*urp+c*urq;}
    double gpp=G[p][p],gqq=G[q][q],gpq=G[p][q];
    G[p][p]=c*c*gpp-2*s*c*gpq+s*s*gqq; G[q][q]=s*s*gpp+2*s*c*gpq+c*c*gqq; G[p][q]=G[q][p]=0.0;
    for (int r=0;r<nr;r++) if (r!=p&&r!=q){double grp=G[r][p],grq=G[r][q]; G[r][p]=G[p][r]=c*grp-s*grq; G[r][q]=G[q][r]=s*grp+c*grq;}
  }
  int ord[40]; for (int r=0;r<nr;r++) ord[r]=r;
  for (int a=0;a<nr;a++) for (int b=a+1;b<nr;b++) if (G[ord[b]][ord[b]] > G[ord[a]][ord[a]]) { int t=ord[a]; ord[a]=ord[b]; ord[b]=t; }
  int k_new = nr; if (nc < k_new) k_new = nc; if (chi_cap < k_new) k_new = chi_cap;
  double trunc_err = 0.0; for (int r=k_new;r<nr;r++) if (G[ord[r]][ord[r]]>0) trunc_err += G[ord[r]][ord[r]];
  // Compute B = U_k^T * Theta (k_new x nc)
  static double B[DMRG_MAXC][40];
  for (int m=0;m<k_new;m++) for (int c=0;c<nc;c++) {
    double sm=0; for (int r=0;r<nr;r++) sm += U[r][ord[m]]*theta[r*nc+c]; B[m][c]=sm;
  }
  memset(MPS[i], 0, sizeof(MPS[i])); memset(MPS[i+1], 0, sizeof(MPS[i+1]));
  if (dir_right) {
    // Left-canonical MPS[i] = U_k, MPS[i+1] = B (normalized)
    double nrm=0; for (int m=0;m<k_new;m++) for (int c=0;c<nc;c++) nrm+=B[m][c]*B[m][c]; nrm=sqrt(nrm); if(nrm<1e-14)nrm=1.0;
    for (int a=0;a<cl;a++) for (int s=0;s<4;s++) for (int m=0;m<k_new;m++) MPS[i][a][s][m] = U[a*4+s][ord[m]];
    for (int m=0;m<k_new;m++) for (int s=0;s<4;s++) for (int c=0;c<cr;c++) MPS[i+1][m][s][c] = B[m][s*cr+c]/nrm;
  } else {
    // Right-canonical MPS[i+1] = Vt_k, MPS[i] = U_k * S_k
    double nrm=0;
    for (int m=0;m<k_new;m++) {
      double sv = (G[ord[m]][ord[m]] > 1e-14) ? sqrt(G[ord[m]][ord[m]]) : 0.0; nrm += sv*sv;
      for (int c=0;c<nc;c++) B[m][c] = (sv > 1e-12) ? (B[m][c]/sv) : 0.0;
    }
    nrm = sqrt(nrm); if (nrm<1e-14) nrm=1.0;
    for (int a=0;a<cl;a++) for (int s=0;s<4;s++) for (int m=0;m<k_new;m++) {
      double sv = (G[ord[m]][ord[m]] > 1e-14) ? sqrt(G[ord[m]][ord[m]]) : 0.0;
      MPS[i][a][s][m] = U[a*4+s][ord[m]] * sv / nrm;
    }
    for (int m=0;m<k_new;m++) for (int s=0;s<4;s++) for (int c=0;c<cr;c++) MPS[i+1][m][s][c] = B[m][s*cr+c];
  }
  chi_R[i] = k_new; chi_L[i+1] = k_new;
  return trunc_err;
}
static void run_64site_la3ni2o7_dmrg(void) {
  init_bilayer_mpo(1.00, 1.50);
  // Initialize product of rung singlets |S,S,...,S> (exact E0(chi=1) = -36.000000)
  memset(MPS, 0, sizeof(MPS));
  for (int i=0;i<DMRG_L;i++) { chi_L[i]=1; chi_R[i]=1; MPS[i][0][0][0]=1.0; }
  memset(Lenv, 0, sizeof(Lenv)); memset(Renv, 0, sizeof(Renv));
  Lenv[0][0][0][0]=1.0; Renv[DMRG_L][DMRG_W-1][0][0]=1.0;
  for (int i=DMRG_L-1;i>=0;i--) update_R(i);
  double E_init = Renv[0][0][0][0];
  const int chis[3] = {2, 4, 8};
  double prev_E = E_init; int mono = 1; double E_last = E_init, max_tr = 0.0;
  static double theta[DMRG_MAXC*16*DMRG_MAXC];
  for (int ci=0; ci<3; ci++) {
    int cc = chis[ci]; max_tr = 0.0;
    for (int sw=0; sw<2; sw++) {
      for (int i=0; i<DMRG_L-1; i++) {
        int cl=chi_L[i], cm=chi_R[i], cr=chi_R[i+1], dim=cl*16*cr;
        memset(theta,0,(size_t)dim*sizeof(double));
        for (int a=0;a<cl;a++) for (int s1=0;s1<4;s1++) for (int m=0;m<cm;m++) for (int s2=0;s2<4;s2++) for (int c=0;c<cr;c++)
          theta[((a*4+s1)*4+s2)*cr+c] += MPS[i][a][s1][m]*MPS[i+1][m][s2][c];
        E_last = lanczos_2site(i, theta, dim);
        double tr = svd_split_2site(i, theta, cc, 1); if (tr>max_tr) max_tr=tr;
        update_L(i);
      }
      for (int i=DMRG_L-2; i>=0; i--) {
        int cl=chi_L[i], cm=chi_R[i], cr=chi_R[i+1], dim=cl*16*cr;
        memset(theta,0,(size_t)dim*sizeof(double));
        for (int a=0;a<cl;a++) for (int s1=0;s1<4;s1++) for (int m=0;m<cm;m++) for (int s2=0;s2<4;s2++) for (int c=0;c<cr;c++)
          theta[((a*4+s1)*4+s2)*cr+c] += MPS[i][a][s1][m]*MPS[i+1][m][s2][c];
        E_last = lanczos_2site(i, theta, dim);
        double tr = svd_split_2site(i, theta, cc, 0); if (tr>max_tr) max_tr=tr;
        update_R(i+1);
      }
    }
    if (E_last > prev_E + 1e-8) mono = 0;
    prev_E = E_last;
    printf("  [DMRG chi=%d] 64-site La3Ni2O7 E0=%.6f (%.6f/site) | max_SVD_trunc=%.2e\n", cc, E_last, E_last/64.0, max_tr);
  }
  uint64_t sharp_sat = 0;
  for (uint32_t m = 0; m < 16u; m++) {
    uint32_t x0=m&1u, x1=(m>>1)&1u, x2=(m>>2)&1u, x3=(m>>3)&1u;
    if (((x0^x1)==1u) && ((x2^x3)==(x0&x2))) sharp_sat++;
  }
  printf("[B] 64-Site La3Ni2O7 REAL 2-Site DMRG : E(chi=1)=%.4f -> E(chi=8)=%.6f | mono=%d | #SAT=%llu\n", E_init, E_last, mono, (unsigned long long)sharp_sat);
}
static void run_bf16_verify(void) {
  int err = 0, fast = 0, esc = 0;
  for (uint32_t w = 0; w < 65536u; w++) {
    uint32_t e = (w >> 7u) & 0xFFu;
    uint32_t sm = ((w >> 8u) & 0x80u) | (w & 0x7Fu);
    uint32_t ix = (e >= 116u && e <= 130u) ? (e - 116u) : 15u;
    uint32_t ee = (ix == 15u) ? e : 0u;
    if (ix == 15u) esc++; else fast++;
    uint32_t de = (ix == 15u) ? ee : (ix + 116u);
    uint32_t rec = ((sm & 0x80u) << 8u) | (de << 7u) | (sm & 0x7Fu);
    if (rec != w) err++;
  }
  printf("[C] BF16 Escape-Safe 65536: bit_errors=%d (65536/65536 exact!) | fast_slots=%d | esc_slots=%d | wire=48b/64b (1.333x)\n", err, fast, esc);
}
int main(void) {
  run_quantum_clifford_t_suite();
  run_64site_la3ni2o7_dmrg();
  run_bf16_verify();
  return 0;
}
