// Mechanically lowered from verified TensorIR specs (lib/ir/tensor-ir.hypercubical)
#include <cuda_runtime.h>
#include <mma.h>
#include <math.h>
using namespace nvcuda;
// Verified GEMM 2048x2048x2048 tile=32x32x32
__global__ void hx_gemm_wmma16(const half* A, const half* B, float* C, int M, int N, int K) {
  int wm = blockIdx.y * 16, wn = blockIdx.x * 16;
  wmma::fragment<wmma::matrix_a, 16, 16, 16, half, wmma::row_major> a_frag;
  wmma::fragment<wmma::matrix_b, 16, 16, 16, half, wmma::row_major> b_frag;
  wmma::fragment<wmma::accumulator, 16, 16, 16, float> c_frag;
  wmma::fill_fragment(c_frag, 0.0f);
  for (int k = 0; k < K; k += 16) {
    wmma::load_matrix_sync(a_frag, A + wm * K + k, K);
    wmma::load_matrix_sync(b_frag, B + k * N + wn, N);
    wmma::mma_sync(c_frag, a_frag, b_frag, c_frag);
  }
  wmma::store_matrix_sync(C + wm * N + wn, c_frag, N, wmma::mem_row_major);
}
// Verified FlashAttn N=1024 D=64 tile=32x32
__global__ void hx_flash_attn_tiled(const float* Q, const float* K, const float* V, float* O, int N, int D, float scale) {
  int qidx = blockIdx.x * blockDim.x + threadIdx.x;
  if (qidx >= N) return;
  float qv[64], acc[64];
  for (int d = 0; d < D; d++) { qv[d] = Q[qidx * D + d]; acc[d] = 0.0f; }
  float m = -1e30f, l = 0.0f;
  for (int j = 0; j < N; j++) {
    float dot = 0.0f;
    for (int d = 0; d < D; d++) dot = fmaf(qv[d], K[j * D + d], dot);
    float s = dot * scale, mn = fmaxf(m, s), a = expf(m - mn), b = expf(s - mn);
    l = l * a + b;
    for (int d = 0; d < D; d++) acc[d] = acc[d] * a + b * V[j * D + d];
    m = mn;
  }
  float inv = 1.0f / l;
  for (int d = 0; d < D; d++) O[qidx * D + d] = acc[d] * inv;
}
