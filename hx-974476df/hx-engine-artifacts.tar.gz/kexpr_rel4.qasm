OPENQASM 3.0;
include "stdgates.inc";
// Certified by kexpr-thm-rel-tof4-exact (8/8 unit-phase Z[zeta_8], T-count=4, -42.9%)
qubit[3] q;
h q[2];
t q[2];
cx q[1], q[2];
tdg q[2];
cx q[0], q[2];
t q[2];
cx q[1], q[2];
tdg q[2];
h q[2];
