// Synthesized optimal NAND2 Full-Adder cells directly from lib/hx-synth.hypercubical
module hx_synth_xor2(input logic w0, input logic w1, output logic y);
  wire w3 = ~(w0 & w1);
  wire w4 = ~(w0 & w3);
  wire w5 = ~(w1 & w3);
  wire w6 = ~(w4 & w5);
  assign y = w6;
endmodule
module hx_synth_maj3_carry(input logic w0, input logic w1, input logic w2, output logic cout);
  wire w3 = ~(w0 & w0);
  wire w4 = ~(w0 & w1);
  wire w5 = ~(w1 & w1);
  wire w6 = ~(w3 & w5);
  wire w7 = ~(w2 & w6);
  wire w8 = ~(w4 & w7);
  assign cout = w8;
endmodule
