#include <metal_stdlib>
using namespace metal;

constant uint K64[64] = {
  0x428a2f98u,0x71374491u,0xb5c0fbcfu,0xe9b5dba5u,0x3956c25bu,0x59f111f1u,0x923f82a4u,0xab1c5ed5u,
  0xd807aa98u,0x12835b01u,0x243185beu,0x550c7dc3u,0x72be5d74u,0x80deb1feu,0x9bdc06a7u,0xc19bf174u,
  0xe49b69c1u,0xefbe4786u,0x0fc19dc6u,0x240ca1ccu,0x2de92c6fu,0x4a7484aau,0x5cb0a9dcu,0x76f988dau,
  0x983e5152u,0xa831c66du,0xb00327c8u,0xbf597fc7u,0xc6e00bf3u,0xd5a79147u,0x06ca6351u,0x14292967u,
  0x27b70a85u,0x2e1b2138u,0x4d2c6dfcu,0x53380d13u,0x650a7354u,0x766a0abbu,0x81c2c92eu,0x92722c85u,
  0xa2bfe8a1u,0xa81a664bu,0xc24b8b70u,0xc76c51a3u,0xd192e819u,0xd6990624u,0xf40e3585u,0x106aa070u,
  0x19a4c116u,0x1e376c08u,0x2748774cu,0x34b0bcb5u,0x391c0cb3u,0x4ed8aa4au,0x5b9cca4fu,0x682e6ff3u,
  0x748f82eeu,0x78a5636fu,0x84c87814u,0x8cc70208u,0x90befffau,0xa4506cebu,0xbef9a3f7u,0xc67178f2u
};
inline uint rotr32(uint x, uint n) { return (x >> n) | (x << (32u - n)); }
inline uint sha256_eval_a(uint msg16, uint R) {
  uint W[16];
  W[0] = 0x61626380u ^ (msg16 & 0xFFFFu); W[1] = 0u; W[2] = 0u; W[3] = 0u;
  W[4] = 0u; W[5] = 0u; W[6] = 0u; W[7] = 0u; W[8] = 0u; W[9] = 0u;
  W[10] = 0u; W[11] = 0u; W[12] = 0u; W[13] = 0u; W[14] = 0u; W[15] = 24u;
  uint a=0x6a09e667u, b=0xbb67ae85u, c=0x3c6ef372u, d=0xa54ff53au;
  uint e=0x510e527fu, f=0x9b05688cu, g=0x1f83d9abu, h=0x5be0cd19u;
  for (uint r = 0; r < R; r++) {
    uint w = (r < 16u) ? W[r] : 0u;
    if (r >= 16u) {
      uint w15 = W[(r - 15u) & 15u], w2 = W[(r - 2u) & 15u];
      uint s0 = rotr32(w15,7u) ^ rotr32(w15,18u) ^ (w15 >> 3u);
      uint s1 = rotr32(w2,17u) ^ rotr32(w2,19u) ^ (w2 >> 10u);
      w = W[(r - 16u) & 15u] + s0 + W[(r - 7u) & 15u] + s1;
      W[r & 15u] = w;
    }
    uint S1 = rotr32(e,6u) ^ rotr32(e,11u) ^ rotr32(e,25u);
    uint ch = g ^ (e & (f ^ g));
    uint T1 = h + S1 + ch + K64[r] + w;
    uint S0 = rotr32(a,2u) ^ rotr32(a,13u) ^ rotr32(a,22u);
    uint maj = a ^ ((a ^ b) & (a ^ c));
    uint T2 = S0 + maj;
    h = g; g = f; f = e; e = d + T1; d = c; c = b; b = a; a = T1 + T2;
  }
  return a;
}

kernel void anf_pack_sha256(
  device uint* tt [[buffer(0)]],
  constant uint& R [[buffer(1)]],
  uint tid [[thread_position_in_grid]])
{
  uint base = tid * 32u;
  uint acc[32];
  for (uint b = 0; b < 32u; b++) acc[b] = 0u;
  for (uint k = 0; k < 32u; k++) {
    uint a = sha256_eval_a(base + k, R);
    for (uint b = 0; b < 32u; b++) acc[b] |= ((a >> b) & 1u) << k;
  }
  for (uint b = 0; b < 32u; b++) tt[b * 2048u + tid] = acc[b];
}

kernel void anf_mobius16(
  device uint* tt [[buffer(0)]],
  device uint* stats [[buffer(1)]],
  uint tgid [[threadgroup_position_in_grid]],
  uint lid [[thread_position_in_threadgroup]])
{
  threadgroup uint tg[2048];
  uint off = tgid * 2048u;
  uint v0 = tt[off + lid];
  uint v1 = tt[off + lid + 1024u];
  v0 ^= (v0 & 0x55555555u) << 1; v1 ^= (v1 & 0x55555555u) << 1;
  v0 ^= (v0 & 0x33333333u) << 2; v1 ^= (v1 & 0x33333333u) << 2;
  v0 ^= (v0 & 0x0F0F0F0Fu) << 4; v1 ^= (v1 & 0x0F0F0F0Fu) << 4;
  v0 ^= (v0 & 0x00FF00FFu) << 8; v1 ^= (v1 & 0x00FF00FFu) << 8;
  v0 ^= (v0 & 0x0000FFFFu) << 16; v1 ^= (v1 & 0x0000FFFFu) << 16;
  tg[lid] = v0; tg[lid + 1024u] = v1;
  threadgroup_barrier(mem_flags::mem_threadgroup);
  for (uint bit = 0u; bit < 11u; bit++) {
    uint stride = 1u << bit;
    uint block = lid >> bit;
    uint inb = lid & (stride - 1u);
    uint lo = (block << (bit + 1u)) + inb;
    uint hi = lo + stride;
    tg[hi] ^= tg[lo];
    threadgroup_barrier(mem_flags::mem_threadgroup);
  }
  uint w0 = tg[lid], w1 = tg[lid + 1024u];
  tt[off + lid] = w0; tt[off + lid + 1024u] = w1;
  uint cnt = popcount(w0) + popcount(w1);
  uint maxd = 0u, d1 = 0u, d2 = 0u;
  for (uint j = 0u; j < 2u; j++) {
    uint w = (j == 0u) ? w0 : w1;
    uint widx = lid + (j << 10u);
    uint hi_deg = popcount(widx);
    while (w) {
      uint tz = ctz(w);
      uint deg = hi_deg + popcount(tz);
      if (deg > maxd) maxd = deg;
      if (deg == 1u) d1++;
      if (deg == 2u) d2++;
      w &= (w - 1u);
    }
  }
  threadgroup uint sc[1024], sm[1024], s1[1024], s2[1024];
  sc[lid] = cnt; sm[lid] = maxd; s1[lid] = d1; s2[lid] = d2;
  threadgroup_barrier(mem_flags::mem_threadgroup);
  for (uint st = 512u; st > 0u; st >>= 1u) {
    if (lid < st) {
      sc[lid] += sc[lid + st];
      if (sm[lid + st] > sm[lid]) sm[lid] = sm[lid + st];
      s1[lid] += s1[lid + st];
      s2[lid] += s2[lid + st];
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
  }
  if (lid == 0u) {
    stats[tgid * 4u + 0u] = sc[0];
    stats[tgid * 4u + 1u] = sm[0];
    stats[tgid * 4u + 2u] = s1[0];
    stats[tgid * 4u + 3u] = s2[0];
  }
}

kernel void tn_contract_fp16(
  device const half* A [[buffer(0)]],
  device const half* B [[buffer(1)]],
  device half* C [[buffer(2)]],
  uint3 tgid [[threadgroup_position_in_grid]],
  uint sgid [[simdgroup_index_in_threadgroup]])
{
  uint batch = tgid.z;
  uint base = batch * 256u * 256u;
  uint row0 = tgid.y * 32u + (sgid / 2u) * 16u;
  uint col0 = tgid.x * 32u + (sgid % 2u) * 16u;
  simdgroup_float8x8 acc00 = make_filled_simdgroup_matrix<float,8,8>(0.0f);
  simdgroup_float8x8 acc01 = make_filled_simdgroup_matrix<float,8,8>(0.0f);
  simdgroup_float8x8 acc10 = make_filled_simdgroup_matrix<float,8,8>(0.0f);
  simdgroup_float8x8 acc11 = make_filled_simdgroup_matrix<float,8,8>(0.0f);
  for (uint k = 0u; k < 256u; k += 8u) {
    simdgroup_half8x8 a0, a1, b0, b1;
    simdgroup_load(a0, A + base + row0 * 256u + k, 256u);
    simdgroup_load(a1, A + base + (row0 + 8u) * 256u + k, 256u);
    simdgroup_load(b0, B + base + k * 256u + col0, 256u);
    simdgroup_load(b1, B + base + k * 256u + col0 + 8u, 256u);
    simdgroup_multiply_accumulate(acc00, a0, b0, acc00);
    simdgroup_multiply_accumulate(acc01, a0, b1, acc01);
    simdgroup_multiply_accumulate(acc10, a1, b0, acc10);
    simdgroup_multiply_accumulate(acc11, a1, b1, acc11);
  }
  simdgroup_half8x8 o00, o01, o10, o11;
  threadgroup float tmp[4][64];
  threadgroup half htmp[4][64];
  simdgroup_store(acc00, tmp[sgid], 8u);
  for (uint i = 0u; i < 64u; i++) htmp[sgid][i] = half(tmp[sgid][i]);
  simdgroup_load(o00, htmp[sgid], 8u);
  simdgroup_store(o00, C + base + row0 * 256u + col0, 256u);
  simdgroup_store(acc01, tmp[sgid], 8u);
  for (uint i = 0u; i < 64u; i++) htmp[sgid][i] = half(tmp[sgid][i]);
  simdgroup_load(o01, htmp[sgid], 8u);
  simdgroup_store(o01, C + base + row0 * 256u + col0 + 8u, 256u);
  simdgroup_store(acc10, tmp[sgid], 8u);
  for (uint i = 0u; i < 64u; i++) htmp[sgid][i] = half(tmp[sgid][i]);
  simdgroup_load(o10, htmp[sgid], 8u);
  simdgroup_store(o10, C + base + (row0 + 8u) * 256u + col0, 256u);
  simdgroup_store(acc11, tmp[sgid], 8u);
  for (uint i = 0u; i < 64u; i++) htmp[sgid][i] = half(tmp[sgid][i]);
  simdgroup_load(o11, htmp[sgid], 8u);
  simdgroup_store(o11, C + base + (row0 + 8u) * 256u + col0 + 8u, 256u);
}
