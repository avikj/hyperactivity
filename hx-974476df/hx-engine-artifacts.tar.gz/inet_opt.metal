// hx_hyperinet_opt.metal — Mechanically Lowered 32-Way Bit-Sliced Superoptimized Cubical INet GPU Shader
#include <metal_stdlib>
using namespace metal;
inline uint32_t opt_face_conflict(uint32_t w0, uint32_t w1, uint32_t w2) {
  uint32_t w3 = ~(w0 & w2);
  uint32_t w4 = ~(w1 & w2);
  uint32_t w5 = ~(w3 & w4);
  return w5;
}
inline uint32_t opt_demorgan_mux(uint32_t w0, uint32_t w1, uint32_t w2) {
  uint32_t w3 = ~(w0 & w1);
  uint32_t w4 = ~(w2 & w3);
  uint32_t w5 = ~(w0 & w4);
  uint32_t w6 = ~(w1 & w4);
  uint32_t w7 = ~(w5 & w6);
  return w7;
}
inline uint32_t opt_commute(uint32_t w0, uint32_t w1, uint32_t w2) {
  uint32_t w3 = ~(w0 & w1);
  uint32_t w4 = ~(w0 & w2);
  uint32_t w5 = ~(w1 & w2);
  uint32_t w6 = ~(w4 & w5);
  uint32_t w7 = ~(w3 & w6);
  uint32_t w8 = ~(w7 & w7);
  return w8;
}
inline uint32_t opt_era_prune(uint32_t w0, uint32_t w1, uint32_t w2) {
  uint32_t w3 = ~(w0 & w0);
  uint32_t w4 = ~(w1 & w1);
  uint32_t w5 = ~(w2 & w2);
  uint32_t w6 = ~(w3 & w4);
  uint32_t w7 = ~(w5 & w6);
  uint32_t w8 = ~(w5 & w7);
  return w8;
}
inline uint32_t opt_gals_clk_en(uint32_t w0, uint32_t w1, uint32_t w2) {
  uint32_t w3 = ~(w0 & w1);
  uint32_t w4 = ~(w0 & w3);
  uint32_t w5 = ~(w2 & w2);
  uint32_t w6 = ~(w4 & w5);
  return w6;
}
inline uint32_t opt_vxchg_fire(uint32_t w0, uint32_t w1, uint32_t w2) {
  uint32_t w3 = ~(w0 & w1);
  uint32_t w4 = ~(w0 & w2);
  uint32_t w5 = ~(w3 & w3);
  uint32_t w6 = ~(w4 & w5);
  uint32_t w7 = ~(w6 & w6);
  return w7;
}
inline uint32_t opt_aux_mux2(uint32_t w0, uint32_t w1, uint32_t w2) {
  uint32_t w3 = ~(w0 & w2);
  uint32_t w4 = ~(w0 & w3);
  uint32_t w5 = ~(w1 & w2);
  uint32_t w6 = ~(w4 & w5);
  return w6;
}
inline uint32_t opt_maj3_carry(uint32_t w0, uint32_t w1, uint32_t w2) {
  uint32_t w3 = ~(w0 & w0);
  uint32_t w4 = ~(w0 & w1);
  uint32_t w5 = ~(w1 & w1);
  uint32_t w6 = ~(w3 & w5);
  uint32_t w7 = ~(w2 & w6);
  uint32_t w8 = ~(w4 & w7);
  return w8;
}
inline uint32_t opt_xor2_vxchg(uint32_t w0, uint32_t w1, uint32_t w2) {
  uint32_t w3 = ~(w0 & w1);
  uint32_t w4 = ~(w0 & w3);
  uint32_t w5 = ~(w1 & w3);
  uint32_t w6 = ~(w4 & w5);
  return w6;
}

// 32-way bit-sliced gate-level Cubical Interaction-Net active-pair reduction engine:
// Each thread executes 32 independent cubical active pairs per iteration through ALL 45 superoptimized NAND2 gates!
kernel void hx_inet_opt_step(
  device uint32_t* out_stats [[buffer(0)]],
  constant uint32_t& iters   [[buffer(1)]],
  uint gid [[thread_position_in_grid]])
{
  uint32_t a0 = 0xA5A5F00Fu ^ (gid * 0x9E3779B9u);
  uint32_t b0 = 0x3C3C55AAu ^ (gid * 0x85EBCA6Bu);
  uint32_t m1 = 0xF0F033CCu ^ (gid * 0xC2B2AE35u);
  uint32_t ta = 0x55AA33CCu ^ gid, tb = 0xAA55CC33u ^ (gid << 3), pv = 0xFFFFFFFFu;
  uint32_t ea = 0x0F0F0F0Fu, eb = 0x00FF00FFu, vx_a = 0xAAAAAAAAu, vx_w = 0xCCCCCCCCu;
  uint32_t acc = 0u;
  for (uint i = 0; i < iters; ++i) {
    uint32_t fc   = opt_face_conflict(a0, b0, m1);
    uint32_t iv   = opt_demorgan_mux(a0, b0, m1);
    uint32_t era  = opt_era_prune(ea, eb, fc);
    uint32_t clk  = opt_gals_clk_en(pv, fc, 0u);
    uint32_t act  = pv & ~era;
    uint32_t comm = opt_commute(ta, tb, act);
    uint32_t ncm  = ~(comm & comm); uint32_t nann = ~(act & ncm); uint32_t ann = ~(nann & nann);
    uint32_t vxf  = opt_vxchg_fire(vx_a, vx_w, era);
    uint32_t vxn  = opt_xor2_vxchg(vx_a, vx_w, 0u);
    uint32_t mux  = opt_aux_mux2(ta, tb, comm);
    uint32_t cry  = opt_maj3_carry(ann, comm, vxf);
    acc ^= (fc ^ iv ^ clk ^ ann ^ vxn ^ mux ^ cry);
    a0 = (a0 << 1) | (iv >> 31); b0 = (b0 >> 1) | (comm << 31); ta = mux; vx_w = vxn;
  }
  out_stats[gid] = acc;
}
