#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <stdint.h>
#include <stdio.h>
#include <mach/mach_time.h>
static inline void opt_vx_coupled_eigen(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t v6, uint32_t v7, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4; (void)v5; (void)v6; (void)v7;
  uint32_t v8 = ((v0 + v1) * (v2 + v3));
  uint32_t v9 = (v4 * v6);
  uint32_t v10 = (v5 * v7);
  uint32_t v11 = ((v4 + v5) * (v6 + v7));
  out[0] = v8;
  out[1] = (v9 - v10);
  out[2] = ((v11 - v9) - v10);
}
static inline void opt_vx_horner_deg3(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4;
  out[0] = (v0 + (v4 * (v1 + (v4 * (v2 + (v4 * v3))))));
}
static inline void opt_vx_lfsr_jump4(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t v5, uint32_t v6, uint32_t v7, uint32_t* out) {
  out[0] = ((v0 ^ v1) ^ v4);
  out[1] = ((v1 ^ v2) ^ v5);
  out[2] = ((v2 ^ v3) ^ v6);
  out[3] = (((v0 ^ v1) ^ v3) ^ (v4 ^ v7));
}
static inline void opt_vx_mux_pipe4(uint32_t v0, uint32_t v1, uint32_t v2, uint32_t v3, uint32_t v4, uint32_t* out) {
  uint32_t v5 = (v0 & (v2 ^ v3));
  out[0] = (v4 ^ (v1 & ((v3 ^ v4) ^ v5)));
}
static const char* kVxMetalPath = "/home/claude/hxb/out/verify.metal";
static uint32_t vx_cpu_sig(uint32_t x0, uint32_t x1, uint32_t x2, uint32_t x3) {
  uint32_t x4=x0^0x9e3779b9u, x5=x1^0x85ebca6bu, x6=x2^0xc2b2ae35u, x7=x3^0x27d4eb2fu;
  uint32_t c0[4], c1[1], c2[3], c3[1];
  opt_vx_lfsr_jump4(x0,x1,x2,x3,x4,x5,x6,x7,c0);
  opt_vx_mux_pipe4(x0,x1,x2,x3,x4,c1);
  opt_vx_coupled_eigen(x0,x1,x2,x3,x4,x5,x6,x7,c2);
  opt_vx_horner_deg3(x0,x1,x2,x3,x4,c3);
  uint32_t p0=0u, p1=0u, p2=0u, xs[4]={x0,x1,x2,x3};
  for(int k=0;k<4;k++){ uint32_t u=xs[k]; p0=3u*u+p1; p1=5u*u+p2; p2=7u*u; }
  return c0[0] ^ c1[0] ^ c2[0] ^ c3[0] ^ p0;
}
int main(void) {
  @autoreleasepool {
    id<MTLDevice> dev = MTLCreateSystemDefaultDevice();
    if (!dev) { printf("NO_METAL_DEVICE\n"); return 1; }
    NSError* err = nil;
    NSString* src = [NSString stringWithContentsOfFile:[NSString stringWithUTF8String:kVxMetalPath] encoding:NSUTF8StringEncoding error:&err];
    if (!src) { fprintf(stderr, "Failed to read metal shader\n"); return 1; }
    MTLCompileOptions* opts = [[MTLCompileOptions alloc] init];
    opts.mathMode = MTLMathModeSafe;
    id<MTLLibrary> lib = [dev newLibraryWithSource:src options:opts error:&err];
    if (!lib) { fprintf(stderr, "Metal compile err: %s\n", [[err localizedDescription] UTF8String]); return 1; }
    id<MTLFunction> fn = [lib newFunctionWithName:@"vx_verify_miter_kernel"];
    id<MTLComputePipelineState> pso = [dev newComputePipelineStateWithFunction:fn error:&err];
    id<MTLCommandQueue> q = [dev newCommandQueue];
    const uint32_t N = 4194304u;
    id<MTLBuffer> bIn  = [dev newBufferWithLength:(size_t)N*16u options:MTLResourceStorageModeShared];
    id<MTLBuffer> bErr = [dev newBufferWithLength:(size_t)N*4u  options:MTLResourceStorageModeShared];
    id<MTLBuffer> bSig = [dev newBufferWithLength:(size_t)N*4u  options:MTLResourceStorageModeShared];
    uint32_t* pIn = (uint32_t*)[bIn contents];
    for (uint32_t i = 0; i < N*4u; i++) pIn[i] = i * 2654435761u ^ 0x9e3779b9u;
    mach_timebase_info_data_t tb; mach_timebase_info(&tb);
    uint64_t t0 = mach_absolute_time();
    id<MTLCommandBuffer> cb = [q commandBuffer];
    id<MTLComputeCommandEncoder> enc = [cb computeCommandEncoder];
    [enc setComputePipelineState:pso];
    [enc setBuffer:bIn offset:0 atIndex:0]; [enc setBuffer:bErr offset:0 atIndex:1]; [enc setBuffer:bSig offset:0 atIndex:2];
    [enc dispatchThreads:MTLSizeMake(N,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)];
    [enc endEncoding]; [cb commit]; [cb waitUntilCompleted];
    uint64_t t1 = mach_absolute_time();
    double sec = (double)(t1 - t0) * (double)tb.numer / ((double)tb.denom * 1e9);
    uint32_t* pErr = (uint32_t*)[bErr contents]; uint32_t* pSig = (uint32_t*)[bSig contents];
    uint32_t miterBad = 0u, sigBad = 0u;
    for (uint32_t i = 0; i < N; i++) if (pErr[i] != 0u) miterBad++;
    for (uint32_t i = 0; i < 65536u; i++) {
      uint32_t idx = (i * 61u) & (N - 1u);
      if (pSig[idx] != vx_cpu_sig(pIn[idx*4u], pIn[idx*4u+1u], pIn[idx*4u+2u], pIn[idx*4u+3u])) sigBad++;
    }
    printf("HX-VERIFY LIVE METAL GPU (%s): threads=%u | time=%.3f ms | %.2f G-threads/s | %.2f G-miter-checks/s | miter_err=%u cpu_gpu_err=%u\n", [[dev name] UTF8String], N, sec*1e3, (double)N/(sec*1e9), (double)N*32.0/(sec*1e9), miterBad, sigBad);
    return (miterBad || sigBad) ? 1 : 0;
  }
}
