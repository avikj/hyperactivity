OPENQASM 3.0;
include "stdgates.inc";
// Certified Quantum Adelic Poisson-GHZ Dual Code H^perp (8/8 exact Z[zeta_8], T-count=0)
qubit[3] q;
h q[0];
cx q[0], q[1];
cx q[0], q[2];
h q[0];
h q[1];
h q[2];
