#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
typedef struct { uint32_t rows, cols; } LlmDims;
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1e3 + ts.tv_nsec * 1e-6; }
static uint16_t f32_to_bf16(float f) { uint32_t u; memcpy(&u, &f, 4); return (uint16_t)(u >> 16); }
int main(void) { @autoreleasepool {
  id<MTLDevice> dev = MTLCreateSystemDefaultDevice();
  if (!dev) { printf(
"NO_METAL_DEVICE"); putchar(10); return 1; }
  NSError *err = nil;
  NSString *src = [NSString stringWithContentsOfFile:[NSString stringWithUTF8String:"/home/claude/hxb/out/llmzip.metal"] encoding:NSUTF8StringEncoding error:&err];
  id<MTLLibrary> lib = [dev newLibraryWithSource:src options:nil error:&err];
  if (!lib) { fprintf(stderr, 
"METAL_ERR: %s", err.localizedDescription.UTF8String); fputc(10, stderr); return 2; }
  id<MTLCommandQueue> q = [dev newCommandQueue];
  id<MTLComputePipelineState> pRaw = [dev newComputePipelineStateWithFunction:[lib newFunctionWithName:[NSString stringWithUTF8String:"hx_gemv_bf16_raw"]] error:&err];
  id<MTLComputePipelineState> pZip = [dev newComputePipelineStateWithFunction:[lib newFunctionWithName:[NSString stringWithUTF8String:"hx_gemv_bf16_zip"]] error:&err];
  const uint32_t R = 4096, C = 4096; const size_t N = (size_t)R * C;
  id<MTLBuffer> bW = [dev newBufferWithLength:N*2 options:MTLResourceStorageModeShared];
  id<MTLBuffer> bX = [dev newBufferWithLength:C*4 options:MTLResourceStorageModeShared];
  id<MTLBuffer> bY0 = [dev newBufferWithLength:R*4 options:MTLResourceStorageModeShared];
  id<MTLBuffer> bY1 = [dev newBufferWithLength:R*4 options:MTLResourceStorageModeShared];
  uint16_t *W = bW.contents; float *X = bX.contents;
  uint64_t rng = 0x9e3779b97f4a7c15ull;
  for (uint32_t i = 0; i < C; i++) X[i] = sinf(i * 0.017f) * 0.5f;
  for (size_t i = 0; i < N; i++) {
    rng ^= rng >> 12; rng ^= rng << 25; rng ^= rng >> 27;
    double u1 = ((rng * 0x2545F4914F6CDD1Dull) >> 11) * (1.0 / 9007199254740992.0) + 1e-12;
    rng ^= rng >> 12; rng ^= rng << 25; rng ^= rng >> 27;
    double u2 = ((rng * 0x2545F4914F6CDD1Dull) >> 11) * (1.0 / 9007199254740992.0);
    float g = (float)(sqrt(-2.0 * log(u1)) * cos(6.28318530718 * u2) * 0.02);
    W[i] = f32_to_bf16(g);
  }
  id<MTLBuffer> bSM = [dev newBufferWithLength:N options:MTLResourceStorageModeShared];
  id<MTLBuffer> bE4 = [dev newBufferWithLength:N/2 options:MTLResourceStorageModeShared];
  id<MTLBuffer> bPal = [dev newBufferWithLength:R*16 options:MTLResourceStorageModeShared];
  id<MTLBuffer> bEO = [dev newBufferWithLength:(R+1)*4 options:MTLResourceStorageModeShared];
  uint8_t *sm = bSM.contents, *pal = bPal.contents; uint16_t *e4 = bE4.contents; uint32_t *eo = bEO.contents;
  size_t esc_cap = 1024, esc_n = 0;
  uint16_t *ec_tmp = malloc(esc_cap * 2); uint8_t *ee_tmp = malloc(esc_cap);
  for (uint32_t r = 0; r < R; r++) {
    uint32_t hist[256] = {0};
    for (uint32_t c = 0; c < C; c++) hist[(W[r*C+c] >> 7) & 255]++;
    uint8_t top[15]; int rev[256]; for (int i = 0; i < 256; i++) rev[i] = 15;
    for (int k = 0; k < 15; k++) {
      int best = 0; for (int e = 1; e < 256; e++) if (hist[e] > hist[best]) best = e;
      top[k] = (uint8_t)best; pal[r*16+k] = (uint8_t)best; rev[best] = k; hist[best] = 0;
    }
    pal[r*16+15] = 0; eo[r] = (uint32_t)esc_n;
    for (uint32_t g = 0; g < C/4; g++) {
      uint16_t code = 0;
      for (uint32_t j = 0; j < 4; j++) {
        uint32_t c = g*4 + j; uint16_t w = W[r*C+c]; uint8_t e = (w >> 7) & 255;
        sm[r*C+c] = (uint8_t)(((w >> 8) & 128) | (w & 127));
        int idx = rev[e]; code |= (uint16_t)(idx << (j * 4));
        if (idx == 15) {
          if (esc_n >= esc_cap) { esc_cap *= 2; ec_tmp = realloc(ec_tmp, esc_cap * 2); ee_tmp = realloc(ee_tmp, esc_cap); }
          ec_tmp[esc_n] = (uint16_t)c; ee_tmp[esc_n] = e; esc_n++;
        }
      }
      e4[r*(C/4)+g] = code;
    }
  }
  eo[R] = (uint32_t)esc_n;
  id<MTLBuffer> bEC = [dev newBufferWithBytes:ec_tmp length:(esc_n ? esc_n*2 : 4) options:MTLResourceStorageModeShared];
  id<MTLBuffer> bEE = [dev newBufferWithBytes:ee_tmp length:(esc_n ? esc_n : 4) options:MTLResourceStorageModeShared];
  size_t raw_bytes = N * 2, zip_bytes = N + N/2 + R*16 + (R+1)*4 + esc_n * 3;
  LlmDims dm = { R, C }; MTLSize gr = MTLSizeMake(R, 1, 1), grp = MTLSizeMake(128, 1, 1);
  for (int w = 0; w < 3; w++) {
    id<MTLCommandBuffer> c0 = [q commandBuffer]; id<MTLComputeCommandEncoder> e0 = [c0 computeCommandEncoder];
    [e0 setComputePipelineState:pRaw]; [e0 setBuffer:bW offset:0 atIndex:0]; [e0 setBuffer:bX offset:0 atIndex:1]; [e0 setBuffer:bY0 offset:0 atIndex:2]; [e0 setBytes:&dm length:sizeof(dm) atIndex:3]; [e0 dispatchThreadgroups:gr threadsPerThreadgroup:grp]; [e0 endEncoding]; [c0 commit]; [c0 waitUntilCompleted];
    id<MTLCommandBuffer> c1 = [q commandBuffer]; id<MTLComputeCommandEncoder> e1 = [c1 computeCommandEncoder];
    [e1 setComputePipelineState:pZip]; [e1 setBuffer:bSM offset:0 atIndex:0]; [e1 setBuffer:bE4 offset:0 atIndex:1]; [e1 setBuffer:bPal offset:0 atIndex:2]; [e1 setBuffer:bEO offset:0 atIndex:3]; [e1 setBuffer:bEC offset:0 atIndex:4]; [e1 setBuffer:bEE offset:0 atIndex:5]; [e1 setBuffer:bSM offset:0 atIndex:6]; [e1 setBuffer:bX offset:0 atIndex:7]; [e1 setBuffer:bX offset:0 atIndex:8]; [e1 setBuffer:bY1 offset:0 atIndex:9]; [e1 setBytes:&dm length:sizeof(dm) atIndex:10]; [e1 dispatchThreadgroups:gr threadsPerThreadgroup:grp]; [e1 endEncoding]; [c1 commit]; [c1 waitUntilCompleted];
  }
  double t0 = now_ms();
  id<MTLCommandBuffer> cb0 = [q commandBuffer]; id<MTLComputeCommandEncoder> enc0 = [cb0 computeCommandEncoder];
  [enc0 setComputePipelineState:pRaw]; [enc0 setBuffer:bW offset:0 atIndex:0]; [enc0 setBuffer:bX offset:0 atIndex:1]; [enc0 setBuffer:bY0 offset:0 atIndex:2]; [enc0 setBytes:&dm length:sizeof(dm) atIndex:3];
  for (int it = 0; it < 40; it++) [enc0 dispatchThreadgroups:gr threadsPerThreadgroup:grp];
  [enc0 endEncoding]; [cb0 commit]; [cb0 waitUntilCompleted];
  double raw_ms = (now_ms() - t0) / 40.0;
  double t1 = now_ms();
  id<MTLCommandBuffer> cb1 = [q commandBuffer]; id<MTLComputeCommandEncoder> enc1 = [cb1 computeCommandEncoder];
  [enc1 setComputePipelineState:pZip]; [enc1 setBuffer:bSM offset:0 atIndex:0]; [enc1 setBuffer:bE4 offset:0 atIndex:1]; [enc1 setBuffer:bPal offset:0 atIndex:2]; [enc1 setBuffer:bEO offset:0 atIndex:3]; [enc1 setBuffer:bEC offset:0 atIndex:4]; [enc1 setBuffer:bEE offset:0 atIndex:5]; [enc1 setBuffer:bSM offset:0 atIndex:6]; [enc1 setBuffer:bX offset:0 atIndex:7]; [enc1 setBuffer:bX offset:0 atIndex:8]; [enc1 setBuffer:bY1 offset:0 atIndex:9]; [enc1 setBytes:&dm length:sizeof(dm) atIndex:10];
  for (int it = 0; it < 40; it++) [enc1 dispatchThreadgroups:gr threadsPerThreadgroup:grp];
  [enc1 endEncoding]; [cb1 commit]; [cb1 waitUntilCompleted];
  double zip_ms = (now_ms() - t1) / 40.0;
  float *Y0 = bY0.contents, *Y1 = bY1.contents; double max_err = 0.0;
  for (uint32_t r = 0; r < R; r++) { double e = fabs((double)Y0[r] - (double)Y1[r]); if (e > max_err) max_err = e; }
  printf("TensorIR LLM-ZIP BF16 4096x4096: raw=%.2f MB vs zip=%.2f MB (%.1f%% VRAM saved, esc=%.3f%%) | GPU raw=%.2f ms (%.1f GB/s) vs fused_zip=%.2f ms (%.2fx speedup, eff=%.1f GB/s) | max_err=%.2e", raw_bytes/1e6, zip_bytes/1e6, (1.0 - (double)zip_bytes/raw_bytes)*100.0, 100.0*esc_n/N, raw_ms, raw_bytes/(raw_ms*1e6), zip_ms, raw_ms/zip_ms, raw_bytes/(zip_ms*1e6), max_err); putchar(10);
  free(ec_tmp); free(ee_tmp); return max_err < 1e-5 ? 0 : 3;
} }
