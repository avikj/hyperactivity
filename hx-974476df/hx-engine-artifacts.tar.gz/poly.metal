// Mechanically lowered from PolyOptCert + F2OptCert (Apple Metal — identical AST to C11 & CUDA!)
#include <metal_stdlib>
using namespace metal;
inline void opt_karatsuba(uint v0, uint v1, uint v2, uint v3, thread uint* out) {
  (void)v0; (void)v1; (void)v2; (void)v3;
  uint v4 = (v0 * v2);
  uint v5 = (v1 * v3);
  uint v6 = ((v0 + v1) * (v2 + v3));
  out[0] = v4;
  out[1] = ((v6 - v4) - v5);
  out[2] = v5;
}
inline void opt_gauss_complex(uint v0, uint v1, uint v2, uint v3, thread uint* out) {
  (void)v0; (void)v1; (void)v2; (void)v3;
  uint v4 = (v0 * (v2 + v3));
  uint v5 = (v3 * (v0 + v1));
  uint v6 = (v2 * (v1 - v0));
  out[0] = (v4 - v5);
  out[1] = (v4 + v6);
}
inline void opt_horner_cubic(uint v0, uint v1, uint v2, uint v3, uint v4, thread uint* out) {
  (void)v0; (void)v1; (void)v2; (void)v3; (void)v4;
  out[0] = (v1 + (v0 * (v2 + (v0 * (v3 + (v0 * v4))))));
}
inline void opt_cayley_su2_err(uint v0, uint v1, uint v2, thread uint* out) {
  (void)v0; (void)v1; (void)v2;
  out[0] = 0u;
}
inline void opt_brahmagupta_norm(uint v0, uint v1, uint v2, uint v3, thread uint* out) {
  (void)v0; (void)v1; (void)v2; (void)v3;
  out[0] = (((v0 * v0) + (v1 * v1)) * ((v2 * v2) + (v3 * v3)));
}
inline void opt_sha256_ch(uint v0, uint v1, uint v2, thread uint* out) {
  out[0] = (v2 ^ (v0 & (v1 ^ v2)));
}
inline void opt_sha256_maj(uint v0, uint v1, uint v2, thread uint* out) {
  out[0] = (v0 ^ ((v0 ^ v1) & (v0 ^ v2)));
}
inline void opt_full_adder(uint v0, uint v1, uint v2, thread uint* out) {
  uint v3 = (v0 ^ v2);
  uint v4 = (v1 ^ v2);
  out[0] = (v3 ^ v1);
  out[1] = (v2 ^ (v3 & v4));
}
kernel void poly_metal_bench(device const uint* in [[buffer(0)]], device uint* out [[buffer(1)]], uint tid [[thread_position_in_grid]]) {
  uint a=in[tid*4u], b=in[tid*4u+1u], c=in[tid*4u+2u], d=in[tid*4u+3u]; uint k[3], g[2], f[2];
  opt_karatsuba(a,b,c,d,k); opt_gauss_complex(a,b,c,d,g); opt_full_adder(a,b,c,f);
  out[tid] = k[1] ^ g[0] ^ g[1] ^ f[0] ^ f[1];
}
