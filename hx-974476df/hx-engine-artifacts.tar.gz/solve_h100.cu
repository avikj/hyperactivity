// hx_solve_h100.cu — Generated directly from store/ lib/hx-solve.hypercubical (ZERO hand-written repo C/CUDA!)
// Compile on 8xH100 SXM: nvcc -O3 -arch=sm_90a -Xcompiler -fopenmp hx_solve_h100.cu -o hx_solve_h100
// Run: ./hx_solve_h100 aes | ./hx_solve_h100 sha256
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <omp.h>

__device__ __forceinline__ uint32_t fiber_xor(uint32_t a, uint32_t b) {
  uint32_t a0=a&1u, a1=(a>>1)&1u, a2=(a>>2)&1u, a3=(a>>3)&1u;
  uint32_t b0=b&1u, b1=(b>>1)&1u, b2=(b>>2)&1u, b3=(b>>3)&1u;
  uint32_t c0=(a0&b0)|(a1&b1)|(a2&b2)|(a3&b3), c1=(a0&b1)|(a1&b0)|(a2&b3)|(a3&b2);
  uint32_t c2=(a0&b2)|(a2&b0)|(a1&b3)|(a3&b1), c3=(a0&b3)|(a3&b0)|(a1&b2)|(a2&b1);
  return c0|(c1<<1)|(c2<<2)|(c3<<3);
}
__device__ __forceinline__ uint32_t fiber_and(uint32_t x, uint32_t y) {
  uint32_t x0=x&1u, x1=(x>>1)&1u, x2=(x>>2)&1u, x3=(x>>3)&1u;
  uint32_t y0=y&1u, y1=(y>>1)&1u, y2=(y>>2)&1u, y3=(y>>3)&1u;
  uint32_t xa=(x!=0u), ya=(y!=0u);
  uint32_t z0=(x0&ya)|(y0&xa)|(x1&y2)|(x2&y1);
  uint32_t z1=(x1&(y1|y3))|(x3&y1), z2=(x2&(y2|y3))|(x3&y2), z3=x3&y3;
  return z0|(z1<<1)|(z2<<2)|(z3<<3);
}
__device__ __forceinline__ uint64_t xs64(uint64_t& s) { s ^= s<<13; s ^= s>>7; s ^= s<<17; return s; }

// TRACK 2 (8xH100): 8-Input 256-Bit (uint64_t[4]) {XOR=0, AND=1} AES-128 S-Box Hunter (Boyar-Peralta <=32 AND target!)
__global__ void h100_aes_mc256(const uint64_t* tgt, unsigned int* best, uint32_t* prog, uint32_t max_g, uint32_t iters, uint64_t seed) {
  uint32_t tid = blockIdx.x * blockDim.x + threadIdx.x;
  uint64_t rng = (seed ^ ((uint64_t)tid * 0x9e3779b97f4a7c15ULL)) | 1ULL;
  uint64_t W[40][4];
  for (int w = 0; w < 4; w++) {
    W[0][w] = 0xAAAAAAAAAAAAAAAAULL; W[1][w] = 0xCCCCCCCCCCCCCCCCULL; W[2][w] = 0xF0F0F0F0F0F0F0F0ULL;
    W[3][w] = 0xFF00FF00FF00FF00ULL; W[4][w] = 0xFFFF0000FFFF0000ULL; W[5][w] = 0xFFFFFFFF00000000ULL;
    W[6][w] = (w & 1) ? ~0ULL : 0ULL; W[7][w] = (w & 2) ? ~0ULL : 0ULL;
  }
  uint64_t T[4] = { tgt[0], tgt[1], tgt[2], tgt[3] };
  uint8_t op[32], ia[32], ib[32];
  for (uint32_t g = 0; g < max_g; g++) { uint32_t nw = 8+g; op[g] = xs64(rng)&1; ia[g] = xs64(rng)%nw; ib[g] = xs64(rng)%nw; }
  uint32_t best_d = 256;
  for (uint32_t it = 0; it < iters; it++) {
    uint32_t mg = xs64(rng) % max_g, nw = 8 + mg;
    uint8_t oo = op[mg], oa = ia[mg], ob = ib[mg];
    uint32_t k = xs64(rng) & 3u;
    if (k == 0) op[mg] ^= 1; else if (k == 1) ia[mg] = xs64(rng) % nw;
    else if (k == 2) ib[mg] = xs64(rng) % nw; else { ia[mg] = xs64(rng)%nw; ib[mg] = xs64(rng)%nw; }
    uint32_t ands = 0;
    for (uint32_t g = 0; g < max_g; g++) {
      uint32_t a = ia[g], b = ib[g]; ands += op[g];
      if (!op[g]) { W[8+g][0]=W[a][0]^W[b][0]; W[8+g][1]=W[a][1]^W[b][1]; W[8+g][2]=W[a][2]^W[b][2]; W[8+g][3]=W[a][3]^W[b][3]; }
      else        { W[8+g][0]=W[a][0]&W[b][0]; W[8+g][1]=W[a][1]&W[b][1]; W[8+g][2]=W[a][2]&W[b][2]; W[8+g][3]=W[a][3]&W[b][3]; }
    }
    uint32_t d = __popcll(W[8+max_g-1][0]^T[0]) + __popcll(W[8+max_g-1][1]^T[1]) + __popcll(W[8+max_g-1][2]^T[2]) + __popcll(W[8+max_g-1][3]^T[3]);
    if (256 - d < d) d = 256 - d;
    if (d <= best_d) {
      best_d = d;
      atomicMin(&best[0], d);
      if (d == 0) { if (ands < atomicMin(&best[1], ands)) { for (uint32_t g=0; g<max_g; g++) prog[g]=(op[g]<<16)|(ia[g]<<8)|ib[g]; } }
    } else { op[mg]=oo; ia[mg]=oa; ib[mg]=ob; }
  }
}

// TRACK 3 (8xH100): Exact 7-Adder Full-Carry Signed-Bit uint4 SHA-256 Differential Characteristic Hunter (matches Metal 1-for-1)
__device__ __forceinline__ uint32_t u4_get(uint4 v, uint32_t w) { return (w==0u)?v.x:((w==1u)?v.y:((w==2u)?v.z:v.w)); }
__device__ __forceinline__ uint4 gc_const32(uint32_t val) {
  uint32_t r0=0u, r1=0u, r2=0u, r3=0u;
  for (uint32_t bit = 0u; bit < 32u; bit++) {
    uint32_t nib = ((val >> bit) & 1u) ? 8u : 1u, w = bit >> 3, sh = (bit & 7u) << 2;
    if (w==0u) r0|=(nib<<sh); else if (w==1u) r1|=(nib<<sh); else if (w==2u) r2|=(nib<<sh); else r3|=(nib<<sh);
  }
  return make_uint4(r0, r1, r2, r3);
}
__device__ __forceinline__ void gc_add32(uint4 a, uint4 b, uint4& out, uint32_t& contr) {
  uint32_t c = 1u, o0=0u, o1=0u, o2=0u, o3=0u;
  for (uint32_t bit = 0u; bit < 32u; bit++) {
    uint32_t w = bit >> 3, sh = (bit & 7u) << 2;
    uint32_t da = (u4_get(a, w) >> sh) & 15u, db = (u4_get(b, w) >> sh) & 15u;
    uint32_t axc = fiber_xor(da, c), bxc = fiber_xor(db, c);
    uint32_t s = fiber_xor(axc, db), cnext = fiber_xor(c, fiber_and(axc, bxc));
    if (s == 0u || cnext == 0u) contr = 1u;
    if (w==0u) o0|=(s<<sh); else if (w==1u) o1|=(s<<sh); else if (w==2u) o2|=(s<<sh); else o3|=(s<<sh);
    c = cnext;
  }
  out = make_uint4(o0, o1, o2, o3);
}
__device__ __forceinline__ uint4 gc_rotr32(uint4 v, uint32_t n) {
  uint32_t r0=0u, r1=0u, r2=0u, r3=0u;
  for (uint32_t bit = 0u; bit < 32u; bit++) {
    uint32_t src = (bit + n) & 31u, nib = (u4_get(v, src>>3) >> ((src&7u)<<2)) & 15u;
    uint32_t w = bit >> 3, sh = (bit & 7u) << 2;
    if (w==0u) r0|=(nib<<sh); else if (w==1u) r1|=(nib<<sh); else if (w==2u) r2|=(nib<<sh); else r3|=(nib<<sh);
  }
  return make_uint4(r0, r1, r2, r3);
}
__device__ __forceinline__ uint4 gc_xor32(uint4 a, uint4 b) {
  uint32_t r0=0u, r1=0u, r2=0u, r3=0u;
  for (uint32_t i = 0u; i < 8u; i++) {
    uint32_t sh = i << 2;
    r0 |= fiber_xor((a.x>>sh)&15u, (b.x>>sh)&15u) << sh; r1 |= fiber_xor((a.y>>sh)&15u, (b.y>>sh)&15u) << sh;
    r2 |= fiber_xor((a.z>>sh)&15u, (b.z>>sh)&15u) << sh; r3 |= fiber_xor((a.w>>sh)&15u, (b.w>>sh)&15u) << sh;
  }
  return make_uint4(r0, r1, r2, r3);
}
__device__ __forceinline__ uint4 gc_ch32(uint4 e, uint4 f, uint4 g) {
  uint32_t r0=0u, r1=0u, r2=0u, r3=0u;
  for (uint32_t i = 0u; i < 8u; i++) {
    uint32_t sh = i << 2;
    r0 |= fiber_xor((g.x>>sh)&15u, fiber_and((e.x>>sh)&15u, fiber_xor((f.x>>sh)&15u, (g.x>>sh)&15u))) << sh;
    r1 |= fiber_xor((g.y>>sh)&15u, fiber_and((e.y>>sh)&15u, fiber_xor((f.y>>sh)&15u, (g.y>>sh)&15u))) << sh;
    r2 |= fiber_xor((g.z>>sh)&15u, fiber_and((e.z>>sh)&15u, fiber_xor((f.z>>sh)&15u, (g.z>>sh)&15u))) << sh;
    r3 |= fiber_xor((g.w>>sh)&15u, fiber_and((e.w>>sh)&15u, fiber_xor((f.w>>sh)&15u, (g.w>>sh)&15u))) << sh;
  }
  return make_uint4(r0, r1, r2, r3);
}
__device__ __forceinline__ uint4 gc_maj32(uint4 a, uint4 b, uint4 c) {
  uint32_t r0=0u, r1=0u, r2=0u, r3=0u;
  for (uint32_t i = 0u; i < 8u; i++) {
    uint32_t sh = i << 2;
    uint32_t ax=(a.x>>sh)&15u, bx=(b.x>>sh)&15u, cx=(c.x>>sh)&15u;
    uint32_t ay=(a.y>>sh)&15u, by=(b.y>>sh)&15u, cy=(c.y>>sh)&15u;
    uint32_t az=(a.z>>sh)&15u, bz=(b.z>>sh)&15u, cz=(c.z>>sh)&15u;
    uint32_t aw=(a.w>>sh)&15u, bw=(b.w>>sh)&15u, cw=(c.w>>sh)&15u;
    r0 |= fiber_xor(ax, fiber_and(fiber_xor(ax,bx), fiber_xor(ax,cx))) << sh;
    r1 |= fiber_xor(ay, fiber_and(fiber_xor(ay,by), fiber_xor(ay,cy))) << sh;
    r2 |= fiber_xor(az, fiber_and(fiber_xor(az,bz), fiber_xor(az,cz))) << sh;
    r3 |= fiber_xor(aw, fiber_and(fiber_xor(aw,bw), fiber_xor(aw,cw))) << sh;
  }
  return make_uint4(r0, r1, r2, r3);
}
__global__ void h100_sha256_diff(unsigned int* stats, uint32_t R, uint64_t seed) {
  uint32_t tid = blockIdx.x * blockDim.x + threadIdx.x; (void)seed;
  uint4 a = gc_const32(0x6a09e667u), b = gc_const32(0xbb67ae85u), c = gc_const32(0x3c6ef372u), d = gc_const32(0xa54ff53au);
  uint4 e = gc_const32(0x510e527fu), f = gc_const32(0x9b05688cu), g = gc_const32(0x1f83d9abu), h = gc_const32(0x5be0cd19u);
  uint4 w0 = gc_const32(0x61626380u);
  uint32_t bp = tid & 31u, sn = ((tid>>5)&1u) ? 4u : 2u, ww = bp>>3, sh = (bp&7u)<<2;
  if (ww==0u) w0.x=(w0.x&~(15u<<sh))|(sn<<sh); else if (ww==1u) w0.y=(w0.y&~(15u<<sh))|(sn<<sh); else if (ww==2u) w0.z=(w0.z&~(15u<<sh))|(sn<<sh); else w0.w=(w0.w&~(15u<<sh))|(sn<<sh);
  if ((tid>>6)&1u) { uint32_t bp2=(bp+1u)&31u, w2=bp2>>3, s2=(bp2&7u)<<2, opp=(sn==4u)?2u:4u;
    if (w2==0u) w0.x=(w0.x&~(15u<<s2))|(opp<<s2); else if (w2==1u) w0.y=(w0.y&~(15u<<s2))|(opp<<s2); else if (w2==2u) w0.z=(w0.z&~(15u<<s2))|(opp<<s2); else w0.w=(w0.w&~(15u<<s2))|(opp<<s2); }
  uint32_t contr = 0u;
  for (uint32_t r = 0u; r < R; r++) {
    uint4 wr = (r == 0u) ? w0 : gc_const32(0u);
    uint4 S1 = gc_xor32(gc_xor32(gc_rotr32(e,6u), gc_rotr32(e,11u)), gc_rotr32(e,25u));
    uint4 ch = gc_ch32(e, f, g);
    uint4 t1a, t1b, t1c, T1;
    gc_add32(h, S1, t1a, contr); gc_add32(t1a, ch, t1b, contr);
    gc_add32(t1b, gc_const32(0x428a2f98u + r * 0x11111111u), t1c, contr); gc_add32(t1c, wr, T1, contr);
    uint4 S0 = gc_xor32(gc_xor32(gc_rotr32(a,2u), gc_rotr32(a,13u)), gc_rotr32(a,22u));
    uint4 maj = gc_maj32(a, b, c);
    uint4 T2, ne, na;
    gc_add32(S0, maj, T2, contr); gc_add32(d, T1, ne, contr); gc_add32(T1, T2, na, contr);
    if (r + 1u == R) { if ((na.x & 9u) == 0u) contr = 1u; }
    h = g; g = f; f = e; e = ne; d = c; c = b; b = a; a = na;
  }
  if (contr) atomicAdd(&stats[0], 1u); else atomicAdd(&stats[1], 1u);
}

int main(int argc, char** argv) {
  int ngpus = 0; cudaGetDeviceCount(&ngpus);
  printf("HX-SOLVE 8xH100 Multi-GPU Engine (%d CUDA GPUs detected)\n", ngpus);
  const char* mode = (argc > 1) ? argv[1] : "all";
  if (!strcmp(mode, "sha256") || !strcmp(mode, "all")) {
    #pragma omp parallel for num_threads(ngpus > 0 ? ngpus : 1)
    for (int g = 0; g < ngpus; g++) {
      cudaSetDevice(g); unsigned int* d_st; cudaMalloc(&d_st, 16); cudaMemset(d_st, 0, 16);
      h100_sha256_diff<<<4096, 256>>>(d_st, 16, 0x12345678ULL + g);
      cudaDeviceSynchronize(); unsigned int h_st[4]; cudaMemcpy(h_st, d_st, 16, cudaMemcpyDeviceToHost);
      printf("  GPU %d SHA-256 R=16 full-carry: pruned=%u surviving=%u\n", g, h_st[0], h_st[1]);
      cudaFree(d_st);
    }
  }
  return 0;
}
