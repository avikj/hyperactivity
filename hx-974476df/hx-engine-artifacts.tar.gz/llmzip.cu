// Mechanically lowered from verified tk-bf16-gemv 4096x4096 pal=15 threads=128
#include <cuda_runtime.h>
#include <stdint.h>
__device__ __forceinline__ float bf16_to_f32(uint16_t b) { return __uint_as_float((uint32_t)b << 16); }
__global__ void hx_gemv_bf16_zip_cuda(const uchar4* sm4, const uint16_t* e4, const uint8_t* pal, const uint32_t* esc_off, const uint16_t* esc_col, const uint8_t* esc_exp, const uint8_t* sm_raw, const float4* x4, const float* x, float* y, uint32_t rows, uint32_t cols) {
  uint32_t row = blockIdx.x, tid = threadIdx.x;
  __shared__ uint8_t lp[16]; if (tid < 16) lp[tid] = pal[row * 16 + tid];
  __syncthreads();
  uint32_t cols4 = cols >> 2; const uchar4* sr = sm4 + row * cols4; const uint16_t* er = e4 + row * cols4; float acc = 0.0f;
  for (uint32_t g = tid; g < cols4; g += 128) {
    uchar4 s = sr[g]; uint16_t code = er[g]; float4 xv = x4[g];
    uint8_t c0 = code & 15, c1 = (code >> 4) & 15, c2 = (code >> 8) & 15, c3 = (code >> 12) & 15;
    uint16_t w0 = (c0 < 15) ? (((uint16_t)(s.x & 128) << 8) | ((uint16_t)lp[c0] << 7) | (s.x & 127)) : 0;
    uint16_t w1 = (c1 < 15) ? (((uint16_t)(s.y & 128) << 8) | ((uint16_t)lp[c1] << 7) | (s.y & 127)) : 0;
    uint16_t w2 = (c2 < 15) ? (((uint16_t)(s.z & 128) << 8) | ((uint16_t)lp[c2] << 7) | (s.z & 127)) : 0;
    uint16_t w3 = (c3 < 15) ? (((uint16_t)(s.w & 128) << 8) | ((uint16_t)lp[c3] << 7) | (s.w & 127)) : 0;
    acc = fmaf(bf16_to_f32(w0), xv.x, acc); acc = fmaf(bf16_to_f32(w1), xv.y, acc);
    acc = fmaf(bf16_to_f32(w2), xv.z, acc); acc = fmaf(bf16_to_f32(w3), xv.w, acc);
  }
  uint32_t eb = esc_off[row], ee = esc_off[row + 1];
  for (uint32_t k = eb + tid; k < ee; k += 128) {
    uint32_t c = esc_col[k]; uint8_t s = sm_raw[row * cols + c];
    uint16_t w = ((uint16_t)(s & 128) << 8) | ((uint16_t)esc_exp[k] << 7) | (s & 127);
    acc = fmaf(bf16_to_f32(w), x[c], acc);
  }
  for (int off = 16; off > 0; off >>= 1) acc += __shfl_down_sync(0xffffffffu, acc, off);
  __shared__ float sh[4]; if ((tid & 31) == 0) sh[tid >> 5] = acc; __syncthreads();
  if (tid == 0) y[row] = sh[0] + sh[1] + sh[2] + sh[3];
}
